# Space Engineers drones, warships and printers v2.7 (everything)

Every drone, every warship and every printer, Full and Lite, in one zip.

Package contents: 28 drone blueprints, 16 ship blueprints, 32 printer blueprints. **No DLC blocks.** The warships (Shrike, Corsair, Warden, Leviathan, the Cradle Pod and the `* Wing` variants) have their own guide in the `Warships_*` zips (manual flying, Staff commands, drone launch, in-game test order); the sections below list them with the drones. `MODELS.md` in this zip is the master table (blocks, mass, thrust-to-weight, PCU, cost).

## Install

1. Unzip this package anywhere. You get `Blueprints/<Name>/{bp.sbc,thumb.png}`, `Scripts/*.cs` and this README. The scripts in
   `Scripts/` are compacted (no comments) so they fit the Programmable Block's 100,000-character limit: paste those. The commented
   originals in `Scripts/Source/` are for reading only and are too long to paste.
2. **Delete the old blueprint folders first.** Open `%AppData%\SpaceEngineers\Blueprints\local\`, and remove every folder of an earlier
   version of these ships (Hornet, Gnat, Longbow ..., also their `bp.sbcB5` files). The game caches a binary `bp.sbcB5` next to `bp.sbc`
   and keeps loading the stale copy if it is still there. This package never ships a `.sbcB5`.
3. Copy the `Blueprints/<Name>` folders you want into `%AppData%\SpaceEngineers\Blueprints\local\`.
4. In game: press **F10** (blueprint screen), pick the ship, and paste it into the world (creative tools, or load it into a projector in a
   survival world).
5. Every ship is pasted as a **dynamic** small-grid ship (a large-grid ship for the Basilisk). Do not convert printers to a station: a
   static printer would make every printed drone static.
6. Check that "In-game scripts" is enabled in the world settings, otherwise the Programmable Blocks do not run.
7. If something does not paste, send the game log (`%AppData%\SpaceEngineers\SpaceEngineers_*.log`) and say which model and variant.

**Which variant?** `<Name>` (Full) uses the whole design, including block types whose XML has never been seen in a game-written
blueprint (Sensor, AI blocks, Decoy, cargo containers, turret). `<Name> Lite` uses only block types whose XML shape is copied from a
game-written ship (the Starburst reference), with the one exception noted under "Known unknowns" (the small merge block). If a Full ship
does not paste, try its Lite twin: it must still fly and fight. No ship uses DLC blocks.

## Models

| Model | Variant | Blocks | Mass kg | Accel m/s2 | PCU | Script |
|---|---|--:|--:|--:|--:|---|
| Gnat | Full | 21 | 2253 | 0.0-6.4 | 722 | GnatSwarmAI |
| Gnat | Lite | 18 | 1807 | 0.0-8.0 | 647 | GnatSwarmAI |
| Hornet | Full | 54 | 4451 | 6.5 | 1010 | HornetDroneAI |
| Hornet | Lite | 51 | 4005 | 7.2 | 935 | HornetDroneAI |
| Longbow L | Full | 52 | 110181 | 6.3 | 926 | LongbowSniperAI |
| Longbow L | Lite | 49 | 108247 | 6.4 | 851 | LongbowSniperAI |
| Longbow L Seeker | Full | 53 | 124405 | 5.6 | 1201 | LongbowSniperAI |
| Longbow L Seeker | Lite | 50 | 122471 | 5.6 | 1126 | LongbowSniperAI |
| Longbow S | Full | 53 | 6044 | 4.8 | 885 | LongbowSniperAI |
| Longbow S | Lite | 50 | 5597 | 5.1 | 810 | LongbowSniperAI |
| Lancer | Full | 54 | 4515 | 6.4 | 1010 | LancerAI |
| Lancer | Lite | 51 | 4069 | 7.1 | 935 | LancerAI |
| Wasp | Full | 54 | 4607 | 6.3 | 1700 | WaspAI |
| Wasp | Lite | 51 | 4161 | 6.9 | 1625 | WaspAI |
| Midge | Full | 35 | 4169 | 6.9 | 680 | none |
| Midge | Lite | 20 | 2119 | 0.0-6.8 | 697 | GnatSwarmAI |
| Watcher | Full | 54 | 4005 | 7.2 | 900 | HornetDroneAI |
| Watcher | Lite | 53 | 3871 | 7.4 | 875 | HornetDroneAI |
| Aegis | Full | 58 | 4876 | 5.9 | 1180 | AegisAI |
| Aegis | Lite | 55 | 4525 | 6.4 | 1097 | AegisAI |
| Basilisk | Full | 52 | 115787 | 6.0 | 4257 | BasiliskAI |
| Basilisk | Lite | 48 | 112424 | 6.1 | 3957 | BasiliskAI |
| Basilisk Seeker | Full | 52 | 115787 | 6.0 | 4257 | BasiliskAI |
| Basilisk Seeker | Lite | 49 | 113852 | 6.1 | 4182 | BasiliskAI |
| Harrier | Full | 56 | 4693 | 6.1-12.3 | 1034 | HarrierAI |
| Harrier | Lite | 53 | 4247 | 6.8-13.6 | 959 | HarrierAI |
| Mantis | Full | 53 | 6312 | 4.6-9.1 | 914 | MantisAI |
| Mantis | Lite | 50 | 5866 | 4.9-9.8 | 839 | MantisAI |
| Cradle Pod | Full | 605 | 16518 | 0.0 | 1643 | CradleBayAI |
| Cradle Pod | Lite | 605 | 16518 | 0.0 | 1643 | CradleBayAI |
| Shrike | Full | 1278 | 59318 | 8.1-16.2 | 2864 | ShrikeAI |
| Shrike | Lite | 1273 | 58743 | 8.2-16.3 | 2779 | ShrikeAI |
| Corsair | Full | 6601 | 279167 | 3.4-6.9 | 11735 | CradleBayAI, ShrikeAI, StaffAI |
| Corsair | Lite | 6593 | 270831 | 3.5-7.1 | 10565 | CradleBayAI, ShrikeAI, StaffAI |
| Corsair Wing | Full | 6601 | 279167 | 3.4-6.9 | 11735 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Corsair Wing | Lite | 6593 | 270831 | 3.5-7.1 | 10565 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Warden | Full | 1220 | 2758126 | 1.6-3.8 | 9862 | CradleBayAI, ShrikeAI, StaffAI |
| Warden | Lite | 1215 | 2747526 | 1.6-3.8 | 9577 | CradleBayAI, ShrikeAI, StaffAI |
| Warden Wing | Full | 1220 | 2758126 | 1.6-3.8 | 9862 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Warden Wing | Lite | 1215 | 2747526 | 1.6-3.8 | 9577 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Leviathan | Full | 8550 | 14895816 | 1.0-1.9 | 34251 | CradleBayAI, ShrikeAI, StaffAI |
| Leviathan | Lite | 8534 | 14877763 | 1.0-1.9 | 33620 | CradleBayAI, ShrikeAI, StaffAI |
| Leviathan Wing | Full | 8550 | 14895816 | 1.0-1.9 | 34251 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Leviathan Wing | Lite | 8534 | 14877763 | 1.0-1.9 | 33620 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Aegis Shipyard | Full | 333 | 21579 | 1.3 | 4738 | AegisAI, HiveMotherAI |
| Aegis Shipyard | Lite | 301 | 20881 | 1.4 | 4688 | AegisAI, HiveMotherAI |
| Escort Carrier | Full | 326 | 47702 | 0.9 | 5337 | HiveMotherAI, HornetDroneAI |
| Escort Carrier | Lite | 311 | 44895 | 1.0 | 4782 | HiveMotherAI, HornetDroneAI |
| Fleet Forge | Full | 424 | 30368 | 1.4 | 7277 | GnatSwarmAI, HiveMotherAI, HornetDroneAI |
| Fleet Forge | Lite | 377 | 27228 | 1.6 | 6467 | GnatSwarmAI, HiveMotherAI, HornetDroneAI |
| Harrier Forge | Full | 303 | 20979 | 1.4 | 4708 | HarrierAI, HiveMotherAI |
| Harrier Forge | Lite | 256 | 18267 | 1.6 | 4047 | HarrierAI, HiveMotherAI |
| Hive Mother | Full | 221 | 15055 | 1.9 | 3136 | GnatSwarmAI, HiveMotherAI |
| Hive Mother | Lite | 205 | 13820 | 2.1 | 2804 | GnatSwarmAI, HiveMotherAI |
| Hornet Forge | Full | 313 | 21179 | 1.4 | 4718 | HiveMotherAI, HornetDroneAI |
| Hornet Forge | Lite | 301 | 20024 | 1.4 | 4390 | HiveMotherAI, HornetDroneAI |
| Lancer Foundry | Full | 329 | 21499 | 1.3 | 4734 | HiveMotherAI, LancerAI |
| Lancer Foundry | Lite | 323 | 21321 | 1.4 | 4710 | HiveMotherAI, LancerAI |
| Longbow Foundry | Full | 298 | 20879 | 1.4 | 4703 | HiveMotherAI, LongbowSniperAI |
| Longbow Foundry | Lite | 318 | 21221 | 1.4 | 4705 | HiveMotherAI, LongbowSniperAI |
| Mantis Foundry | Full | 331 | 21539 | 1.3 | 4736 | HiveMotherAI, MantisAI |
| Mantis Foundry | Lite | 339 | 21641 | 1.3 | 4726 | HiveMotherAI, MantisAI |
| Mobile Hive | Full | 361 | 25430 | 2.3 | 5790 | GnatSwarmAI, HiveMotherAI |
| Mobile Hive | Lite | 338 | 23198 | 2.5 | 5153 | GnatSwarmAI, HiveMotherAI |
| Quad Hive | Full | 589 | 42110 | 1.0 | 10716 | GnatSwarmAI, HiveMotherAI |
| Quad Hive | Lite | 542 | 37684 | 1.1 | 9459 | GnatSwarmAI, HiveMotherAI |
| Static Nest | Full | 453 | 31209 | 0.0 | 8000 | GnatSwarmAI, HiveMotherAI |
| Static Nest | Lite | 417 | 27860 | 0.0 | 7052 | GnatSwarmAI, HiveMotherAI |
| Stinger Rack | Full | 352 | 24038 | 1.2 | 5649 | HiveMotherAI, StingerAI |
| Stinger Rack | Lite | 350 | 23940 | 1.2 | 5629 | HiveMotherAI, StingerAI |
| Twin Hive | Full | 349 | 23978 | 1.2 | 5646 | GnatSwarmAI, HiveMotherAI |
| Twin Hive | Lite | 326 | 21746 | 1.3 | 5009 | GnatSwarmAI, HiveMotherAI |
| Wasp Foundry | Full | 313 | 21179 | 1.4 | 4718 | HiveMotherAI, WaspAI |
| Wasp Foundry | Lite | 301 | 20024 | 1.4 | 4390 | HiveMotherAI, WaspAI |
| Watcher Pad | Full | 319 | 21299 | 1.4 | 4724 | HiveMotherAI, HornetDroneAI |
| Watcher Pad | Lite | 283 | 18807 | 1.5 | 4074 | HiveMotherAI, HornetDroneAI |

### Gnat

Compact swarm drone: one gatling, two axial ion thrusters (it steers by turning the whole ship), sensor, AI Offensive + AI Flight blocks on a 2-cell tail (Lite: none), belly merge latch. Flies yo-yo attack runs inside a leaderless IGC swarm.

* **Gnat**: 21 blocks, 2253 kg, 2.0x2.5x3.5 m, accel F6.4 B6.4 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 722; script: GnatSwarmAI.cs; cost Iron 2282 Nickel 274 Cobalt 26 Silicon 23 Gold 2 Platinum 1
* **Gnat Lite**: 18 blocks, 1807 kg, 2.0x2.5x2.5 m, accel F8.0 B8.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 647; script: GnatSwarmAI.cs; cost Iron 1838 Nickel 44 Cobalt 26 Silicon 17 Gold 2 Platinum 1

Note: Thrust only along the nose axis (forward / back), by design.

### Hornet

The standard fighter: two gatlings, 12 ion thrusters (2 per axis), 7 cameras, 4 batteries, rear merge latch. Holds a standoff, orbits and jinks; guard / hunt / assist.

* **Hornet**: 54 blocks, 4451 kg, 3.5x3.0x4.0 m, accel F6.5 B6.5 U6.5 D6.5 L6.5 R6.5 m/s2, PCU 1010; script: HornetDroneAI.cs; cost Iron 4412 Nickel 301 Cobalt 132 Silicon 31 Gold 12 Platinum 5
* **Hornet Lite**: 51 blocks, 4005 kg, 3.5x3.0x4.0 m, accel F7.2 B7.2 U7.2 D7.2 L7.2 R7.2 m/s2, PCU 935; script: HornetDroneAI.cs; cost Iron 3968 Nickel 71 Cobalt 132 Silicon 25 Gold 12 Platinum 5

### Longbow L

Large-grid railgun sniper (2000 m). Same logic as Longbow S; not printable (no merge block).

* **Longbow L**: 52 blocks, 110181 kg, 17.5x25.0x27.5 m, accel F6.3 B6.3 U6.3 D6.3 L6.3 R6.3 m/s2, PCU 926; script: LongbowSniperAI.cs; cost Iron 97090 Nickel 1850 Cobalt 9750 Silicon 528 Gold 1260 Platinum 384
* **Longbow L Lite**: 49 blocks, 108247 kg, 17.5x25.0x27.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 851; script: LongbowSniperAI.cs; cost Iron 95132 Nickel 1120 Cobalt 9750 Silicon 518 Gold 1260 Platinum 384

Note: Large grid, no merge block: paste only.

### Longbow L Seeker

TEST SHIP for subsystem seeking: Longbow L with an artillery turret (2 km, the railgun's reach) named [Seeker] on its back. The script sets the turret to a targeting group (Custom Data: Seeker Group, default PowerSystems), reads where it points and aims its railgun slugs down that line. The status screen shows a "Seek:" line with what the turret reports.

* **Longbow L Seeker**: 53 blocks, 124405 kg, 17.5x25.0x27.5 m, accel F5.6 B5.6 U5.6 D5.6 L5.6 R5.6 m/s2, PCU 1201; script: LongbowSniperAI.cs; cost Iron 112150 Nickel 2250 Cobalt 9900 Silicon 532 Gold 1260 Platinum 384
* **Longbow L Seeker Lite**: 50 blocks, 122471 kg, 17.5x25.0x27.5 m, accel F5.6 B5.6 U5.6 D5.6 L5.6 R5.6 m/s2, PCU 1126; script: LongbowSniperAI.cs; cost Iron 110192 Nickel 1520 Cobalt 9900 Silicon 522 Gold 1260 Platinum 384

Note: Large grid, paste only. Experimental (see Basilisk Seeker). Load artillery shells into the turret: a turret without ammunition may not pick a target at all, and then it cannot guide the railgun.

### Longbow S

Small-grid railgun sniper (1400 m). Computes the longest range at which a dodging target is still hit, takes one settled shot, jinks while reloading.

* **Longbow S**: 53 blocks, 6044 kg, 3.5x4.0x5.5 m, accel F4.8 B4.8 U4.8 D4.8 L4.8 R4.8 m/s2, PCU 885; script: LongbowSniperAI.cs; cost Iron 5619 Nickel 310 Cobalt 120 Silicon 58 Gold 52 Platinum 5
* **Longbow S Lite**: 50 blocks, 5597 kg, 3.5x4.0x5.5 m, accel F5.1 B5.1 U5.1 D5.1 L5.1 R5.1 m/s2, PCU 810; script: LongbowSniperAI.cs; cost Iron 5175 Nickel 80 Cobalt 120 Silicon 51 Gold 52 Platinum 5

Note: No docking face in the base model; printers add a docking stalk to it.

### Lancer

Hornet-class frame with 1x1x5 autocannons (800 m/s shells). Burst fire only when the solution is tight; standoff 420 m.

* **Lancer**: 54 blocks, 4515 kg, 3.5x3.0x4.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 1010; script: LancerAI.cs; cost Iron 4472 Nickel 301 Cobalt 132 Silicon 31 Gold 12 Platinum 5
* **Lancer Lite**: 51 blocks, 4069 kg, 3.5x3.0x4.5 m, accel F7.1 B7.1 U7.1 D7.1 L7.1 R7.1 m/s2, PCU 935; script: LancerAI.cs; cost Iron 4028 Nickel 71 Cobalt 132 Silicon 25 Gold 12 Platinum 5

### Wasp

Hornet frame with small rocket launchers (8 rockets). Integrates the rocket speed curve to lead targets, fires short salvos, refuses shots at unpredictable targets or near hive mates.

* **Wasp**: 54 blocks, 4607 kg, 3.5x3.0x4.0 m, accel F6.3 B6.3 U6.3 D6.3 L6.3 R6.3 m/s2, PCU 1700; script: WaspAI.cs; cost Iron 4584 Nickel 291 Cobalt 126 Silicon 31 Gold 12 Platinum 5
* **Wasp Lite**: 51 blocks, 4161 kg, 3.5x3.0x4.0 m, accel F6.9 B6.9 U6.9 D6.9 L6.9 R6.9 m/s2, PCU 1625; script: WaspAI.cs; cost Iron 4140 Nickel 61 Cobalt 126 Silicon 25 Gold 12 Platinum 5

Note: Needs rockets loaded by hand in survival; relies on the terminal action ShootOnce (unverified).

### Midge (experimental)

EXPERIMENTAL scriptless drone: gatling, AI Offensive + AI Flight + AI Defensive blocks, no Programmable Block. The AI blocks must be set up by hand (Scripts/MidgeNotes.md). Midge Lite is only a renamed Gnat Lite running GnatSwarmAI.cs.

* **Midge**: 35 blocks, 4169 kg, 3.5x3.0x5.0 m, accel F6.9 B6.9 U6.9 D6.9 L6.9 R6.9 m/s2, PCU 680; script: none; cost Iron 4122 Nickel 267 Cobalt 126 Silicon 19 Gold 12 Platinum 5
* **Midge Lite**: 20 blocks, 2119 kg, 2.0x2.5x3.5 m, accel F6.8 B6.8 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 697; script: GnatSwarmAI.cs; cost Iron 2144 Nickel 184 Cobalt 26 Silicon 21 Gold 2 Platinum 1

Note: Experimental; no script. Configure the three AI blocks by hand (Scripts/MidgeNotes.md). Gatling ammo is not preloaded.

### Watcher

Unarmed scout / spotter: 11 cameras, 5000 m antenna. Keeps 900 m standoff and shares targets with the hive (runs the Hornet script in scout mode).

* **Watcher**: 54 blocks, 4005 kg, 3.5x3.0x4.0 m, accel F7.2 B7.2 U7.2 D7.2 L7.2 R7.2 m/s2, PCU 900; script: HornetDroneAI.cs; cost Iron 3948 Nickel 131 Cobalt 120 Silicon 29 Gold 12 Platinum 5
* **Watcher Lite**: 53 blocks, 3871 kg, 3.5x3.0x4.0 m, accel F7.4 B7.4 U7.4 D7.4 L7.4 R7.4 m/s2, PCU 875; script: HornetDroneAI.cs; cost Iron 3810 Nickel 41 Cobalt 120 Silicon 27 Gold 12 Platinum 5

Note: Configured only through the PB Custom Data ([Hornet] section, IGC Tag HORNET, Start Mode HUNT). `range` is clamped to Max Fire Range; use Standoff in Custom Data for larger values.

### Aegis

Escort / point defence: four gatlings, two decoys (Lite: armour plates). Parks on a station around the carrier and screens it by standing on the carrier-to-threat line.

* **Aegis**: 58 blocks, 4876 kg, 3.5x3.0x4.5 m, accel F5.9 B5.9 U5.9 D5.9 L5.9 R5.9 m/s2, PCU 1180; script: AegisAI.cs; cost Iron 4882 Nickel 331 Cobalt 144 Silicon 34 Gold 12 Platinum 5
* **Aegis Lite**: 55 blocks, 4525 kg, 3.5x3.0x4.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 1097; script: AegisAI.cs; cost Iron 4560 Nickel 121 Cobalt 156 Silicon 25 Gold 12 Platinum 5

Note: For a carrier link copy HornetMothership.cs and change Tag to AEGIS, or use the default extra channel HORNET_HOME.

### Basilisk

LARGE-grid armoured rocket gunship: four large missile launchers, six heavy armour blocks, 12 thrusters; Full adds a large gatling turret as point defence. Not printable.

* **Basilisk**: 52 blocks, 115787 kg, 17.5x17.5x20.0 m, accel F6.0 B6.0 U6.0 D6.0 L6.0 R6.0 m/s2, PCU 4257; script: BasiliskAI.cs; cost Iron 109148 Nickel 3825 Cobalt 11055 Silicon 326 Gold 960 Platinum 384
* **Basilisk Lite**: 48 blocks, 112424 kg, 17.5x17.5x20.0 m, accel F6.1 B6.1 U6.1 D6.1 L6.1 R6.1 m/s2, PCU 3957; script: BasiliskAI.cs; cost Iron 105655 Nickel 2980 Cobalt 11010 Silicon 313 Gold 960 Platinum 384

Note: Large grid: paste it as a free ship; it has no merge block and cannot be put in a printer bay.

### Basilisk Seeker

TEST SHIP for subsystem seeking: the Full Basilisk with its roof turret named [Seeker]. The script sets that turret to a targeting group (Custom Data: Seeker Group, default PowerSystems), reads where it points, and drills its rockets into the hull over that block. The status screen shows a "Seek:" line with what the turret reports.

* **Basilisk Seeker**: 52 blocks, 115787 kg, 17.5x17.5x20.0 m, accel F6.0 B6.0 U6.0 D6.0 L6.0 R6.0 m/s2, PCU 4257; script: BasiliskAI.cs; cost Iron 109148 Nickel 3825 Cobalt 11055 Silicon 326 Gold 960 Platinum 384
* **Basilisk Seeker Lite**: 49 blocks, 113852 kg, 17.5x17.5x20.0 m, accel F6.1 B6.1 U6.1 D6.1 L6.1 R6.1 m/s2, PCU 4182; script: BasiliskAI.cs; cost Iron 107190 Nickel 3095 Cobalt 11055 Silicon 315 Gold 960 Platinum 384

Note: Large grid, paste only. Experimental: tells you whether the game lets a script find an enemy's power blocks through a turret. Decoys pull the turret first.

### Harrier

Fast interceptor: Hornet frame with four main engines (12 m/s2 forward). Hunts small fast grids, drones and missiles first; shares threat cues on the DRONE_CUE channel.

* **Harrier**: 56 blocks, 4693 kg, 3.5x3.0x4.0 m, accel F12.3 B6.1 U6.1 D6.1 L6.1 R6.1 m/s2, PCU 1034; script: HarrierAI.cs; cost Iron 4648 Nickel 301 Cobalt 152 Silicon 31 Gold 14 Platinum 6
* **Harrier Lite**: 53 blocks, 4247 kg, 3.5x3.0x4.0 m, accel F13.6 B6.8 U6.8 D6.8 L6.8 R6.8 m/s2, PCU 959; script: HarrierAI.cs; cost Iron 4204 Nickel 71 Cobalt 152 Silicon 25 Gold 14 Platinum 6

### Mantis

Railgun + gatling hybrid on a Longbow S spine: alpha strike at range, gatling up close. Engage cap 650 m.

* **Mantis**: 53 blocks, 6312 kg, 3.5x4.5x5.5 m, accel F9.1 B4.6 U4.6 D4.6 L4.6 R4.6 m/s2, PCU 914; script: MantisAI.cs; cost Iron 5891 Nickel 325 Cobalt 146 Silicon 56 Gold 54 Platinum 6
* **Mantis Lite**: 50 blocks, 5866 kg, 3.5x4.5x5.5 m, accel F9.8 B4.9 U4.9 D4.9 L4.9 R4.9 m/s2, PCU 839; script: MantisAI.cs; cost Iron 5447 Nickel 95 Cobalt 146 Silicon 50 Gold 54 Platinum 6

### Cradle Pod

Small-grid 4-slot drone cradle (merge blocks), Pod PB, two ConnectorMedium, batteries and reactors, backup timers; docks into the Warden / Leviathan hangars. Empty: drones are added by pasting them touching the merge blocks (designs/pods.py attach_drone). No propulsion.

* **Cradle Pod**: 605 blocks, 16518 kg, 19.0x5.5x7.5 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 1643; script: CradleBayAI.cs; cost Iron 16544 Nickel 200 Cobalt 12 Silicon 59 Silver 30 Stone 120
* **Cradle Pod Lite**: 605 blocks, 16518 kg, 19.0x5.5x7.5 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 1643; script: CradleBayAI.cs; cost Iron 16544 Nickel 200 Cobalt 12 Silicon 59 Silver 30 Stone 120

Note: Paste next to a large hangar and dock the two connectors (or paste the Warden, which carries it docked). Merge-block clamp face and the connector lock at paste are unverified (docs/design/ships/Pod.md, C1..C4).

### Shrike

Delta-wing fighter (small grid, 17 m): one pilot in a fighter cockpit, one Programmable Block "[Helm] Shrike" (ShrikeAI.cs), Remote Control, two autocannons + two gatlings (battery [B1]) and an assault cannon ([B2]) fixed forward, eight large hydrogen thrusters on three full tanks (16 m/s2 forward and back, 8 m/s2 up / down / sideways), six gyros, two charged batteries, two uranium reactors, six cameras, antenna, dead-man timer. No drone bay. Limitation: the autocannons hold 3 magazines (19 s of fire) and the assault cannon 3 shells; the 12 + 10 spare magazines in the nose container touch the guns exactly as the owner's Pod Chaser layout does, but whether that feeds them is untested in game.

* **Shrike**: 1278 blocks, 59318 kg, 15.5x7.0x17.5 m, accel F16.2 B16.2 U8.1 D8.1 L8.1 R8.1 m/s2, PCU 2864; script: ShrikeAI.cs; cost Iron 63516 Nickel 2680 Cobalt 1347 Silicon 1010 Silver 30 Stone 120
* **Shrike Lite**: 1273 blocks, 58743 kg, 15.5x7.0x17.5 m, accel F16.3 B16.3 U8.2 D8.2 L8.2 R8.2 m/s2, PCU 2779; script: ShrikeAI.cs; cost Iron 62934 Nickel 2450 Cobalt 1347 Silicon 1001 Silver 30 Stone 120

### Corsair

Catamaran-hammerhead corvette (small grid, 33 m x 26.5 m x 12 m): charcoal hull with orange accents, hammer crossbar at the bow carrying two assault cannons and two autocannons, a dorsal ridge with two small railguns (B1), a stepped bridge tower with the cockpit, four point-defence gatling turrets and an assault turret (Full), 14 large hydrogen thrusters on 10 full tanks (7.1 m/s2 forward, 3.6 m/s2 in the other directions), 40 gyros, a 14.75 MW reactor and four charged batteries, three Programmable Blocks ("[Helm] Corsair", "[Staff] Corsair", "[Bay] Corsair" for the cradles), dead-man timer, hand-flyable. Two cradle pods on outrigger pylons, each a 9 x 8 x 9 cell bay for a Hornet-class drone (Hornet, Wasp, Watcher, Harrier, Lancer, Aegis), nose forward, 24-cell launch lane; the bay merge blocks are "[SH] [Bay n] Merge ...". Limitation: the assault cannons hold 3 shells, the autocannons 3 clips (48 rounds) and the railguns 6 slugs; there is no conveyor feed (port positions are not known), so those guns run dry after a short fight. Paste it empty and add drones by hand, or use Corsair Wing.

* **Corsair**: 6601 blocks, 279167 kg, 26.5x12.0x33.0 m, accel F6.9 B3.4 U3.4 D3.4 L3.4 R3.4 m/s2, PCU 11735; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 301682 Nickel 11315 Cobalt 6201 Silicon 1278 Gold 80 Silver 475 Stone 1900
* **Corsair Lite**: 6593 blocks, 270831 kg, 25.5x10.0x33.0 m, accel F7.1 B3.5 U3.5 D3.5 L3.5 R3.5 m/s2, PCU 10565; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 293853 Nickel 10845 Cobalt 6108 Silicon 1260 Gold 80 Silver 60 Stone 240

### Corsair Wing

Catamaran-hammerhead corvette (small grid, 33 m x 26.5 m x 12 m): charcoal hull with orange accents, hammer crossbar at the bow carrying two assault cannons and two autocannons, a dorsal ridge with two small railguns (B1), a stepped bridge tower with the cockpit, four point-defence gatling turrets and an assault turret (Full), 14 large hydrogen thrusters on 10 full tanks (7.1 m/s2 forward, 3.6 m/s2 in the other directions), 40 gyros, a 14.75 MW reactor and four charged batteries, three Programmable Blocks ("[Helm] Corsair", "[Staff] Corsair", "[Bay] Corsair" for the cradles), dead-man timer, hand-flyable. Two cradle pods on outrigger pylons, each a 9 x 8 x 9 cell bay for a Hornet-class drone (Hornet, Wasp, Watcher, Harrier, Lancer, Aegis), nose forward, 24-cell launch lane; the bay merge blocks are "[SH] [Bay n] Merge ...". Limitation: the assault cannons hold 3 shells, the autocannons 3 clips (48 rounds) and the railguns 6 slugs; there is no conveyor feed (port positions are not known), so those guns run dry after a short fight. Corsair Wing is the same ship with two Hornets already clamped in the cradles as separate CubeGrids (merge blocks touching, enabled). Paste risk C1 (grids_bays.md): whether the game merges the touching grids at paste time is untested; if the drones float free on paste, toggle the bay merge blocks Off/On, or paste Corsair and the drones separately. The drones add 2 x 4.4 t that the acceleration figures do not include.

* **Corsair Wing**: 6601 blocks, 279167 kg, 26.5x12.0x33.0 m, accel F6.9 B3.4 U3.4 D3.4 L3.4 R3.4 m/s2, PCU 11735; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 301682 Nickel 11315 Cobalt 6201 Silicon 1278 Gold 80 Silver 475 Stone 1900
* **Corsair Wing Lite**: 6593 blocks, 270831 kg, 25.5x10.0x33.0 m, accel F7.1 B3.5 U3.5 D3.5 L3.5 R3.5 m/s2, PCU 10565; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 293853 Nickel 10845 Cobalt 6108 Silicon 1260 Gold 80 Silver 60 Stone 240

### Warden

LARGE-grid frigate (about 85 x 27.5 x 40 m, 2.6 kt with ammunition): two large railguns (battery [B1]), two artillery and four assault turrets, eight gatling turrets for point defence, six decoys, a four-engine hydrogen stern (1 large + 3 small, 4 m/s2), 20 small hydrogen thrusters for the other axes, a bridge tower with cockpit, Remote Control and the Helm and Staff programmable blocks, and a belly hangar (8 doors) with a docked, empty 4-slot Cradle Pod for Hornet-class drones (own CubeGrid and Pod PB). Ammunition, uranium, hydrogen and batteries are pre-loaded; 101 junction blocks feed the thrusters and every turret from the tanks and two ammo lockers. Limits: the two railguns have no feed (6 slugs each, reload by hand from the lockers), the pod carries no drones, and nothing of this has been pasted in the game yet.

* **Warden**: 1220 blocks, 2758126 kg, 27.5x40.0x85.0 m, accel F3.8 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 9862; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 3036400 Nickel 166410 Cobalt 96228 Silicon 12416 Gold 660 Silver 3030 Stone 12000
* **Warden Lite**: 1215 blocks, 2747526 kg, 27.5x40.0x85.0 m, accel F3.8 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 9577; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 3026814 Nickel 165560 Cobalt 94908 Silicon 12396 Gold 600 Silver 3000 Stone 12000

Note: Large grid, paste only (delete the old blueprint folder first). Needs the Helm / Staff / Pod scripts for autonomous play (PBs stay empty until the script files exist); flyable by hand from the bridge cockpit. The pod is a second grid docked by two connector pairs: press Lock on both hangar connectors if it did not lock (docs/design/ships/Warden.md, C1..C4). Drones are added by pasting them against the pod's merge blocks.

### Warden Wing

The Warden with four Hornets already clamped in its pod (each stern merge block on a cradle merge block): launch them with `launch all` on the Staff PB. Adds 216 blocks and about 4,000 PCU to the empty Warden.

* **Warden Wing**: 1220 blocks, 2758126 kg, 27.5x40.0x85.0 m, accel F3.8 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 9862; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 3036400 Nickel 166410 Cobalt 96228 Silicon 12416 Gold 660 Silver 3030 Stone 12000
* **Warden Wing Lite**: 1215 blocks, 2747526 kg, 27.5x40.0x85.0 m, accel F3.8 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 9577; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 3026814 Nickel 165560 Cobalt 94908 Silicon 12396 Gold 600 Silver 3000 Stone 12000

Note: Large grid, paste only (delete the old blueprint folder first). Needs the Helm / Staff / Pod scripts for autonomous play (PBs stay empty until the script files exist); flyable by hand from the bridge cockpit. The pod is a second grid docked by two connector pairs: press Lock on both hangar connectors if it did not lock (docs/design/ships/Warden.md, C1..C4). Drones are added by pasting them against the pod's merge blocks.

### Leviathan

LARGE-grid dreadnought (about 222 x 72 x 42 m, 14 kt with ammunition): a stepped wedge with an armoured dorsal citadel and a glazed bridge tower, a forward main-battery spine of six large railguns (battery [B1]), eight artillery and twelve assault turrets on the flank ledges, twenty gatling turrets for point defence, four rocket turrets (Full only) and twelve decoys; four large hydrogen engines (2 m/s2 forward) and ten more large thrusters for the other axes, 144 gyros, one large and eight small reactors, 20 batteries, four hydrogen tanks, Helm and Staff programmable blocks, bridge cockpit, gunnery seat and Remote Control, and two flank hangars (eight doors each) with a docked, empty 4-slot Cradle Pod each (own CubeGrids and Pod PBs, room for 8 Hornet-class drones). Ammunition, uranium, hydrogen and batteries are pre-loaded and about 270 junction blocks feed the thrusters and the artillery / assault / rocket turrets from the tanks and four ammo lockers. Limits: the six railguns have no feed (6 slugs each, reload by hand from the lockers), the pods carry no drones, about 33,000 PCU with the pods (worlds of 50 k or more; the doc lists what to drop for 20 k), and nothing of this has been pasted in the game yet.

* **Leviathan**: 8550 blocks, 14895816 kg, 72.5x42.5x222.5 m, accel F1.9 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 34251; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 16462454 Nickel 829930 Cobalt 486039 Silicon 13626 Gold 2060 Silver 14030 Stone 56000
* **Leviathan Lite**: 8534 blocks, 14877763 kg, 72.5x42.5x222.5 m, accel F1.9 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 33620; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 16445608 Nickel 828470 Cobalt 484719 Silicon 13605 Gold 2000 Silver 14000 Stone 56000

Note: Large grid, paste only (delete the old blueprint folder first). About 33,000 PCU with the two pods: needs a world limit of 50 k or more (docs/design/ships/Leviathan.md lists the trimming steps for 20 k). The Helm, Staff and Pod scripts are embedded in the PBs; flyable by hand from the bridge cockpit. Each pod is a second / third grid docked by two connector pairs inside its hangar: press Lock on the hangar connectors if a pod did not lock. Drones are added by pasting them against the pods' merge blocks.

### Leviathan Wing

The Leviathan with eight Hornets already clamped, four in each hangar pod: launch them with `launch all` on the Staff PB (the second pod follows the first by 20 s). Adds 432 blocks and about 8,000 PCU to the empty Leviathan (about 41,000 PCU in all: a world limit of 50 k or more).

* **Leviathan Wing**: 8550 blocks, 14895816 kg, 72.5x42.5x222.5 m, accel F1.9 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 34251; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 16462454 Nickel 829930 Cobalt 486039 Silicon 13626 Gold 2060 Silver 14030 Stone 56000
* **Leviathan Wing Lite**: 8534 blocks, 14877763 kg, 72.5x42.5x222.5 m, accel F1.9 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 33620; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 16445608 Nickel 828470 Cobalt 484719 Silicon 13605 Gold 2000 Silver 14000 Stone 56000

Note: Large grid, paste only (delete the old blueprint folder first). About 33,000 PCU with the two pods: needs a world limit of 50 k or more (docs/design/ships/Leviathan.md lists the trimming steps for 20 k). The Helm, Staff and Pod scripts are embedded in the PBs; flyable by hand from the bridge cockpit. Each pod is a second / third grid docked by two connector pairs inside its hangar: press Lock on the hangar connectors if a pod did not lock. Drones are added by pasting them against the pods' merge blocks.

### Aegis Shipyard

2 bays, prints Aegis escorts (4 gatlings, decoys).

* **Aegis Shipyard**: 333 blocks, 21579 kg, 22.0x7.5x12.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4738, 2 bays / 24 welders; script: AegisAI.cs, HiveMotherAI.cs; cost Iron 21872 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Aegis Shipyard Lite**: 301 blocks, 20881 kg, 21.0x7.5x11.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4688, 2 bays / 24 welders; script: AegisAI.cs, HiveMotherAI.cs; cost Iron 21164 Nickel 340 Cobalt 120 Silicon 43 Gold 12 Platinum 5

### Escort Carrier

Hornet bays + heavy armour, 4 fixed gatlings and the turret-target relay.

* **Escort Carrier**: 326 blocks, 47702 kg, 20.0x7.5x11.0 m, accel F0.9 B0.9 U0.9 D0.9 L0.9 R0.9 m/s2, PCU 5337, 2 bays / 24 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 52326 Nickel 3115 Cobalt 1815 Silicon 56 Gold 18 Platinum 7
* **Escort Carrier Lite**: 311 blocks, 44895 kg, 21.0x7.5x10.5 m, accel F1.0 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 4782, 2 bays / 22 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 49310 Nickel 2940 Cobalt 1740 Silicon 43 Gold 18 Platinum 7

### Fleet Forge

mixed bays: 2 Gnats on top, a Hornet and a Watcher in front.

* **Fleet Forge**: 424 blocks, 30368 kg, 14.5x12.5x17.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 7277, 4 bays / 38 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 30874 Nickel 510 Cobalt 180 Silicon 60 Gold 18 Platinum 7
* **Fleet Forge Lite**: 377 blocks, 27228 kg, 10.0x11.5x16.0 m, accel F1.6 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 6467, 4 bays / 33 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 27662 Nickel 450 Cobalt 180 Silicon 48 Gold 18 Platinum 7

### Harrier Forge

2 bays, prints Harrier interceptors.

* **Harrier Forge**: 303 blocks, 20979 kg, 18.5x8.0x12.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4708, 2 bays / 24 welders; script: HarrierAI.cs, HiveMotherAI.cs; cost Iron 21242 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Harrier Forge Lite**: 256 blocks, 18267 kg, 15.5x8.0x13.0 m, accel F1.6 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 4047, 2 bays / 20 welders; script: HarrierAI.cs, HiveMotherAI.cs; cost Iron 18468 Nickel 300 Cobalt 120 Silicon 41 Gold 12 Platinum 5

### Hive Mother

2 bays, prints Gnats (swarm drone).

* **Hive Mother**: 221 blocks, 15055 kg, 10.0x11.0x5.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 3136, 2 bays / 14 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 15140 Nickel 250 Cobalt 120 Silicon 49 Gold 12 Platinum 5
* **Hive Mother Lite**: 205 blocks, 13820 kg, 10.0x10.0x5.5 m, accel F2.1 B2.1 U2.1 D2.1 L2.1 R2.1 m/s2, PCU 2804, 2 bays / 12 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 13892 Nickel 220 Cobalt 120 Silicon 38 Gold 12 Platinum 5

### Hornet Forge

2 bays, prints Hornets (twin gatling fighters).

* **Hornet Forge**: 313 blocks, 21179 kg, 20.0x7.5x11.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4718, 2 bays / 24 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 21452 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Hornet Forge Lite**: 301 blocks, 20024 kg, 21.0x7.5x10.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4390, 2 bays / 22 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 20288 Nickel 320 Cobalt 120 Silicon 42 Gold 12 Platinum 5

### Lancer Foundry

2 bays, prints Lancers (autocannons).

* **Lancer Foundry**: 329 blocks, 21499 kg, 20.0x7.5x12.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4734, 2 bays / 24 welders; script: HiveMotherAI.cs, LancerAI.cs; cost Iron 21788 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Lancer Foundry Lite**: 323 blocks, 21321 kg, 21.0x7.5x11.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4710, 2 bays / 24 welders; script: HiveMotherAI.cs, LancerAI.cs; cost Iron 21626 Nickel 340 Cobalt 120 Silicon 43 Gold 12 Platinum 5

### Longbow Foundry

2 big bays, prints Longbow S railgun snipers (docking stalk added by printer_lib.with_latch).

* **Longbow Foundry**: 298 blocks, 20879 kg, 16.5x12.5x9.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4703, 2 bays / 24 welders; script: HiveMotherAI.cs, LongbowSniperAI.cs; cost Iron 21136 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Longbow Foundry Lite**: 318 blocks, 21221 kg, 17.5x12.0x9.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4705, 2 bays / 24 welders; script: HiveMotherAI.cs, LongbowSniperAI.cs; cost Iron 21522 Nickel 340 Cobalt 120 Silicon 43 Gold 12 Platinum 5

### Mantis Foundry

2 bays, prints Mantis hybrids (railgun + gatling; docking stalk added).

* **Mantis Foundry**: 331 blocks, 21539 kg, 19.5x15.5x8.5 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4736, 2 bays / 24 welders; script: HiveMotherAI.cs, MantisAI.cs; cost Iron 21830 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Mantis Foundry Lite**: 339 blocks, 21641 kg, 18.5x13.5x8.5 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4726, 2 bays / 24 welders; script: HiveMotherAI.cs, MantisAI.cs; cost Iron 21962 Nickel 340 Cobalt 120 Silicon 43 Gold 12 Platinum 5

### Mobile Hive

4 Gnat bays and 4 ion thrusters per direction: keeps up with its brood.

* **Mobile Hive**: 361 blocks, 25430 kg, 10.0x11.0x15.5 m, accel F2.3 B2.3 U2.3 D2.3 L2.3 R2.3 m/s2, PCU 5790, 4 bays / 28 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 25752 Nickel 410 Cobalt 240 Silicon 56 Gold 24 Platinum 10
* **Mobile Hive Lite**: 338 blocks, 23198 kg, 10.0x12.0x15.0 m, accel F2.5 B2.5 U2.5 D2.5 L2.5 R2.5 m/s2, PCU 5153, 4 bays / 24 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 23482 Nickel 360 Cobalt 240 Silicon 44 Gold 24 Platinum 10

### Quad Hive

8 compact bays in a 4x2 array, prints Gnats.

* **Quad Hive**: 589 blocks, 42110 kg, 20.0x11.0x15.5 m, accel F1.0 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 10716, 8 bays / 56 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 42976 Nickel 730 Cobalt 180 Silicon 70 Gold 18 Platinum 7
* **Quad Hive Lite**: 542 blocks, 37684 kg, 20.0x12.0x15.0 m, accel F1.1 B1.1 U1.1 D1.1 L1.1 R1.1 m/s2, PCU 9459, 8 bays / 48 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 38450 Nickel 640 Cobalt 180 Silicon 56 Gold 18 Platinum 7

### Static Nest

6 Gnat bays, no thrusters: a stationary hive (still a DYNAMIC grid; never convert it to a station).

* **Static Nest**: 453 blocks, 31209 kg, 15.0x10.0x15.5 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 8000, 6 bays / 42 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 31866 Nickel 570 Silicon 63
* **Static Nest Lite**: 417 blocks, 27860 kg, 15.0x11.0x15.0 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 7052, 6 bays / 36 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 28446 Nickel 500 Silicon 50

### Stinger Rack

RACK MODE: 4 Stingers stay docked; one is released per enemy sighting and told to launch.

* **Stinger Rack**: 352 blocks, 24038 kg, 12.5x9.5x18.0 m, accel F1.2 B1.2 U1.2 D1.2 L1.2 R1.2 m/s2, PCU 5649, 4 bays / 28 welders; script: HiveMotherAI.cs, StingerAI.cs; cost Iron 24400 Nickel 410 Cobalt 120 Silicon 56 Gold 12 Platinum 5
* **Stinger Rack Lite**: 350 blocks, 23940 kg, 11.5x11.5x14.5 m, accel F1.2 B1.2 U1.2 D1.2 L1.2 R1.2 m/s2, PCU 5629, 4 bays / 28 welders; script: HiveMotherAI.cs, StingerAI.cs; cost Iron 24322 Nickel 400 Cobalt 120 Silicon 46 Gold 12 Platinum 5

### Twin Hive

4 bays in a 2x2 array, prints Gnats.

* **Twin Hive**: 349 blocks, 23978 kg, 10.0x11.0x15.5 m, accel F1.2 B1.2 U1.2 D1.2 L1.2 R1.2 m/s2, PCU 5646, 4 bays / 28 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 24336 Nickel 410 Cobalt 120 Silicon 56 Gold 12 Platinum 5
* **Twin Hive Lite**: 326 blocks, 21746 kg, 10.0x12.0x15.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 5009, 4 bays / 24 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 22066 Nickel 360 Cobalt 120 Silicon 44 Gold 12 Platinum 5

### Wasp Foundry

2 bays, prints Wasps (rocket launchers).

* **Wasp Foundry**: 313 blocks, 21179 kg, 20.0x7.5x11.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4718, 2 bays / 24 welders; script: HiveMotherAI.cs, WaspAI.cs; cost Iron 21452 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Wasp Foundry Lite**: 301 blocks, 20024 kg, 21.0x7.5x10.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4390, 2 bays / 22 welders; script: HiveMotherAI.cs, WaspAI.cs; cost Iron 20288 Nickel 320 Cobalt 120 Silicon 42 Gold 12 Platinum 5

### Watcher Pad

2 bays, prints unarmed Watcher scouts (feed the HORNET hive).

* **Watcher Pad**: 319 blocks, 21299 kg, 20.0x7.5x11.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4724, 2 bays / 24 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 21578 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Watcher Pad Lite**: 283 blocks, 18807 kg, 17.0x8.5x10.5 m, accel F1.5 B1.5 U1.5 D1.5 L1.5 R1.5 m/s2, PCU 4074, 2 bays / 20 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 19034 Nickel 300 Cobalt 120 Silicon 41 Gold 12 Platinum 5


## Configure and command

Every script keeps its settings in the Programmable Block's **Custom Data** (ini; written on first run, edit and run `reload`).
Commands go in the PB's *argument* (run the PB with the text, or use a toolbar slot / button panel) or arrive over IGC on `<IGC Tag>_CMD`.
Printed drones start in IDLE and wait for the printer's `_JOIN`; a drone pasted by hand needs `guard` or `hunt`.
Printers: put the component stock in the `[Stock]` cargo or the welders, then run the printer PB with `start`.

### AegisAI.cs (v2.6-aegis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Extra Home Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Max Fire Range vs Huge Grids`, `Standoff Range vs Huge Grids`, `Standoff Range`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Screen Distance From Carrier`, `Carrier Radius`, `Hold Radius`, `Tether Radius`, `Target Missiles`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### BasiliskAI.cs (v2.6-basilisk)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Rocket Velocity Model (CAPPED/NONE/FULL)`, `Aim Margin (predicted misses)`, `Max Fire Range`, `Max Flight Time`, `Max Fire Range vs Huge Grids`, `Max Flight Time vs Huge Grids`, `Standoff Range vs Huge Grids`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range vs Small Grids`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Wingmate Close Separation Range`, `Wingmate Close Separation Speed`, `Take Over From AI When A Wingmate Is Closer Than (m; 0 off)`, `Wingmate Separation Hold (s)`, `Fire Window Multiplier`, `Fire Window Multiplier (unlimited rockets)`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Cone (deg)`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Dash Only While Recent Hits Below`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### CradleBayAI.cs (v1.0)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `release`: printers: `release [bay]` release finished drones; warship Staff / bay PBs: `release <n|a-b|all> [delay_s] [force]` let go of clamped drones (waits for a calm ship unless `force`)
* `hold`: `hold <bay>` keep a bay paused
* `unhold`: `unhold <bay>` resume a bay
* `recall`: warship Staff / bays: wing rtb, then satellite, bays cancel and re-open
* `reload`: re-read Custom Data and re-scan blocks
* `status`: refresh the screen

Custom Data `[Pod]` keys: `Tag`, `First Bay`, `Slots`, `Charge Fraction`, `Wave Gap`, `Arm Seconds`, `Fused Grace`, `Cooldown`, `Wait Max`, `Max Turn`, `Max Accel`, `Join Seconds`, `Lane Check`, `Lane Cells`, `Match Radius`, `Fleet Channel`, `Fleet Secret`.

Custom Data `[Hive Mother]` keys: `Note`.

Custom Data `[Bay N]` keys: `Merge`, `Timer`, `Drone Prefix`, `Drone Tag`, `Away`, `Away X`, `Away Y`, `Away Z`, `Drone Box Min`, `Drone Box Max`.


### GnatSwarmAI.cs (v1.13+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `form`
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `attack`
* `hunt`: chase and engage any target, actively scan
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (FORM/ATTACK/IDLE)`, `Projectile Speed`, `Fire Range`, `Closing Speed`, `Run-in Start Range`, `Back-off Speed`, `Orbit Speed`, `Back-off Range`, `Re-close Range`, `Emergency Break Range`, `Attack Cone Degrees`, `Max Sideways Drift m/s`, `Formation Radius`, `Satellite Distance (m)`, `Satellite Orbit Period (s)`, `Separation Radius`, `Engage Radius From Home`, `Combat Speed`, `Cruise Speed`, `Velocity Gain`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `RTB Battery Fraction`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Lead Scale (1 = calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false = focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire (s)`, `Raid Fan Half-angle Degrees`, `Raid Scan Cone Degrees`, `Raid Scan Ray Length`, `Raid Speed`, `Raid Max Travel`, `Raid Bearing Memory Seconds`, `Raid Start Confidence`, `Raid Hold Confidence`, `Listen To IGC Tags (target feeds)`, `Scan Range`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`.


### HarrierAI.cs (v2.6-harrier)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Small Target Standoff Fraction`, `Target Priority Small Bonus`, `Target Priority Large Penalty`, `Target Priority Fast Closer Bonus`, `Target Priority Missile Bonus`, `Target Missiles`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### HiveMotherAI.cs (v2.2)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `start`: start printing
* `stop`: stop printing, all welders off
* `max`: `max <n>` set Max Drones
* `release`: printers: `release [bay]` release finished drones; warship Staff / bay PBs: `release <n|a-b|all> [delay_s] [force]` let go of clamped drones (waits for a calm ship unless `force`)
* `hold`: `hold <bay>` keep a bay paused
* `unhold`: `unhold <bay>` resume a bay
* `relay`: `relay on|off` forward carrier turret targets
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Hive Mother]` keys: `Max Drones (all tags)`, `Rack Mode (keep docked, launch on targets)`, `Rack Launch Command Tag`, `Rack Target Tags (enemy sightings that release a drone)`, `Max Charge Seconds`, `Cooldown Seconds`, `Stall Warning Seconds`, `Build Timeout Seconds`, `Fault Retry Seconds`, `Parallel Builds`, `Recompile Drone PB Before Release`, `Recompile Wait Seconds`, `Release Nudge Seconds`, `Release Nudge Power (0-1)`, `Release Gap Seconds`, `Drone Match Radius m`, `Finish Timeout Seconds`, `Finish Fallback Seconds (used only without Drone Box keys)`, `Arm Max Seconds`, `Join Seconds (join is re-sent every 2 s, minimum 30)`, `Fused Grace Seconds`, `Launch Burst Seconds`, `Fleet Channel (join command for freshly released drones, blank = off)`, `Fleet Secret`, `Relay Turret Targets To All Tags`, `Auto Start`.

Custom Data `[Bay N]` keys: `Tag`, `Prefix`, `Max Alive`, `Max Prints`, `Hold`, `Exit Direction (printer axis the drone leaves along, blank means straight away from the merge block)`, `Skip Finish Check`, `Launch Burst Seconds`, `Drone Cell Count`, `Drone Cell Tolerance`, `Drone Box Min`, `Drone Box Max`, `Ignore Cells`.


### HornetDroneAI.cs (v2.6-hornet)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LancerAI.cs (v2.6-lancer+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Burst Seconds`, `Burst Pause`, `Conserve Below Shells`, `Conserve Max Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LongbowSniperAI.cs (v2.4)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### MantisAI.cs (v2.6-mantis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Engage Cap`, `Use Gatling`, `Gatling Projectile Speed`, `Gatling Range`, `Gatling Fire Window Multiplier`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### ShrikeAI.cs (v0.1-shrike)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `manual`: warship Helm: the ship is hand-flown (nothing of the script touches thrusters or gyros)
* `auto`: warship Helm: the script flies again even with a pilot aboard
* `pilot`: warship Helm: toggle manual / auto
* `assist`: you fly, the script aims and fires
* `guard`: hold the home point, engage anything inside Guard Radius
* `react`
* `hunt`: chase and engage any target, actively scan
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[M]` keys: `Seat Debounce`, `Release Delay`, `Assist (OFF/HUD/FBW)`, `Assist Max Rate`, `Pilot Rate Gain`, `Pilot Rot Sign`, `Rotation Input Scale`, `Pilot Priority Rate`, `Auto Fire In Manual`, `Scan In Manual`, `Run Menu`, `Run Menu Wait`, `Deadman Timer Name`, `Seat Exclude (name part)`, `HUD Surface`.

Custom Data `[Fleet]` keys: `Primary (AUTO/B1..B4)`, `Standoff By Weapons`, `Turret Only (AUTO/ON/OFF)`, `Auto Max Turn (AUTO/ON/OFF)`, `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Max Fire Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Auto Camera Scan`, `Share Targets Over IGC`, `Friendly Fire Check`, `Fire Window Multiplier`, `Listen To IGC Tags (target feeds)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `AI Block Search Assist`, `Max Turn Rate rad/s`.

Custom Data `[Link]` keys: `Enable (AUTO/ON/OFF)`, `Ship Tag`, `Block Prefix`, `Heartbeat (s)`.


### StaffAI.cs (v1.4)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `wing`: warship Staff: `wing hunt|guard|rtb|follow|satellite|lock|roll` order the drones
* `page`: warship Staff: `page [1|2]` status / wing roll call on the PB screen
* `fleet`: warship Staff: `fleet <command>` on the fleet channel
* `release`: printers: `release [bay]` release finished drones; warship Staff / bay PBs: `release <n|a-b|all> [delay_s] [force]` let go of clamped drones (waits for a calm ship unless `force`)
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `dock`
* `deploy`
* `hold`: `hold <bay>` keep a bay paused
* `unhold`: `unhold <bay>` resume a bay
* `recall`: warship Staff / bays: wing rtb, then satellite, bays cancel and re-open
* `doors`: warship Staff: `doors open|close` the hangar doors
* `reload`: re-read Custom Data and re-scan blocks
* `status`: refresh the screen

Custom Data `[Fleet]` keys: `Ship Tag`, `Block Prefix`, `Pod Gap (s)`, `Door Open Wait (s)`, `Door Close After (s)`, `Recall Satellite After (s)`, `Trip Time (s)`, `Watch Helm`, `Cockpit Surface`, `Helm HUD Surface`, `Run Menu`, `Run Menu Wait`, `Display Name`, `Wing Surface`, `Wing Display Name`, `Turret Target Group`, `Turret Target Names`.

Custom Data `[Wing]` keys: `Types`.


### StingerAI.cs (v1.1)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `abort`: abort and release
* `disarm`: disarm the warheads
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `Listen To IGC Tags`, `Own Command Tag`, `Auto Launch When Released`, `Max Target Distance`, `Arm Warheads Within`, `Never Arm Within This Of Launch Point`, `Max Speed`, `Target Large Grids`, `Target Small Grids`, `Target Neutral/Unowned`.


### WaspAI.cs (v2.6-wasp+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Rocket Velocity Model (CAPPED/NONE/FULL)`, `Aim Margin (predicted misses)`, `Max Fire Range`, `Max Flight Time`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Jink Gate Radius Factor`, `Jink Gate Min Miss (m)`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range`, `Standoff Range (unlimited rockets)`, `Max Fire Range (unlimited rockets)`, `Max Flight Time (unlimited rockets)`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Boresight Rays (of 8)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `AI Confirm Cone Yaw (deg)`, `AI Confirm Cone Pitch (deg)`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### GnatMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.

### HornetMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.

### LongbowMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.


## Known unknowns

- **Merge-block clamp face (unverified).** The small 1x1x1 merge block (`SmallShipSmallMergeBlock`) clamps toward its local **Up** face (one wiki source); the old assumption was Right. Every merge pair in this package is built on that. It is one constant (`MERGE_CLAMP_FACE_SMALL` in `tools/designs/_common.py`); if the merge-face test (T1) shows another face, change it and run `tools/build_all.py` again.
- **Lite variants keep the small merge block.** Its XML shape comes from the Keen source, not from the Starburst reference, so strictly a Lite ship is not 100 % "seen" XML. A drone or printer without it cannot be printed or docked. `LITE_KEEPS_MERGE = False` in `_common.py` drops it from the drones.
- **XML shapes never seen in a game-written blueprint:** Sensor, the AI blocks (Offensive, Flight, Defensive), Decoy, large gatling turret, Timer and Event Controller toolbars. They are why Full variants exist next to Lite ones. Earlier blueprints with a Sensor or Custom Turret Controller failed to paste; the leading hypothesis is a missing `<Toolbar>` element (now always written), but that is not confirmed.
- **Projected Programmable Blocks.** A welded PB may keep its Program text but not start by itself. The printer script calls `ApplyAction("Recompile")` on it; whether that works is the projected-PB test (T5, T6).
- **No ammunition is pre-loaded** in any gun or launcher (the generator cannot write inventories). In a survival world load magazines / rockets by hand; in a creative world the guns may still need magazines unless the world has infinite ammunition switched on (test T8 shows which). Scripts treat an unknown ammo count as unlimited and never return to base for lack of ammo in that case.
- **Scripts have never run in the game with these versions.** They compile against a hand-written stub of the game API (`tools/compile_check.sh`), which proves syntax and types only.
- **Weapon numbers** come from the local game data (gatling 700 rpm, 800 m/s, 800 m; small rocket 500 damage, 4 m blast; small railgun 1000 m/s, 1400 m, 500 ms shot delay). Rockets are assumed (v2.3) to leave with the shooter's velocity plus their launch speed, accelerate along the barrel and have their total speed capped, so a rocket fired from a moving ship curves onto the barrel line (Keen bug tracker). Test 18 in the test list checks it; if your rockets fly dead straight from a ship moving sideways, set `Rocket Velocity Model=NONE` on the Basilisk and Wasp.
- **Gnat / Midge Lite** thrust only along the nose axis (two axial thrusters, steered by gyros). They have no lateral or vertical thrusters by design.
- **Wasp** relies on the terminal action `ShootOnce` (name from memory, unverified). If it is wrong the Wasp never fires. Its target-lead solver was checked numerically only.
- **Midge (experimental)** has no script and no Programmable Block. The AI-block XML is a guess and its settings (attack pattern, selected gun, AI Behavior switch) cannot be pre-set: configure it by hand once, see `Scripts/MidgeNotes.md`. **Midge Lite** is only the Gnat Lite frame renamed and still runs `GnatSwarmAI.cs`.
- **Basilisk** is a large-grid ship with no merge block; it cannot be printed (paste only). Longbow S / L have no docking face in the base model (printers add a docking stalk to Longbow S and Mantis).
- Scripts that were forked from the Hornet script (Wasp, Lancer, Harrier, Aegis, Mantis, Basilisk, Watcher) do not share later bug fixes automatically. A drone only joins the hive of another model if both use the same `IGC Tag`.
- **Fused grid (biggest risk).** Blocks welded from a projection become part of the *projector's* grid. After switching both merge blocks off the drone may still be on the printer's grid. `HiveMotherAI` checks this at run time; if the drone is still on the printer's grid it sets the bay to FAULT with a "FUSED" message and sends no `_JOIN`. The fused-grid test (P1) decides.
- **Welder reach is modelled, not measured:** the welder's work sphere centre comes from a model dummy we cannot read. v2.1 checks 8 guesses (centre at the tip face or 1 to 3 cells inside the welder, radius 1.3 m or 1.0 m); the outer hull is covered under all of them, deep core blocks (batteries, gyro, remote) only under the shallow ones. If the real centre is deeper, bays stall in FINISH with `N unfinished`, and the LCD lists which blocks.
- **Hornet-class drones need touching welders.** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis, Mantis and Longbow S are 6 to 7 cells across, so their interior blocks can only be reached by welders whose tips touch the drone surface (a welder tip has no mount point, so no block attaches, but the surfaces do touch). If touching causes a permanent merge, use the Gnat-class printers (Hive Mother, Twin Hive, Quad Hive, Mobile Hive, Static Nest, Stinger Rack), which keep a full cell of air.
- **No conveyors.** The component stock must sit in a cargo container touching a welder's port, or in the welders themselves. A creative world may not need components at all (unconfirmed). The components needed per drone are listed as comment lines at the top of the PB Custom Data.
- **Cargo containers** (Full printers) have a guessed shape and volume; the Escort Carrier Full also has a guessed `SmallGatlingTurret`. Lite printers have neither.
- **Stinger Rack** prints a minimal fallback Stinger (Gnat frame, two warheads, `StingerAI.cs`) because there is no dedicated Stinger design module.
- Printers are heavy (about 13 to 36 t) and slow to turn; the Static Nest has no thrusters at all (it is still a dynamic grid). Timer / Event-Controller printers ("Midge Nest" and friends) are **not** part of this release.
- **Power budget and run time (computed from `defs_stats.json`, not measured).** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis: 4 small batteries = 0.2 MWh and at most 0.8 MW output; the 12 thrusters could draw 2.4 MW, so a burn on all three axes at once is capped at about 67 % thrust, and a one-axis burn (2 thrusters, 0.4 MW) lasts about 30 minutes. Gnat and Midge Lite: 1 battery = 0.05 MWh and 0.2 MW, i.e. about 15 minutes with the one thruster at full power. Longbow S and Mantis: one 3x2x3 battery = 1 MWh, 4 MW. Longbow L: 12 MWh, 48 MW against 40 MW of thrusters. Power drawn by guns, railgun charging, antenna range and welders is not in the game files, so it is not in these figures. There is no generator or solar panel on any drone: once the batteries are empty the drone is dead weight (`RTB Battery Fraction` sends it home before that).
- **Space only.** Thrust is ion thrust with no gravity term: the best drones accelerate at 6 to 7 m/s2 (Harrier 12 m/s2 forward only), which is less than 1 g (9.81 m/s2), and ion thrusters lose most of their force in an atmosphere. None of these ships can lift off or hover over a planet. Use them in space or at the edge of low gravity. Masses are component masses only; magazines, rockets and cargo add weight.
- **A printed drone leaves with a nearly empty battery.** The CHARGE phase lasts at most `Max Charge Seconds` (default 25 s). A small battery charges at 0.2 MW, so 25 s adds only about 3 % of its 0.05 MWh; a full recharge of a Hornet's 0.2 MWh from the printer's 4 MW pack takes about 15 minutes. A freshly welded battery starts at its definition's initial charge (30 %, unverified for welded blocks), so expect a drone to leave with roughly one third of its endurance (about 10 minutes of one-axis burn for a Hornet class, 5 minutes for a Gnat). Raise `Max Charge Seconds` in the PB Custom Data if you can wait. Drones that return to the printer are not re-docked or recharged by the scripts.
- **PCU.** The table's PCU is the printer alone (welders cost 150 each). Every printed drone adds roughly 700 to 1,700 PCU, and every projected block counts 1 PCU while it is projected. A world with a low block limit (survival defaults) will refuse to paste a Quad Hive (8,381 PCU) or Static Nest (6,244 PCU).
- **AI Behavior switch from a script (unverified).** The Full drones' AI blocks paste with AI Behavior off. The scripts look for a bool terminal property whose id contains "Behavior" on each `[AI]` block and switch it on; the id is not documented (believed to be `ActivateBehavior`). The PB screen shows `AI Behavior on (N blocks)` when it found the switch, else `AI Behavior switch not found`: then switch it on by hand (see "AI blocks" above). Even switched on, the AI blocks keep their default settings (AI Flight speed limit 10 m/s, no weapon selected), which a blueprint cannot pre-set.
- **Camera-only search is weak.** Without working AI blocks (and on Lite variants) a drone finds enemies only with camera rays. In the simulator 3 Hornets with inert AI blocks found a pirate ship 700 m away in about 4 of 10 fights (was 1 in 40 before v2.1), mostly after it opened fire, and still lost most of those fights; with working AI blocks they found it within 3 s every time and won 3 of 4.
- **BREACH and SEEKER (v2.6) are sim-tested only.** BREACH assumes camera rays at a hull point come back deeper once blocks there die (true in the sim's block-exact raycast). SEEKER assumes `IMyLargeTurretBase.SetTargetingGroup("PowerSystems")` works from a script, that the game then aims the turret at a power block, and that `Vector3D.CreateFromAzimuthAndElevation(Azimuth, Elevation)` in the turret's frame is its barrel direction. Decoys pull the turret first. Test 23 checks all of it.
- **Script size headroom is small.** Minified, the Basilisk script is 97,721 of the 100,000 characters a Programmable Block takes (Wasp 95,313, Mantis 94,623). The build stops with an error when a script goes over; the next big feature will need code moved out or trimmed.
- **One Helm script for all four ships.** `ShrikeAI.cs` (a Hornet-derived script, 79,990 of its 80,000 characters) flies the 60-tonne fighter and the 14-kilotonne dreadnought alike; the large ships differ only by Custom Data (stand-off 700 / 800 m, jinking off, `AI Block Search Assist` off, stand-off from the weapons off). A `HelmAI.cs` for the large ships was not needed in the sim; whether the game's gyro and thruster response lets the same controller settle on a 14 kt hull is in-game test 35. The script has no room left (10 characters): the next feature must remove something (the AI-block support is the agreed first cut).
- **Instruction counts.** The sim counts a block model (Helm peak about 1,700) and a pessimistic IL model (Helm peak about 25,000 of 50,000, Staff 9,500, bay 15,700, Hornet 17,000). Which of the two the game's counter resembles is not known (test 30); the integrity scan is sliced for that reason.
- **Large-ship fights are optimistic in the sim.** Large thrusters and batteries die 1.6 to 5.9 times too slowly there, hydrogen is unlimited, there is no conveyor model (ammunition and fuel are "free"), the enemy ships are stand-ins (the Pirate brain), and the connector-docked pods are held rigidly to the host (RigidLink: no real connector, no pod mass). Kill times and win rates in `docs/design/ships/*.md` are for comparing settings, not for predicting the game.
- **Small drones are hard to find at long range.** The Helm confirms what the AI blocks see with camera rays; a 54-block Hornet is 0.1 to 0.4 degrees wide at 0.5 to 1 km, so a heavy ship that turns slowly finds small attackers late (the Shrike with one forward camera lost to a single Hornet 4 times out of 5; with two forward cameras 2 out of 5). Against several Hornets a single Shrike always lost in the sim (the old M3 result for any single fighter). Use turret ships (Warden, Leviathan) or a wing against drone swarms.
- **Lite Shrike and Lite Corsair do not find targets on their own.** Lite has no AI blocks, no sensor and (Corsair) no turrets, so autonomous search is the camera sweep only: in the sim `Shrike Lite` and `Corsair Lite` lost 0/3 to the Pirate without firing a shot (the nose camera is shot off first, the sweep turns the ship at 1 rad/s and rarely hits). Fly them (`lock` on a target gives the Helm one), or use the Full ships. `Warden Lite` and `Leviathan Lite` keep their turrets and won 3/3 vs the Pirate (Warden Lite, 64-80 s).

## In-game tests (do them in this order)

1. **World settings and cache (T13, T14).** "In-game scripts" on. Old blueprint folders deleted. Paste once with a stale `bp.sbcB5` left in a folder to see whether it matters. Decides: cause 1 of "script missing after paste".
2. **Paste the Lite twins first** (`Gnat Lite`, `Hornet Lite`, then the rest of the Lite set). Pass: it pastes, no floating blocks (cut one block with a grinder; thrusters, cameras, gyro, PB and antenna must stay), the PB's Edit window shows the code, its Custom Data shows the ini section, no DLC warning. Decides: the generator's basic XML (ComponentContainers, ModStorage custom data, orientation) is right.
3. **Paste the Full variants.** Same checks. If a Full ship fails and its Lite twin pastes, the unseen block shapes (Sensor, AI blocks, Decoy, cargo, turret) are the cause (T2, T11): send a Ctrl+B export of a small grid that holds one each of Timer, Sensor, Turret Controller, Event Controller, AI Offensive / Flight / Defensive, Merge Block, Projector, Welder, Warhead.
4. **Merge face (T1).** On two small grids put two `SmallShipSmallMergeBlock`s with their Up faces towards each other (and separately Right towards Right) and see which pair turns yellow / merges. Then check a drone's merge latch against a printer bay.
5. **Release (T3).** Merge two blocks; switch the drone-side one off, then the printer-side one off. Decides which side can release (needed by the printers; also by hand docking).
6. **Dynamic printer (T4).** Merge a dynamic printer with a drone and unmerge. Repeat with a static one if you want to see the trap.
7. **Pre-loaded projection.** In the printer, the projector must show the drone at the merge block (offset and rotation as generated), with Keep Projection on. Weld one block by hand and check the welded block lines up with the projection.
8. **Welder reach and finish (v2.1).** Switch on one bay and watch the printer LCD. After BUILD shows `0 left` it must show FINISH with a scan percentage, and the welders must keep running until it reads `0 unfinished`; only then CHARGE. The bay now checks 8 guesses for where the welder's work sphere is centred, so a stall means the real centre is deeper than all of them or a block is blocked. In the PB's Show on screen / the LCD, FINISH lists every unfinished block with its name, cell, integrity % and distance to the nearest welder, plus any welder that is off, damaged or unpowered, and `[Stock]` empty. Weld range cannot be seen in game (no Show Tool Range for welders), so measure it instead: with one welder alone (no scripts), put the tip against a single projected armour cube and note whether it builds at 0, 0.5 and 1.0 m in front of the tip. If a block stays unwelded, report: the block name and cell from the LCD line, the nearest welder's name and the distance shown, the bay's `Exit Direction`, the model, and whether the LCD said `no Drone Box keys`, `none buildable (unsupported)` or `buildable but not welded`.
9. **Projected PB (T5, T6).** After the build, open the welded drone's PB: does the Edit window hold the code, does it run, who owns it (and `GetOwnershipFromProjector`)? Does the printer's `Recompile` fix an uncompiled one?
10. **Fused grid (P1).** Weld one drone, switch both merge blocks off, look at the Info / grid list: is the drone a separate grid? If not, the bay shows FAULT "FUSED" and the printer concept needs another way to cut the drone loose.
11. **Full cycle on Hive Mother.** Creative world, stock present: `start`; watch BUILD, CHARGE, RELEASE; the drone should receive `<Tag>_JOIN` and start working. Then `max`, `hold`, `release` commands.
12. **Weapon and ammo behaviour (T8, T9).** Fire each gun class once with an empty inventory (creative vs survival), time the small railgun's trigger-to-impact (Longbow, Mantis), check that Wasp rockets launch (`ShootOnce`) and where they go relative to the moving shooter.
13. **Scriptless Midge (T7).** Configure the AI blocks by hand as in `MidgeNotes.md`, switch AI Behavior on, check that it flies and fires. Send a Ctrl+B export of the configured Midge so the generator can copy the real AI-block XML.
14. **Gyro sign (T10), only for new scripts.** Flight and aim of the Hornet / Longbow scripts worked in earlier tests; confirm the same for Wasp / Lancer / Harrier / Aegis / Mantis (nose turns onto a stationary target).
15. **Runtime and IGC limits (T12).** Print `Runtime.MaxInstructionCount` on a PB; send an IGC test message between two antenna ships at 1 km and 10 km. Decides whether hive messages reach as far as the Watcher's 5000 m antenna implies.
16. **AI Behavior switch (v2.1).** Paste a Full Hornet, run `guard`, read the PB screen: `AI Behavior on (2 blocks)` means the script could switch the AI blocks on (check the AI Flight / AI Offensive terminal: AI Behavior ticked). `AI Behavior switch not found` means switch it on by hand (README "AI blocks"). Then put a pirate or enemy-faction ship 700-1500 m away and watch whether the drone turns to it within a few seconds (`AI: searching`, then `Target:`). Send the PB screen text either way.
17. **FOLLOW (v2.2).** Put `HornetMothership.cs` (any link) on a PB of your ship (with an antenna), paste 2-3 Hornets near it, run `follow` on each. Read a drone's PB screen: `Follow : ship ... m away`. Fly straight, turn, stop: the drones should keep a ring about 60 m behind you and never touch the hull. Then get out next to a Full drone: its screen should switch to `Follow : on foot`. Send the PB screen text and how far they lagged at your top speed.
18. **Rocket flight from a moving ship (v2.3).** Fly a Wasp or Basilisk sideways (strafe, nose still) at 50 m/s or more and fire one rocket (`ShootOnce`) at nothing. Watch it from the cockpit: if it **bends** onto the line straight ahead of the launcher, the default `Rocket Velocity Model=CAPPED` is right; if it flies **dead straight ahead** with no sideways drift, set `NONE`; if it keeps **drifting sideways** at your strafe speed all the way, set `FULL` (Custom Data of the Basilisk and Wasp, then `reload`). Then, against an AI ship with evasive manoeuvres on, read the PB screen's `Lead` line (`acc a/m for N s`: the target's acceleration and how long the solver holds it) and report roughly how many rockets hit.
19. **Kamikaze defence (v2.4).** Two Hornets (or any combat drones) in `hunt`, and 3-4 armed Stingers of another faction launched at them from about 1.5 km (`launch` on the Stingers; give them a target by locking it from a Hornet of their own side, or start them within 50 m sensor range). Watch the drones' PB screens: `!! KAMIKAZE` should appear, the drones should back away while firing and sidestep at the last moment. Report how many Stingers were shot down, how many exploded near a drone, and the PB screen text.
20. **Finish check can be broken on purpose (v2.4).** In FINISH switch one welder off by hand: it must come back on within about a second and the stall text must name it. Empty `[Stock]` during FINISH: the LCD must ask for a refill and not FAULT; refill and it continues. Delete the `Drone Box Min/Max` keys from `[Bay N]`: the LCD must warn `no Drone Box keys` and the finish waits 90 s. Report the LCD text if any of these fail.
21. **Automatic take-off (v2.4).** Print one drone and do nothing else. After the release it must burn away from the printer for a few seconds and then switch to GUARD (the PB screen shows `Launch: took off (...)`). Then repeat three times while the drone is still docked: set Custom Data `[Launch] Auto=false` and run PB argument `launch` after the merge opens; recompile the drone PB after the release; switch the printer's `_JOIN` off. In each case the drone should still leave. Read the drone PB Custom Data before separation (`release 1`): it must contain `[Launch]` with `Armed=true` and `Away X/Y/Z`. If the drone sits still, report the Custom Data and the PB screen text.
22. **Launch direction and Gnat (v2.4).** Check the burn goes along the bay's `Exit Direction` / Away X/Y/Z and not into the printer, for the Longbow S and Mantis docking stalk faces. Gnat only thrusts forward and back, so on a Hive Mother bay check that a printed Gnat really leaves; if it hangs beside the printer, report the bay's Exit Direction and Away values.
23. **Disarm (v2.4).** A drone merged on purpose to something else (carrier hangar) must not launch until the merge is released; run PB argument `disarm` to cancel auto-launch, `armed` to re-arm.
24. **SEEKER / subsystem targeting (v2.6, option 4).** You need an ENEMY grid with power blocks (its own turrets may be switched off). (a) Put `SeekerProbe.cs` on any PB of a ship with a turret (name the turret `[Seeker]`), run it, fly within the turret's range of an enemy ship. Read the PB screen: `group PowerSystems` (else `SET FAILED: ...`), `target ...`, `hitpos N m from centre` or `no hitpos`, `aim line passes N m from centre`, `hull hit N m from centre`. Run `group Weapons` and `group Propulsion` too. Copy the Custom Data log. (b) Paste a **Longbow L Seeker** (load artillery shells into its turret) 1.5-2 km from an enemy ship and `hunt`: its PB screen shows `Aim: BREACH ... (seeker)` and `Seek: ...`. Note whether the target has decoys. Send both screens/logs. Decides whether option 4 can work at all, and whether the game gives the block position directly (`hitpos`).
25. **Cradle bays, first contact (C0/T1, C1).** Paste `Cradle Pod Test`-style geometry: a Corsair Wing or a Cradle Pod with a Hornet pasted against a cradle merge block. Terminal: is it ONE grid (clamped) or two? If two, switch the host merge block Off and On from the terminal; if still two, the clamp face is wrong (`MERGE_CLAMP_FACE_SMALL`). Then PB argument `status` on the Pod PB / `[Bay] Corsair`: the screen must show `Bay 1 DOCKED HORNET 100%`; `EMPTY` with `merge open, no drone (C1...)` means the paste did not lock. Send the screen text and the grid list.
26. **Cradle release by hand (C5).** On the Pod PB / `[Bay] Corsair` run `release 1`. Expected: the PB screen goes ARMING -> RELEASED -> COOLDOWN within about a second, the drone's PB shows `Launch: took off`, it burns forward 4 s along the lane and then GUARDs; the other drone stays. Look for damage to the rear wall (3 cells behind the stalk), the neighbouring drone, the merge block. Then `release all`: two drones 2 s apart. If the drone sits there: PB screen of the bay (`FUSED`?) and of the drone.
27. **Gates.** Turn the ship (or accelerate) and run `release 1`: the bay must wait and say `waiting: ship turns ... rad/s` (limit 0.1) or `ship accelerates ... m/s2` (limit 1.0); `release 1 force` must go anyway. Put a block in the lane (or aim `Away`): `lane blocked at x,y,z`. Pasted drones start with the charge of the blueprint: if a drone battery is below 90 % the bay shows CHARGING and the batteries must read `Recharge`; they must charge from the pod's/ship's power (the sim never charges). Report what the screen says.
28. **Staff to pod across the connector (C3, C4).** Warden / Leviathan with the pod docked and both connector pairs locked: from the Staff PB run `release 1`. The Staff page shows `release 1: sent via ConnectedConstructs`, then `... AntennaRelay (try 2)`, `... unicast to the pod PB (try 3)`, then `the bays answered` or `NO BAY ANSWERED after 6 tries`. Report which try answered (that is the IGC result of C4); with a lost answer the hand launch is the Timer R(n) of the pod. Also: does the ship's Staff PB list the pod's blocks (`GridTerminalSystem` count with and without the pod, C3), and does the docked pod hold under 1 m/s2 for 30 s?
29. **Hangar doors (C8).** `doors open` / `doors close` on the Staff PB: time them (8 AirtightHangarDoors); then `release all`: the Staff opens the doors, waits for Open (up to 15 s), sends, and closes them 10 s after the last drone left. Report the open time and whether any door closed on a drone.
30. **Name-prefix rule (C10).** Corsair Wing with the two Hornets clamped and ShrikeAI/StaffAI in the Helm/Staff PBs: `Block Prefix=[SH]` is in their Custom Data (`[Link]` for the Helm, `[Staff]` for the Staff). Run `hunt` on the Helm (an enemy in sight, or `idle` and a hand-set target) and open the clamped Hornets' thrusters in the terminal: `Thrust Override` must stay 0 % and the Hornets' gyros must not be overridden. Then delete the prefix key and `reload` the Helm: the Hornets' thrusters/gyros now get overrides (that proves the clamped drones are blocks of the ship's grid in the game, too; switch it back). Also K3: the cockpit toolbar slot `Run` with the argument `release 1` while you sit in the seat.
31. **The warship scripts start and stay under the instruction limit (K11).** Open `[Helm]`, `[Staff]`, `[Bay]`/`[Pod]` PBs of each ship: ShrikeAI 0.1 / StaffAI 1.4 / CradleBayAI 1.0 on the PB screen, no `Script too complex`. Fly 5 minutes in `hunt` against something and watch the Helm's `Ins` line (it shows the peak per run): the sim's pessimistic IL model peaks at about 25,000 (Shrike, Warden) of the 50,000; if the real count is much higher the integrity scan (`CheckDamage`, 150 blocks per call) is the first thing to slow down.
32. **Sit down, stand up (K1, K2, K7).** Shrike first. MANUAL within about 0.4 s of sitting, no tug of war on the stick, the HUD pip on screen 0, the dampener switch as you left it; 1.5 s after standing up the Helm is back in its old mode and does not snap the nose. Then `assist fbw` with a lock; if the nose turns the wrong way flip `[Manual] Pilot Rot Sign`, scale with `Pilot Rate Gain` / `Rotation Input Scale`. Large ships: the Remote Control and the Gunnery Seat must NOT put the Helm into MANUAL.
33. **Run menu (K3).** Cockpit toolbar slot with `Run` on the Helm or Staff PB, no argument: each press steps the menu on the PB screen, the highlighted item runs 2 s after the last press. Then try a `Run` slot WITH an argument (Ctrl+B export, see whether the argument is saved).
34. **Dead-man in the game (K8).** Ship flying in `hunt`, switch the Helm PB off in the terminal: thrusters and gyros released within about 1.5 s (Staff), guns off, `HELM LOST` on cockpit screen 0, Timer `(deadman)` after 5 s. Switch it on again: `Helm back`. Repeat sitting in the seat: the Event Controller `EC Cockpit` (set its event by hand: cockpit occupied -> stop the timer, empty -> start) must start the timer when you leave.
35. **`launch all` in a fight.** Warden Wing / Corsair Wing with a target at 1-2 km: `launch all` on the Staff PB. The Helm goes idle (the ship stops turning), the doors open, the drones leave one by one, the Helm comes back to its mode. Then `wing satellite` (ring 100 m plus hull) and `wing hunt`. If the bays only say `waiting: ship turns ...` the ship does not settle (the Helm is not idle?); `release n force` is the manual override.
36. **Turn rate and braking of the large ships.** Time a 90 degree turn and the braking from 40 m/s: the sim says Warden 0.30 rad/s2 yaw (90 degrees in about 4.5 s with a 1.5 rad/s rate cap; `Max Turn Rate` is calibrated by the script from the first turns), Leviathan 0.04 rad/s2 (90 degrees in about 13 s), braking 1.7 / 1.0 m/s2 (Warden 24 s, Leviathan 40 s from 40 m/s). Large differences mean the gyro or thruster model is off; set `Max Turn Rate rad/s` and `Auto Max Turn (AUTO/ON/OFF)` by hand.

## Changelog

### v2.7 (unreleased): WARSHIPS Shrike, Corsair, Warden, Leviathan (new package `Warships_v2.7_Full` / `_Lite`)
- **Helm default mode REACT** (`ShrikeAI.cs`, mode 7 in the `.H2S` flags, `StaffAI.cs` shows it): combat-ready but passive until an AI alarm, a mate's alarm, damage or a held target wakes it. `Start Mode` default is REACT (the key name is unchanged). Four rarely used Custom Data keys were dropped to make room (`Target Large/Small Grids`, `Aim Kp/Kd`, `RTB Battery Fraction`); the Helm is 79,977 of 80,000.
- **Cockpit buttons `deploy` / `dock`** (Staff) on Warden, Leviathan and Corsair; the cradle bay PB keeps a docked drone's thrusters off and switches them on at release.
- **Walkways and entry** (Warden, Leviathan; Shrike and Corsair are cockpit-only): slide doors (`LargeBlockSlideDoor`, seen in the Tech Hunter sample) in both sides of the tower stem lead to a one-cell passage and shaft to the bridge and, on the Warden, through the hangar roof; the Leviathan also has a door into each hangar. `carve_walkway` / `route_walkway` / `walk_check` in `designs/_common.py` (the build asserts a walk from the outside door to the bridge and hangars).
- **Gravity generator** (large `GravityGenerator`, 1 g toward the ship's down, field over the crew spaces) on Warden and Leviathan Full (the Lite variants keep no unseen shape). Large grid only: the small-grid Corsair cannot carry one. The object-builder fields (`FieldSize`, `GravityAcceleration`) were never seen in a game file.
- **Round slopes / corners** in the concave edges of the big Leviathan rooms (`chamfer_room`); the Warden's rooms are too cramped to take any.
- **`<ConveyorLines>`** are now written for every face-adjacent ported pair (junction cubes, thrusters on tanks / junctions, turret / tank / locker terminals), as the game's own saves do. Suspected cause of ships that could not hold forward: without the lines the hydrogen network may not connect on paste. Not verified in the game.

New zips with four ships that fly by hand (sit in the seat) and by themselves, plus the Cradle Pod and the `Corsair Wing`, `Warden Wing`, `Leviathan Wing` variants with Hornets in the cradles.
Three scripts: `ShrikeAI.cs` (the Helm of every ship: Hornet brain + MANUAL mode + weapon batteries + dead-man heartbeat; 79,990 of its 80,000 characters), `StaffAI.cs` (heartbeat watch that releases every
override when the Helm dies, wing orders and roll call, hangar doors, drone launch, display pages) and `CradleBayAI.cs` (the merge-block cradles). The usage guide is the README of the Warships zips.
The drone zips no longer contain the warships (they moved to the new zips); the All zip has everything. All ships were run in the simulator only: nothing has been pasted into the game yet.
- Staff 1.4: `launch [n|a-b|all]` (parks the Helm so the bays' ship-turns / ship-accelerates gates pass, releases, gives the Helm its mode back); `[Staff] Turret Target Group` / `Turret Target Names`
  (artillery and assault turrets aim at the targets' weapons: Leviathan vs Pirate, kill time median 143 s -> 89 s in the sim; replaces the planned Gunnery PB).
- ShrikeAI: the integrity scan (hit direction) is sliced, 150 blocks per call (a 1,300-block ship read all of them in one tick: 58,000 IL instructions of the 50,000 limit; peak is now 25,000);
  a seat named `Gunnery` no longer switches the Helm to MANUAL (`[Manual] Seat Exclude`).
- Designs: the Helm Custom Data of every ship now carries the keys the scripts read (the old `[Battery n]` / `[Cockpit]` sections were read by nobody); large ships: stand-off 700 / 800 m, jinking off,
  AI-block search off (the AI Flight block made the idle warship wander); Warden / Leviathan Timer D renamed `Timer D (deadman)` (the Helm finds it by that word: they had none); the Shrike has a second forward camera
  (with one the nose camera was shot off and the Shrike never saw a Hornet again); the empty Gunnery PB of the Leviathan is gone.
- Simulator: warship scenarios (`ship/<Blueprint>-vs-<Enemy>`) start with the Custom Data the blueprint carries and keep a connector-docked pod rigidly on its host; `selftest m6`.

### v2.7 (unreleased): SATELLITE formation
New operating mode: the drones spread round a slowly turning vertical ring centred on the owner (a ship running a Mothership link, you on foot, or the Gnat's carrier /
home point), break off and engage anything inside the Engage Radius, and fly back to their slots afterwards. Command `satellite` / `sat` / `orbit`; ring distance
(`Satellite Distance`, default 100 m, grows with the number of ships), orbit period and plane are in the `[Follow]` Custom Data section. Details, numbers and tests:
`docs/follow-mode.md`. FOLLOW block v1.1 (`tools/follow_block.cs`); the Gnat has its own copy. Size: the Basilisk is now 99,733 of the 100,000 characters.

### v2.6 (this package): BREACH aim against big ships; SEEKER test ships
- **Script length fix (important).** A Programmable Block takes at most 100,000 characters; since v2.2 every armed drone script
  was over it (Hornet 155,629, Basilisk 175,054 characters with comments), so a pasted drone's PB could not hold its script. The
  blueprints and the zips' `Scripts/` folder now carry minified scripts (comments and whitespace removed only; `tools/minify_cs.py`,
  proven identical by compiling both and comparing the IL, `tools/minify_check.sh`; largest now Basilisk 97,721). The commented
  originals are in `Scripts/Source/`, for reading only: they are too long to paste. The build refuses a script over the limit.
Question from the user: against large battleships (their *Tech Hunter*) the drones "can't figure out where vital components are and
just shoot the hull". Study: `docs/tech-hunter-study.md` (1,280 simulated fights, fleets of up to 10 Hornet / Gnat / Longbow S /
Longbow L / Basilisk).
- **BREACH** (shared block `tools/aim_block.cs` in every armed drone script, synced by `tools/aim_sync.py`): against a large grid of
  radius >= 25 m, AUTO holds one hull point (the known one nearest the target's centre, where the armour over the core is thinnest),
  keeps every round on it, and aims down the hole as it deepens; stalled or missing points are swapped. Sim vs Tech Hunter: railgun
  drones destroy about twice as many power blocks (Longbow L 0.65 -> 1.2 per drone in 10 min), at the cost of fewer exposed turrets.
  `aim breach`, `breach on|off`; Custom Data `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`.
- **SEEKER (experimental, option 4)**: a turret on the drone named `[Seeker]` is set to `Seeker Group` (PowerSystems / Weapons /
  Propulsion); the script reads where it points and drills there. New test ships **Longbow L Seeker** (artillery turret, 2 km) and
  **Basilisk Seeker** (roof turret renamed); `scripts/SeekerProbe.cs` reports what any ship's turrets tell a script. In the sim it did
  not beat BREACH; the in-game API behaviour is the open question (test 23).
- Finding for fleet building: against a turret-heavy capital ship only Longbow L survives (2 km = artillery range); Hornets, Gnats and
  Basilisks die in under 70 s whatever they aim at. Nothing of 10 drones or fewer knocked the Tech Hunter out in 10 minutes.
- Simulator turret ranges as in the game: an AI turret on its own targets within its Range setting, at most 800 m for every
  large-grid turret (artillery and assault cannon included), 600 m small grid; a working AI Offensive/Defensive block on its grid
  unlocks the ammo range (artillery 2 km, assault cannon 1.4 km). Turn rates and elevation limits per turret type from the data
  (artillery 0.2 rad/s). Re-run vs Tech Hunter: Longbow S now survives too; with BREACH 10 of them destroy 4.2 power blocks (0.8 before).
- Simulator: turrets need power; only railguns have a capacitor (artillery / assault-cannon capacitors starved every turret of a big
  ship); turret targeting groups + Azimuth/Elevation API; enemy vitals in the results; `--enemy-fleets`.

### v2.5: foundry fixes (finish-welding, robust reach, automatic take-off, owner ids)
- **Finish-welding verification.** `HiveMotherAI.cs` 2.1 no longer leaves BUILD when the projector reports 0 blocks left (that only means "all placed", not "all welded"). A new FINISH state keeps every welder on until a full scan of the bay's drone box finds each block at full integrity and functional. Welders can no longer be switched off in BUILD/FINISH (the old stall "kick" that turned all welders off is gone; it now toggles one welder at a time). The LCD lists unfinished blocks (name, cell, integrity, distance to the nearest welder), reports off/damaged/unpowered welders and an empty `[Stock]`, and FINISH has a timeout that FAULTs with the list.
- **Robust welder reach.** The welder sphere centre is unknown (model dummy), so `reach.py` now checks 8 hypotheses (centre at the tip, 1, 2 or 3 cells inside the welder; radius 1.3 m and 1.0 m), a build-order support check and a foreign-bay check. Hornet-class bays now carry 10-12 welders (was 5-8), Gnat bays 7 (was 5). Exit directions were re-chosen per drone. Costs about +900 PCU and +2.7 t per Hornet-class bay. Per-bay Custom Data gains `Drone Box Min/Max`, `Drone Cell Count`, `Drone Occupied Cells`, `Ignore Cells`, an explicit `Exit Direction`, and a `[Launch]` section.
- **Automatic take-off.** A shared LAUNCH block (`tools/launch_block.cs`, synced by `tools/launch_sync.py`) is in the Hornet, Gnat, Longbow, Mantis, Wasp, Lancer, Harrier, Aegis and Basilisk scripts. A printed drone launches when its own PB sees the merge pair open, or on `[Launch] Armed=true`, `_JOIN`, FLEET `join`, or the arguments `armed` / `launch` / `disarm`. No single message is needed. It burns away from the printer for `Burst Seconds`, then goes home and into its start mode (default GUARD). The printer writes `[Launch]` into the drone PB before release, repeats `_JOIN` for 40 s and recompiles the drone PB.
- Known limit: Gnat only thrusts forward/back, so a lateral Away direction does not move it in the sim (see docs/launch-protocol.md). The Stinger script is not yet integrated with the LAUNCH block.
- Docs: `docs/foundry-notes.md`, `docs/welder-reach.md`, `docs/launch-protocol.md`, `docs/hive-protocol.md` section 9.
- **Owner / built-by ids.** Blueprints now carry Owner and BuiltBy (the in-game PB showed `Owner: Nobody` because none were written). Already-pasted v2.x ships: select all blocks in the terminal and Transfer to yourself.

### v2.4 : kamikaze defence
Simulated attacks by swarms of small warhead drones (4 and 8 Stingers cued by a carrier's radar, against every combat drone model) showed the
scripts writing the kamikazes off as wrecks. A Stinger correcting its course at the speed cap spins 1-2 rad/s, so the "tumbling for 4 s" rule
dropped it, ignored it for 120 s and told the whole hive it was finished, usually just before it arrived.
- **KAMIKAZE DEFENCE** (shared block in every combat drone script, `tools/kz_block.cs`, synced by `tools/kz_sync.py`; scripts 2.6 / Gnat 1.13
  / Longbow 2.4; details in `docs/kamikaze-defence.md`):
  - small contacts on a collision course with the drone or a hive mate are never written off as wrecks, and are dropped once spent;
  - they become the priority target;
  - the drone backs away along the threat axis while its guns stay on target, and breaks sideways inside 2 s of impact;
  - spare camera charge tracks the rest of the swarm and searches round known kamikazes for their pack;
  - the threats are shared with the hive, and Gnats skip their run-in against a kamikaze.
  New `[Kamikaze Defence]` section in Custom Data; PB screen line `!! KAMIKAZE x3 (2 at me) next 4.2 s 380 m`.
- Simulator, 620 kamikaze fights (20 seeds): defenders still fighting at the end 57% -> 70%, damage taken -41%. Against 4 Stingers, a lone
  Hornet goes 50 -> 80%, Lancer 45 -> 85%, Mantis 35 -> 75%, Longbow S 55 -> 80%. Fights without kamikazes are unchanged (1v1 regression in the doc).
- Simulator: scenario kind `kamikaze`, settings `SwarmCueSeconds` / `SwarmCueTeam`, `one --echo-every S`, report tool `tools/kz_report.py`.

### v2.3: lead aiming against manoeuvring targets
In-game report (2026-10-13): the Basilisk's rockets kept missing an enormous target that was doing basic evasive manoeuvres. A rocket
needs about 4 s to fly 800 m; an AI ship on "evasive" flips its strafe every 2-5 s. Full write-up and measurements: `docs/lead-v1.md`.
- **LEAD v1.0** (shared block in every armed drone script, `tools/lead_block.cs`, scripts v2.5 / Gnat 1.12 / Longbow 2.3):
  - the target's freshest acceleration, held only for as long as its manoeuvres usually last, then constant velocity (the old
    solver extrapolated a lagging, smoothed acceleration over the whole flight);
  - the hull aim point counts only across the line of fire, turns with the target's spin for up to 1 s, and keeps
    `Aim Margin (predicted misses)` x the predicted miss of known hull round it, so long, uncertain shots go to the middle of the
    known hull instead of its edge.
- Basilisk / Wasp: rockets modelled as leaving with the ship's velocity + launch speed and curving onto the barrel line
  (`Rocket Velocity Model` CAPPED / NONE / FULL; NONE is the v2.2 model). Closed-form rocket path, Newton solve on the flight time.
- Offline bench (`tools/lead_bench`), hits on manoeuvring targets: rockets 50 % -> 62 % (strafing 120 m ship 43 -> 66 %, strafing
  30 m ship 14 -> 39 %), gatling 70 % -> 90 %, railgun 77 % -> 90 %.
- Simulator: rockets inherit the shooter's velocity with the speed cap (`--rocket-inherit`, default 1), evasive Pirate
  (`--pirate-evasive true`).

### v2.2: FOLLOW mode
Question from the user: does `guard` follow the owner? Only as a side effect: a Mothership link's position replaces the guard spot, but
the drones fly to the ship's centre (into its hull for most drone types), lag behind a moving ship, and fall back to the old spot when
the link stops. Nothing followed a player on foot.
- **FOLLOW** (shared block in every scripted combat drone, `tools/follow_block.cs`, synced by `tools/follow_sync.py`): `follow` / `escort`
  command (also Start Mode and launch Mode `FOLLOW`). The owner is the ship running a Mothership link (any type, FLEET channel), or the
  owner's own character seen by the drone's sensor (on foot, ~50 m; wins while seen). Each drone flies its own slot on a ring behind the
  owner (upper half in gravity) outside its hull, with the owner's velocity fed forward (estimated from the link's position fixes, so old
  link scripts work), detours round the hull instead of through it, engages only targets within 800 m of the owner, breaks off past
  1.2 km (2.2 km for the snipers), and after a link loss coasts 3 s on the owner's track (10 s on foot) and holds there. On a
  collision course with the owner it sidesteps up to 8 s ahead, and the ring widens (up to 2x) while the owner manoeuvres hard.
  New `[Follow]` section in Custom Data. No AI-block search in FOLLOW (the AI Flight block would fly the drone away from you).
- Gnat 1.11: `follow` / `escort` = `form`; the formation now matches the link ship's velocity (keeps up with it), and also reads the
  ship radius from the FLEET channel.
- Mothership links (Hornet / Longbow v1.1, Gnat v1.2): send the ship's radius on `<Tag>_HOMER` and `<fleet>_HOMER`; `follow` relays.
- FLEET block: `follow` and `escort` added to the default `Allowed Commands`.
- Simulator: `follow-test` (moving owner on the fleet channel, or an owner character reported to the sensors; cruise, weave, link loss,
  on foot, fight).

### v2.1: first in-game report fixes
In-game report (2026-10-13): Full drones set to `guard` stood still; `hunt` drones waited about 20 s, then all flew off the same way
and never saw a pirate ship 700 m away. Cause: the AI blocks paste with **AI Behavior off**, so they do nothing, but the scripts handed
them the ship and switched their own camera search off while waiting for them. Reproduced in the simulator (AI blocks inert:
3 Hornets vs pirate at 700 m won 0 of 40, found the pirate in 1 of 40 runs).
- **AI GATE** (shared block in every scripted drone, `tools/ai_gate_block.cs`): the script tries to switch AI Behavior on itself
  (the PB screen says whether it could). Until the AI blocks have flown the ship once, they only get it in 6 s windows between 8 s
  of the script's own camera search (under fire the script searches); once they have, they are trusted as before (status `AI ok`).
  New `[AI Gate]` section in Custom Data.
- Side cameras scan out to 900 m whenever there is no target (was 120 m); short close-scan rays no longer drain the nose cameras
  below the long scan's range while under fire.
- Hit direction: the blocks that lose integrity tell which side was hit; the nose sweep and the side cameras search that side.
- HUNT search patrol: drones fan out (each starts its square at a different corner), keep sweeping their cameras on a leg instead of
  looking along the flight path, hold position at listening stops, and Lite drones (no AI blocks) patrol too.
- Simulator results (pirate ship 700 m away, 36 pirate scenarios x 20 seeds, every model): AI blocks doing nothing, `hunt`: drone
  side wins 23 -> 44 of 720, `guard`: 24 -> 47 of 720 (3 Hornets alone: found the pirate in 1 -> 15 of 40 fights); AI blocks that
  need the AI Behavior switch: 23 -> 211 of 720 (the script switches it on). With working AI blocks drone-vs-drone results are
  unchanged (1v1 without the Watcher, 1,560 fights: 77.6 % -> 77.4 % decisive). The unarmed Watcher (no AI blocks) now patrols in
  `hunt` like every drone without AI blocks, so armed drones catch it less often (Watcher fights 60 % -> 24 % decisive).
- Simulator: `--script-ai-blocks-inert` (AI blocks never act) and `--ai-behavior-needs-switch` (AI blocks act only once a script
  switches "ActivateBehavior" on); `GetProperties`/`GetActions` on terminal blocks.

### v2.0
- Every model exists as Full and **Lite** (Lite: only block XML shapes seen in a game-written ship, plus the merge block). Both variants build, validate and ship from one generator (`tools/build_all.py`).
- Blueprint generator rewritten around real data: mount-point validation (checked against the Starburst ship), real masses and costs from `defs_stats.json`, `<Toolbar>` written for Sensor/Timer/Turret Controller/Event Controller (probable paste-failure fix), Custom Data stored in ModStorage (the old `<CustomData>` element was ignored by the game), unique blueprint ids, stable (crc32) seeds, no `.sbcB5`.
- Weapon data corrected from the local game files: gatling 700 rpm, 800 m/s (was 400).
- Merge block clamp face corrected: small 1x1x1 block clamps toward Up (was Right); Hornet, Gnat and every printable drone got a clear docking face.
- New drones: **Wasp** (rockets), **Lancer** (autocannon), **Watcher** (unarmed scout), **Harrier** (interceptor), **Aegis** (escort / point defence), **Mantis** (railgun + gatling), **Basilisk** (large-grid rocket gunship), **Midge** (scriptless, experimental).
- New printers (projector + welders + merge block bays, `HiveMotherAI.cs` 2.0): Hive Mother, Twin Hive, Quad Hive, Hornet Forge, Wasp Foundry, Lancer Foundry, Longbow Foundry, Harrier Forge, Aegis Shipyard, Mantis Foundry, Watcher Pad, Fleet Forge, Escort Carrier, Mobile Hive, Static Nest, Stinger Rack.
- Hornet: rear camera moved one cell up to make room for the docking stalk. Gnat: merge block on a 2-cell stalk under the belly.
- Printers: every bay now has an exit lane. Before, Hornet-class bays (Hornet, Wasp, Lancer, Longbow S, Harrier, Aegis, Mantis, Watcher) had a welder on every side of the drone, so the finished drone could not leave. The drone's footprint swept 14 cells away from the merge block is kept free; Longbow S and Mantis leave sideways (outwards, away from the neighbour bay) and HiveMotherAI.cs reads the new per-bay `Exit Direction` Custom Data key to nudge the printer the right way.

### v1.x history
- **v1.0**: Hornet (gatling), Longbow S/L (railgun), Gnat (2-thruster swarm), mothership relays.
- **v1.1**: sensors added; nothing pasted.
- **v1.2**: sensor removed; Longbow stopped reading railgun power.
- **v1.3**: steadiness-gated lead, `Lead Scale`.
- **v1.4**: 5 extra cameras + all-around close scan; compact embedded scripts (size theory later disproven).
- **v1.5**: disabled-target detection, damage sensing and evasion, split focus, on-screen errors.
- **v1.6**: hull-point aim modes.
- **v1.7**: AI-block search hand-off (user places `[AI]` blocks).
- **v1.8** (uncompiled in-game): printer join / re-scan on grid change, Hornet scout mode.
