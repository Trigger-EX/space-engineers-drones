# Space Engineers combat drones v2.7 (Full)

All drone models in their **Full** design (Sensor, AI blocks, Decoy, turret where the model has them). Try `Drones_v2.7_Lite` if a Full ship does not paste.

Package contents: 14 drone blueprints. All ships are small grid unless noted; **no DLC blocks**.

## Install

1. Unzip this package anywhere. You get `Blueprints/<Name>/{bp.sbc,thumb.png}`, `Scripts/*.cs` and this README. The scripts in
   `Scripts/` are compacted (no comments) so they fit the Programmable Block's 100,000-character limit: paste those. The commented
   originals in `Scripts/Source/` are for reading only and are too long to paste.
2. **Delete the old blueprint folders first.** Open `%AppData%\SpaceEngineers\Blueprints\local\`, and remove every folder of an earlier
   version of these ships (Hornet, Gnat, Longbow ..., also their `bp.sbcB5` files). The game caches a binary `bp.sbcB5` next to `bp.sbc`
   and keeps loading the stale copy if it is still there. This package never ships a `.sbcB5`.
3. Copy the `Blueprints/<Name>` folders you want into `%AppData%\SpaceEngineers\Blueprints\local\`.
4. In game: press **F10** (blueprint screen), pick the ship, and paste it into the world (creative tools, or load it into a projector in a
   survival world).
5. Every ship is pasted as a **dynamic** small-grid ship (a large-grid ship for the Basilisk). Do not convert printers to a station: a
   static printer would make every printed drone static.
6. Check that "In-game scripts" is enabled in the world settings, otherwise the Programmable Blocks do not run.
7. If something does not paste, send the game log (`%AppData%\SpaceEngineers\SpaceEngineers_*.log`) and say which model and variant.

**Which variant?** `<Name>` (Full) uses the whole design, including block types whose XML has never been seen in a game-written
blueprint (Sensor, AI blocks, Decoy, cargo containers, turret). `<Name> Lite` uses only block types whose XML shape is copied from a
game-written ship (the Starburst reference), with the one exception noted under "Known unknowns" (the small merge block). If a Full ship
does not paste, try its Lite twin: it must still fly and fight. No ship uses DLC blocks.

## Models

| Model | Variant | Blocks | Mass kg | Accel m/s2 | PCU | Script |
|---|---|--:|--:|--:|--:|---|
| Gnat | Full | 21 | 2253 | 0.0-6.4 | 722 | GnatSwarmAI |
| Hornet | Full | 54 | 4451 | 6.5 | 1010 | HornetDroneAI |
| Longbow L | Full | 52 | 110181 | 6.3 | 926 | LongbowSniperAI |
| Longbow L Seeker | Full | 53 | 124405 | 5.6 | 1201 | LongbowSniperAI |
| Longbow S | Full | 53 | 6044 | 4.8 | 885 | LongbowSniperAI |
| Lancer | Full | 54 | 4515 | 6.4 | 1010 | LancerAI |
| Wasp | Full | 54 | 4607 | 6.3 | 1700 | WaspAI |
| Midge | Full | 35 | 4169 | 6.9 | 680 | none |
| Watcher | Full | 54 | 4005 | 7.2 | 900 | HornetDroneAI |
| Aegis | Full | 58 | 4876 | 5.9 | 1180 | AegisAI |
| Basilisk | Full | 52 | 115787 | 6.0 | 4257 | BasiliskAI |
| Basilisk Seeker | Full | 52 | 115787 | 6.0 | 4257 | BasiliskAI |
| Harrier | Full | 56 | 4693 | 6.1-12.3 | 1034 | HarrierAI |
| Mantis | Full | 53 | 6312 | 4.6-9.1 | 914 | MantisAI |

### Gnat

Compact swarm drone: one gatling, two axial ion thrusters (it steers by turning the whole ship), sensor, AI Offensive + AI Flight blocks on a 2-cell tail (Lite: none), belly merge latch. Flies yo-yo attack runs inside a leaderless IGC swarm.

* **Gnat**: 21 blocks, 2253 kg, 2.0x2.5x3.5 m, accel F6.4 B6.4 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 722; script: GnatSwarmAI.cs; cost Iron 2282 Nickel 274 Cobalt 26 Silicon 23 Gold 2 Platinum 1

Note: Thrust only along the nose axis (forward / back), by design.

### Hornet

The standard fighter: two gatlings, 12 ion thrusters (2 per axis), 7 cameras, 4 batteries, rear merge latch. Holds a standoff, orbits and jinks; guard / hunt / assist.

* **Hornet**: 54 blocks, 4451 kg, 3.5x3.0x4.0 m, accel F6.5 B6.5 U6.5 D6.5 L6.5 R6.5 m/s2, PCU 1010; script: HornetDroneAI.cs; cost Iron 4412 Nickel 301 Cobalt 132 Silicon 31 Gold 12 Platinum 5

### Longbow L

Large-grid railgun sniper (2000 m). Same logic as Longbow S; not printable (no merge block).

* **Longbow L**: 52 blocks, 110181 kg, 17.5x25.0x27.5 m, accel F6.3 B6.3 U6.3 D6.3 L6.3 R6.3 m/s2, PCU 926; script: LongbowSniperAI.cs; cost Iron 97090 Nickel 1850 Cobalt 9750 Silicon 528 Gold 1260 Platinum 384

Note: Large grid, no merge block: paste only.

### Longbow L Seeker

TEST SHIP for subsystem seeking: Longbow L with an artillery turret (2 km, the railgun's reach) named [Seeker] on its back. The script sets the turret to a targeting group (Custom Data: Seeker Group, default PowerSystems), reads where it points and aims its railgun slugs down that line. The status screen shows a "Seek:" line with what the turret reports.

* **Longbow L Seeker**: 53 blocks, 124405 kg, 17.5x25.0x27.5 m, accel F5.6 B5.6 U5.6 D5.6 L5.6 R5.6 m/s2, PCU 1201; script: LongbowSniperAI.cs; cost Iron 112150 Nickel 2250 Cobalt 9900 Silicon 532 Gold 1260 Platinum 384

Note: Large grid, paste only. Experimental (see Basilisk Seeker). Load artillery shells into the turret: a turret without ammunition may not pick a target at all, and then it cannot guide the railgun.

### Longbow S

Small-grid railgun sniper (1400 m). Computes the longest range at which a dodging target is still hit, takes one settled shot, jinks while reloading.

* **Longbow S**: 53 blocks, 6044 kg, 3.5x4.0x5.5 m, accel F4.8 B4.8 U4.8 D4.8 L4.8 R4.8 m/s2, PCU 885; script: LongbowSniperAI.cs; cost Iron 5619 Nickel 310 Cobalt 120 Silicon 58 Gold 52 Platinum 5

Note: No docking face in the base model; printers add a docking stalk to it.

### Lancer

Hornet-class frame with 1x1x5 autocannons (800 m/s shells). Burst fire only when the solution is tight; standoff 420 m.

* **Lancer**: 54 blocks, 4515 kg, 3.5x3.0x4.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 1010; script: LancerAI.cs; cost Iron 4472 Nickel 301 Cobalt 132 Silicon 31 Gold 12 Platinum 5

### Wasp

Hornet frame with small rocket launchers (8 rockets). Integrates the rocket speed curve to lead targets, fires short salvos, refuses shots at unpredictable targets or near hive mates.

* **Wasp**: 54 blocks, 4607 kg, 3.5x3.0x4.0 m, accel F6.3 B6.3 U6.3 D6.3 L6.3 R6.3 m/s2, PCU 1700; script: WaspAI.cs; cost Iron 4584 Nickel 291 Cobalt 126 Silicon 31 Gold 12 Platinum 5

Note: Needs rockets loaded by hand in survival; relies on the terminal action ShootOnce (unverified).

### Midge (experimental)

EXPERIMENTAL scriptless drone: gatling, AI Offensive + AI Flight + AI Defensive blocks, no Programmable Block. The AI blocks must be set up by hand (Scripts/MidgeNotes.md). Midge Lite is only a renamed Gnat Lite running GnatSwarmAI.cs.

* **Midge**: 35 blocks, 4169 kg, 3.5x3.0x5.0 m, accel F6.9 B6.9 U6.9 D6.9 L6.9 R6.9 m/s2, PCU 680; script: none; cost Iron 4122 Nickel 267 Cobalt 126 Silicon 19 Gold 12 Platinum 5

Note: Experimental; no script. Configure the three AI blocks by hand (Scripts/MidgeNotes.md). Gatling ammo is not preloaded.

### Watcher

Unarmed scout / spotter: 11 cameras, 5000 m antenna. Keeps 900 m standoff and shares targets with the hive (runs the Hornet script in scout mode).

* **Watcher**: 54 blocks, 4005 kg, 3.5x3.0x4.0 m, accel F7.2 B7.2 U7.2 D7.2 L7.2 R7.2 m/s2, PCU 900; script: HornetDroneAI.cs; cost Iron 3948 Nickel 131 Cobalt 120 Silicon 29 Gold 12 Platinum 5

Note: Configured only through the PB Custom Data ([Hornet] section, IGC Tag HORNET, Start Mode HUNT). `range` is clamped to Max Fire Range; use Standoff in Custom Data for larger values.

### Aegis

Escort / point defence: four gatlings, two decoys (Lite: armour plates). Parks on a station around the carrier and screens it by standing on the carrier-to-threat line.

* **Aegis**: 58 blocks, 4876 kg, 3.5x3.0x4.5 m, accel F5.9 B5.9 U5.9 D5.9 L5.9 R5.9 m/s2, PCU 1180; script: AegisAI.cs; cost Iron 4882 Nickel 331 Cobalt 144 Silicon 34 Gold 12 Platinum 5

Note: For a carrier link copy HornetMothership.cs and change Tag to AEGIS, or use the default extra channel HORNET_HOME.

### Basilisk

LARGE-grid armoured rocket gunship: four large missile launchers, six heavy armour blocks, 12 thrusters; Full adds a large gatling turret as point defence. Not printable.

* **Basilisk**: 52 blocks, 115787 kg, 17.5x17.5x20.0 m, accel F6.0 B6.0 U6.0 D6.0 L6.0 R6.0 m/s2, PCU 4257; script: BasiliskAI.cs; cost Iron 109148 Nickel 3825 Cobalt 11055 Silicon 326 Gold 960 Platinum 384

Note: Large grid: paste it as a free ship; it has no merge block and cannot be put in a printer bay.

### Basilisk Seeker

TEST SHIP for subsystem seeking: the Full Basilisk with its roof turret named [Seeker]. The script sets that turret to a targeting group (Custom Data: Seeker Group, default PowerSystems), reads where it points, and drills its rockets into the hull over that block. The status screen shows a "Seek:" line with what the turret reports.

* **Basilisk Seeker**: 52 blocks, 115787 kg, 17.5x17.5x20.0 m, accel F6.0 B6.0 U6.0 D6.0 L6.0 R6.0 m/s2, PCU 4257; script: BasiliskAI.cs; cost Iron 109148 Nickel 3825 Cobalt 11055 Silicon 326 Gold 960 Platinum 384

Note: Large grid, paste only. Experimental: tells you whether the game lets a script find an enemy's power blocks through a turret. Decoys pull the turret first.

### Harrier

Fast interceptor: Hornet frame with four main engines (12 m/s2 forward). Hunts small fast grids, drones and missiles first; shares threat cues on the DRONE_CUE channel.

* **Harrier**: 56 blocks, 4693 kg, 3.5x3.0x4.0 m, accel F12.3 B6.1 U6.1 D6.1 L6.1 R6.1 m/s2, PCU 1034; script: HarrierAI.cs; cost Iron 4648 Nickel 301 Cobalt 152 Silicon 31 Gold 14 Platinum 6

### Mantis

Railgun + gatling hybrid on a Longbow S spine: alpha strike at range, gatling up close. Engage cap 650 m.

* **Mantis**: 53 blocks, 6312 kg, 3.5x4.5x5.5 m, accel F9.1 B4.6 U4.6 D4.6 L4.6 R4.6 m/s2, PCU 914; script: MantisAI.cs; cost Iron 5891 Nickel 325 Cobalt 146 Silicon 56 Gold 54 Platinum 6


## Configure and command

Every script keeps its settings in the Programmable Block's **Custom Data** (ini; written on first run, edit and run `reload`).
Commands go in the PB's *argument* (run the PB with the text, or put it on a toolbar slot / button panel) or arrive over IGC on the channel `<IGC Tag>_CMD`.
Printed drones start in IDLE and wait for the printer's `_JOIN`; a drone pasted by hand needs `guard`, `follow` or `hunt` (or set `Start Mode`).

- `guard` holds the spot where the drone was pasted (or where you last ran `home`) and attacks anything within `Guard Radius` (1.5 km) of it.
  With nothing in sight it stays put and turns in place to scan; it does not patrol. If a ship runs a Mothership link, its live position
  replaces that spot (so guard drags along behind a carrier), but guard flies to the ship's centre and falls back to the old spot if
  the link stops: for an escort use `follow`.
- `follow` (or `escort`) keeps the drone with **you**: (v2.2)
  - **in a ship**: put a Mothership link script (`HornetMothership.cs`, `LongbowMothership.cs` or `GnatMothership.cs`, any of them
    drives every drone type over the FLEET channel) on a Programmable Block on your ship. Your ship needs an antenna.
  - **on foot**: Full drones (they have a sensor) also follow your character while their sensor sees you (about 50 m). Step out of the
    ship next to them and they switch to you; walk off further than that and they hold where they last saw you.
  - Each drone takes its own slot on a ring behind you (upper half only on a planet), 60 m out (20 m on foot, further for big ships or
    many drones), outside your hull, and matches your speed. It attacks only enemies within 800 m of you and breaks off past 1.2 km
    (2.2 km for the Longbow and Mantis snipers). If the link drops it keeps going your way for 3 s, then holds there until it hears you.
  - Run `follow` on each drone, or `follow` on the Mothership link PB (that drone type), or `fleet follow` on it (every type).
    Settings: `[Follow]` section in Custom Data (`Slot Distance`, `On Foot Distance`, `Owner Radius`, `Engage Radius`, `Leash`,
    `Coast After Link Loss (s)`, `Follow Owner On Foot`). Gnats: `follow` is their `form` (the swarm sphere round the link ship, which
    now keeps up with it); no on-foot mode.
  - Drones configured before v2.2 have an `Allowed Commands` line in `[Fleet]` without `follow`: add `follow,escort` to it (or delete
    the line and run `reload`) if you want `fleet follow` to reach them.
- `hunt` attacks anything it finds. After 15 s with nothing found it flies a search square of 1.2 km around home, stopping every leg to look
  around; several hunters fan out in different directions.

## AI blocks (Full variants): switch AI Behavior on

The Full drones carry an AI Offensive and an AI Flight block (named `... [AI]`). They are the drones' long-range eyes: they notice enemies up
to 2.5 km away in every direction, the script confirms with its cameras and takes over the fight. **A blueprint cannot pre-set them: they
paste with AI Behavior off and do nothing.** The scripts try to switch AI Behavior on by themselves; the PB screen shows
`AI Behavior on (2 blocks)` if that worked, or `AI Behavior switch not found: turn AI Behavior on by hand`.

To set them up by hand (once, then save the drone with Ctrl+B as your own blueprint so every copy keeps it):
1. `<Name> AI Flight [AI]`: Speed Limit 60-100 m/s, Collision Avoidance on, AI Behavior **on**.
2. `<Name> AI Offensive [AI]`: attack Enemies, Target Priority Closest, Facing Mode "Use Static Weapons" with the drone's guns moved to
   Selected, AI Behavior **on**.
3. Leave both blocks switched **off** (Enabled): the script switches them on and off itself.

The status line `AI: searching` means the AI blocks have the ship, `AI: own search` means the script is sweeping its cameras;
`AI ok` appears once the AI blocks have flown the ship, after which the script trusts them fully. Without
working AI blocks (and on Lite variants) a drone searches with camera rays only: it reliably finds enemies within about 100 m, and farther
ones slowly, mostly once they shoot at it.

## Kamikaze defence (incoming swarms of small warhead drones)

Every combat drone recognises small contacts flying at it (or at a hive mate) on a collision course, shoots the most urgent one first,
backs away from it while firing, and breaks sideways just before impact (a small warhead reaches only 4.5 m). The threats are shared with
the hive. The PB screen shows `!! KAMIKAZE x3 (2 at me) next 4.2 s 380 m`. Settings: `[Kamikaze Defence]` in Custom Data
(`Enabled=false` turns it off). Tiny drones are hard to see: the drones find them through their AI blocks, a turret / Custom Turret
Controller, or hive mates. A fleet that expects kamikazes should carry a turret designator or a Watcher / Aegis spotter.

### AegisAI.cs (v2.6-aegis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Extra Home Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Max Fire Range vs Huge Grids`, `Standoff Range vs Huge Grids`, `Standoff Range`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Screen Distance From Carrier`, `Carrier Radius`, `Hold Radius`, `Tether Radius`, `Target Missiles`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### BasiliskAI.cs (v2.6-basilisk)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Rocket Velocity Model (CAPPED/NONE/FULL)`, `Aim Margin (predicted misses)`, `Max Fire Range`, `Max Flight Time`, `Max Fire Range vs Huge Grids`, `Max Flight Time vs Huge Grids`, `Standoff Range vs Huge Grids`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range vs Small Grids`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Wingmate Close Separation Range`, `Wingmate Close Separation Speed`, `Take Over From AI When A Wingmate Is Closer Than (m; 0 off)`, `Wingmate Separation Hold (s)`, `Fire Window Multiplier`, `Fire Window Multiplier (unlimited rockets)`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Cone (deg)`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Dash Only While Recent Hits Below`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### GnatSwarmAI.cs (v1.13+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `form`
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `attack`
* `hunt`: chase and engage any target, actively scan
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (FORM/ATTACK/IDLE)`, `Projectile Speed`, `Fire Range`, `Closing Speed`, `Run-in Start Range`, `Back-off Speed`, `Orbit Speed`, `Back-off Range`, `Re-close Range`, `Emergency Break Range`, `Attack Cone Degrees`, `Max Sideways Drift m/s`, `Formation Radius`, `Satellite Distance (m)`, `Satellite Orbit Period (s)`, `Separation Radius`, `Engage Radius From Home`, `Combat Speed`, `Cruise Speed`, `Velocity Gain`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `RTB Battery Fraction`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Lead Scale (1 = calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false = focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire (s)`, `Raid Fan Half-angle Degrees`, `Raid Scan Cone Degrees`, `Raid Scan Ray Length`, `Raid Speed`, `Raid Max Travel`, `Raid Bearing Memory Seconds`, `Raid Start Confidence`, `Raid Hold Confidence`, `Listen To IGC Tags (target feeds)`, `Scan Range`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`.


### HarrierAI.cs (v2.6-harrier)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Small Target Standoff Fraction`, `Target Priority Small Bonus`, `Target Priority Large Penalty`, `Target Priority Fast Closer Bonus`, `Target Priority Missile Bonus`, `Target Missiles`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### HornetDroneAI.cs (v2.6-hornet)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LancerAI.cs (v2.6-lancer+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Burst Seconds`, `Burst Pause`, `Conserve Below Shells`, `Conserve Max Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LongbowSniperAI.cs (v2.4)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### MantisAI.cs (v2.6-mantis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Engage Cap`, `Use Gatling`, `Gatling Projectile Speed`, `Gatling Range`, `Gatling Fire Window Multiplier`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### WaspAI.cs (v2.6-wasp+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Rocket Velocity Model (CAPPED/NONE/FULL)`, `Aim Margin (predicted misses)`, `Max Fire Range`, `Max Flight Time`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Jink Gate Radius Factor`, `Jink Gate Min Miss (m)`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range`, `Standoff Range (unlimited rockets)`, `Max Fire Range (unlimited rockets)`, `Max Flight Time (unlimited rockets)`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Boresight Rays (of 8)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `AI Confirm Cone Yaw (deg)`, `AI Confirm Cone Pitch (deg)`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### GnatMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.

### HornetMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.

### LongbowMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.


## Known unknowns

- **Merge-block clamp face (unverified).** The small 1x1x1 merge block (`SmallShipSmallMergeBlock`) clamps toward its local **Up** face (one wiki source); the old assumption was Right. Every merge pair in this package is built on that. It is one constant (`MERGE_CLAMP_FACE_SMALL` in `tools/designs/_common.py`); if the merge-face test (T1) shows another face, change it and run `tools/build_all.py` again.
- **Lite variants keep the small merge block.** Its XML shape comes from the Keen source, not from the Starburst reference, so strictly a Lite ship is not 100 % "seen" XML. A drone or printer without it cannot be printed or docked. `LITE_KEEPS_MERGE = False` in `_common.py` drops it from the drones.
- **XML shapes never seen in a game-written blueprint:** Sensor, the AI blocks (Offensive, Flight, Defensive), Decoy, large gatling turret, Timer and Event Controller toolbars. They are why Full variants exist next to Lite ones. Earlier blueprints with a Sensor or Custom Turret Controller failed to paste; the leading hypothesis is a missing `<Toolbar>` element (now always written), but that is not confirmed.
- **Projected Programmable Blocks.** A welded PB may keep its Program text but not start by itself. The printer script calls `ApplyAction("Recompile")` on it; whether that works is the projected-PB test (T5, T6).
- **No ammunition is pre-loaded** in any gun or launcher (the generator cannot write inventories). In a survival world load magazines / rockets by hand; in a creative world the guns may still need magazines unless the world has infinite ammunition switched on (test T8 shows which). Scripts treat an unknown ammo count as unlimited and never return to base for lack of ammo in that case.
- **Scripts have never run in the game with these versions.** They compile against a hand-written stub of the game API (`tools/compile_check.sh`), which proves syntax and types only.
- **Weapon numbers** come from the local game data (gatling 700 rpm, 800 m/s, 800 m; small rocket 500 damage, 4 m blast; small railgun 1000 m/s, 1400 m, 500 ms shot delay). Rockets are assumed (v2.3) to leave with the shooter's velocity plus their launch speed, accelerate along the barrel and have their total speed capped, so a rocket fired from a moving ship curves onto the barrel line (Keen bug tracker). Test 18 in the test list checks it; if your rockets fly dead straight from a ship moving sideways, set `Rocket Velocity Model=NONE` on the Basilisk and Wasp.
- **Gnat / Midge Lite** thrust only along the nose axis (two axial thrusters, steered by gyros). They have no lateral or vertical thrusters by design.
- **Wasp** relies on the terminal action `ShootOnce` (name from memory, unverified). If it is wrong the Wasp never fires. Its target-lead solver was checked numerically only.
- **Midge (experimental)** has no script and no Programmable Block. The AI-block XML is a guess and its settings (attack pattern, selected gun, AI Behavior switch) cannot be pre-set: configure it by hand once, see `Scripts/MidgeNotes.md`. **Midge Lite** is only the Gnat Lite frame renamed and still runs `GnatSwarmAI.cs`.
- **Basilisk** is a large-grid ship with no merge block; it cannot be printed (paste only). Longbow S / L have no docking face in the base model (printers add a docking stalk to Longbow S and Mantis).
- Scripts that were forked from the Hornet script (Wasp, Lancer, Harrier, Aegis, Mantis, Basilisk, Watcher) do not share later bug fixes automatically. A drone only joins the hive of another model if both use the same `IGC Tag`.
- **Power budget and run time (computed from `defs_stats.json`, not measured).** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis: 4 small batteries = 0.2 MWh and at most 0.8 MW output; the 12 thrusters could draw 2.4 MW, so a burn on all three axes at once is capped at about 67 % thrust, and a one-axis burn (2 thrusters, 0.4 MW) lasts about 30 minutes. Gnat and Midge Lite: 1 battery = 0.05 MWh and 0.2 MW, i.e. about 15 minutes with the one thruster at full power. Longbow S and Mantis: one 3x2x3 battery = 1 MWh, 4 MW. Longbow L: 12 MWh, 48 MW against 40 MW of thrusters. Power drawn by guns, railgun charging, antenna range and welders is not in the game files, so it is not in these figures. There is no generator or solar panel on any drone: once the batteries are empty the drone is dead weight (`RTB Battery Fraction` sends it home before that).
- **Space only.** Thrust is ion thrust with no gravity term: the best drones accelerate at 6 to 7 m/s2 (Harrier 12 m/s2 forward only), which is less than 1 g (9.81 m/s2), and ion thrusters lose most of their force in an atmosphere. None of these ships can lift off or hover over a planet. Use them in space or at the edge of low gravity. Masses are component masses only; magazines, rockets and cargo add weight.
- **AI Behavior switch from a script (unverified).** The Full drones' AI blocks paste with AI Behavior off. The scripts look for a bool terminal property whose id contains "Behavior" on each `[AI]` block and switch it on; the id is not documented (believed to be `ActivateBehavior`). The PB screen shows `AI Behavior on (N blocks)` when it found the switch, else `AI Behavior switch not found`: then switch it on by hand (see "AI blocks" above). Even switched on, the AI blocks keep their default settings (AI Flight speed limit 10 m/s, no weapon selected), which a blueprint cannot pre-set.
- **Camera-only search is weak.** Without working AI blocks (and on Lite variants) a drone finds enemies only with camera rays. In the simulator 3 Hornets with inert AI blocks found a pirate ship 700 m away in about 4 of 10 fights (was 1 in 40 before v2.1), mostly after it opened fire, and still lost most of those fights; with working AI blocks they found it within 3 s every time and won 3 of 4.
- **BREACH and SEEKER (v2.6) are sim-tested only.** BREACH assumes camera rays at a hull point come back deeper once blocks there die (true in the sim's block-exact raycast). SEEKER assumes `IMyLargeTurretBase.SetTargetingGroup("PowerSystems")` works from a script, that the game then aims the turret at a power block, and that `Vector3D.CreateFromAzimuthAndElevation(Azimuth, Elevation)` in the turret's frame is its barrel direction. Decoys pull the turret first. Test 23 checks all of it.
- **Script size headroom is small.** Minified, the Basilisk script is 97,721 of the 100,000 characters a Programmable Block takes (Wasp 95,313, Mantis 94,623). The build stops with an error when a script goes over; the next big feature will need code moved out or trimmed.

## In-game tests (do them in this order)

1. **World settings and cache (T13, T14).** "In-game scripts" on. Old blueprint folders deleted. Paste once with a stale `bp.sbcB5` left in a folder to see whether it matters. Decides: cause 1 of "script missing after paste".
2. **Paste the Lite twins first** (`Gnat Lite`, `Hornet Lite`, then the rest of the Lite set). Pass: it pastes, no floating blocks (cut one block with a grinder; thrusters, cameras, gyro, PB and antenna must stay), the PB's Edit window shows the code, its Custom Data shows the ini section, no DLC warning. Decides: the generator's basic XML (ComponentContainers, ModStorage custom data, orientation) is right.
3. **Paste the Full variants.** Same checks. If a Full ship fails and its Lite twin pastes, the unseen block shapes (Sensor, AI blocks, Decoy, cargo, turret) are the cause (T2, T11): send a Ctrl+B export of a small grid that holds one each of Timer, Sensor, Turret Controller, Event Controller, AI Offensive / Flight / Defensive, Merge Block, Projector, Welder, Warhead.
4. **Merge face (T1).** On two small grids put two `SmallShipSmallMergeBlock`s with their Up faces towards each other (and separately Right towards Right) and see which pair turns yellow / merges. Then check a drone's merge latch against a printer bay.
5. **Release (T3).** Merge two blocks; switch the drone-side one off, then the printer-side one off. Decides which side can release (needed by the printers; also by hand docking).
6. **Weapon and ammo behaviour (T8, T9).** Fire each gun class once with an empty inventory (creative vs survival), time the small railgun's trigger-to-impact (Longbow, Mantis), check that Wasp rockets launch (`ShootOnce`) and where they go relative to the moving shooter.
7. **Scriptless Midge (T7).** Configure the AI blocks by hand as in `MidgeNotes.md`, switch AI Behavior on, check that it flies and fires. Send a Ctrl+B export of the configured Midge so the generator can copy the real AI-block XML.
8. **Gyro sign (T10), only for new scripts.** Flight and aim of the Hornet / Longbow scripts worked in earlier tests; confirm the same for Wasp / Lancer / Harrier / Aegis / Mantis (nose turns onto a stationary target).
9. **Runtime and IGC limits (T12).** Print `Runtime.MaxInstructionCount` on a PB; send an IGC test message between two antenna ships at 1 km and 10 km. Decides whether hive messages reach as far as the Watcher's 5000 m antenna implies.
10. **AI Behavior switch (v2.1).** Paste a Full Hornet, run `guard`, read the PB screen: `AI Behavior on (2 blocks)` means the script could switch the AI blocks on (check the AI Flight / AI Offensive terminal: AI Behavior ticked). `AI Behavior switch not found` means switch it on by hand (README "AI blocks"). Then put a pirate or enemy-faction ship 700-1500 m away and watch whether the drone turns to it within a few seconds (`AI: searching`, then `Target:`). Send the PB screen text either way.
11. **FOLLOW (v2.2).** Put `HornetMothership.cs` (any link) on a PB of your ship (with an antenna), paste 2-3 Hornets near it, run `follow` on each. Read a drone's PB screen: `Follow : ship ... m away`. Fly straight, turn, stop: the drones should keep a ring about 60 m behind you and never touch the hull. Then get out next to a Full drone: its screen should switch to `Follow : on foot`. Send the PB screen text and how far they lagged at your top speed.
12. **Rocket flight from a moving ship (v2.3).** Fly a Wasp or Basilisk sideways (strafe, nose still) at 50 m/s or more and fire one rocket (`ShootOnce`) at nothing. Watch it from the cockpit: if it **bends** onto the line straight ahead of the launcher, the default `Rocket Velocity Model=CAPPED` is right; if it flies **dead straight ahead** with no sideways drift, set `NONE`; if it keeps **drifting sideways** at your strafe speed all the way, set `FULL` (Custom Data of the Basilisk and Wasp, then `reload`). Then, against an AI ship with evasive manoeuvres on, read the PB screen's `Lead` line (`acc a/m for N s`: the target's acceleration and how long the solver holds it) and report roughly how many rockets hit.
13. **Kamikaze defence (v2.4).** Two Hornets (or any combat drones) in `hunt`, and 3-4 armed Stingers of another faction launched at them from about 1.5 km (`launch` on the Stingers; give them a target by locking it from a Hornet of their own side, or start them within 50 m sensor range). Watch the drones' PB screens: `!! KAMIKAZE` should appear, the drones should back away while firing and sidestep at the last moment. Report how many Stingers were shot down, how many exploded near a drone, and the PB screen text.
14. **Disarm (v2.4).** A drone merged on purpose to something else (carrier hangar) must not launch until the merge is released; run PB argument `disarm` to cancel auto-launch, `armed` to re-arm.
15. **SEEKER / subsystem targeting (v2.6, option 4).** You need an ENEMY grid with power blocks (its own turrets may be switched off). (a) Put `SeekerProbe.cs` on any PB of a ship with a turret (name the turret `[Seeker]`), run it, fly within the turret's range of an enemy ship. Read the PB screen: `group PowerSystems` (else `SET FAILED: ...`), `target ...`, `hitpos N m from centre` or `no hitpos`, `aim line passes N m from centre`, `hull hit N m from centre`. Run `group Weapons` and `group Propulsion` too. Copy the Custom Data log. (b) Paste a **Longbow L Seeker** (load artillery shells into its turret) 1.5-2 km from an enemy ship and `hunt`: its PB screen shows `Aim: BREACH ... (seeker)` and `Seek: ...`. Note whether the target has decoys. Send both screens/logs. Decides whether option 4 can work at all, and whether the game gives the block position directly (`hitpos`).

## Changelog

### v2.7 (unreleased): WARSHIPS Shrike, Corsair, Warden, Leviathan (new package `Warships_v2.7_Full` / `_Lite`)
- **Helm default mode REACT** (`ShrikeAI.cs`, mode 7 in the `.H2S` flags, `StaffAI.cs` shows it): combat-ready but passive until an AI alarm, a mate's alarm, damage or a held target wakes it. `Start Mode` default is REACT (the key name is unchanged). Four rarely used Custom Data keys were dropped to make room (`Target Large/Small Grids`, `Aim Kp/Kd`, `RTB Battery Fraction`); the Helm is 79,977 of 80,000.
- **Cockpit buttons `deploy` / `dock`** (Staff) on Warden, Leviathan and Corsair; the cradle bay PB keeps a docked drone's thrusters off and switches them on at release.
- **Walkways and entry** (Warden, Leviathan; Shrike and Corsair are cockpit-only): slide doors (`LargeBlockSlideDoor`, seen in the Tech Hunter sample) in both sides of the tower stem lead to a one-cell passage and shaft to the bridge and, on the Warden, through the hangar roof; the Leviathan also has a door into each hangar. `carve_walkway` / `route_walkway` / `walk_check` in `designs/_common.py` (the build asserts a walk from the outside door to the bridge and hangars).
- **Gravity generator** (large `GravityGenerator`, 1 g toward the ship's down, field over the crew spaces) on Warden and Leviathan Full (the Lite variants keep no unseen shape). Large grid only: the small-grid Corsair cannot carry one. The object-builder fields (`FieldSize`, `GravityAcceleration`) were never seen in a game file.
- **Round slopes / corners** in the concave edges of the big Leviathan rooms (`chamfer_room`); the Warden's rooms are too cramped to take any.
- **`<ConveyorLines>`** are now written for every face-adjacent ported pair (junction cubes, thrusters on tanks / junctions, turret / tank / locker terminals), as the game's own saves do. Suspected cause of ships that could not hold forward: without the lines the hydrogen network may not connect on paste. Not verified in the game.

New zips with four ships that fly by hand (sit in the seat) and by themselves, plus the Cradle Pod and the `Corsair Wing`, `Warden Wing`, `Leviathan Wing` variants with Hornets in the cradles.
Three scripts: `ShrikeAI.cs` (the Helm of every ship: Hornet brain + MANUAL mode + weapon batteries + dead-man heartbeat; 79,990 of its 80,000 characters), `StaffAI.cs` (heartbeat watch that releases every
override when the Helm dies, wing orders and roll call, hangar doors, drone launch, display pages) and `CradleBayAI.cs` (the merge-block cradles). The usage guide is the README of the Warships zips.
The drone zips no longer contain the warships (they moved to the new zips); the All zip has everything. All ships were run in the simulator only: nothing has been pasted into the game yet.
- Staff 1.4: `launch [n|a-b|all]` (parks the Helm so the bays' ship-turns / ship-accelerates gates pass, releases, gives the Helm its mode back); `[Staff] Turret Target Group` / `Turret Target Names`
  (artillery and assault turrets aim at the targets' weapons: Leviathan vs Pirate, kill time median 143 s -> 89 s in the sim; replaces the planned Gunnery PB).
- ShrikeAI: the integrity scan (hit direction) is sliced, 150 blocks per call (a 1,300-block ship read all of them in one tick: 58,000 IL instructions of the 50,000 limit; peak is now 25,000);
  a seat named `Gunnery` no longer switches the Helm to MANUAL (`[Manual] Seat Exclude`).
- Designs: the Helm Custom Data of every ship now carries the keys the scripts read (the old `[Battery n]` / `[Cockpit]` sections were read by nobody); large ships: stand-off 700 / 800 m, jinking off,
  AI-block search off (the AI Flight block made the idle warship wander); Warden / Leviathan Timer D renamed `Timer D (deadman)` (the Helm finds it by that word: they had none); the Shrike has a second forward camera
  (with one the nose camera was shot off and the Shrike never saw a Hornet again); the empty Gunnery PB of the Leviathan is gone.
- Simulator: warship scenarios (`ship/<Blueprint>-vs-<Enemy>`) start with the Custom Data the blueprint carries and keep a connector-docked pod rigidly on its host; `selftest m6`.

### v2.7 (unreleased): SATELLITE formation
New operating mode: the drones spread round a slowly turning vertical ring centred on the owner (a ship running a Mothership link, you on foot, or the Gnat's carrier /
home point), break off and engage anything inside the Engage Radius, and fly back to their slots afterwards. Command `satellite` / `sat` / `orbit`; ring distance
(`Satellite Distance`, default 100 m, grows with the number of ships), orbit period and plane are in the `[Follow]` Custom Data section. Details, numbers and tests:
`docs/follow-mode.md`. FOLLOW block v1.1 (`tools/follow_block.cs`); the Gnat has its own copy. Size: the Basilisk is now 99,733 of the 100,000 characters.

### v2.6 (this package): BREACH aim against big ships; SEEKER test ships
- **Script length fix (important).** A Programmable Block takes at most 100,000 characters; since v2.2 every armed drone script
  was over it (Hornet 155,629, Basilisk 175,054 characters with comments), so a pasted drone's PB could not hold its script. The
  blueprints and the zips' `Scripts/` folder now carry minified scripts (comments and whitespace removed only; `tools/minify_cs.py`,
  proven identical by compiling both and comparing the IL, `tools/minify_check.sh`; largest now Basilisk 97,721). The commented
  originals are in `Scripts/Source/`, for reading only: they are too long to paste. The build refuses a script over the limit.
Question from the user: against large battleships (their *Tech Hunter*) the drones "can't figure out where vital components are and
just shoot the hull". Study: `docs/tech-hunter-study.md` (1,280 simulated fights, fleets of up to 10 Hornet / Gnat / Longbow S /
Longbow L / Basilisk).
- **BREACH** (shared block `tools/aim_block.cs` in every armed drone script, synced by `tools/aim_sync.py`): against a large grid of
  radius >= 25 m, AUTO holds one hull point (the known one nearest the target's centre, where the armour over the core is thinnest),
  keeps every round on it, and aims down the hole as it deepens; stalled or missing points are swapped. Sim vs Tech Hunter: railgun
  drones destroy about twice as many power blocks (Longbow L 0.65 -> 1.2 per drone in 10 min), at the cost of fewer exposed turrets.
  `aim breach`, `breach on|off`; Custom Data `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`.
- **SEEKER (experimental, option 4)**: a turret on the drone named `[Seeker]` is set to `Seeker Group` (PowerSystems / Weapons /
  Propulsion); the script reads where it points and drills there. New test ships **Longbow L Seeker** (artillery turret, 2 km) and
  **Basilisk Seeker** (roof turret renamed); `scripts/SeekerProbe.cs` reports what any ship's turrets tell a script. In the sim it did
  not beat BREACH; the in-game API behaviour is the open question (test 23).
- Finding for fleet building: against a turret-heavy capital ship only Longbow L survives (2 km = artillery range); Hornets, Gnats and
  Basilisks die in under 70 s whatever they aim at. Nothing of 10 drones or fewer knocked the Tech Hunter out in 10 minutes.
- Simulator turret ranges as in the game: an AI turret on its own targets within its Range setting, at most 800 m for every
  large-grid turret (artillery and assault cannon included), 600 m small grid; a working AI Offensive/Defensive block on its grid
  unlocks the ammo range (artillery 2 km, assault cannon 1.4 km). Turn rates and elevation limits per turret type from the data
  (artillery 0.2 rad/s). Re-run vs Tech Hunter: Longbow S now survives too; with BREACH 10 of them destroy 4.2 power blocks (0.8 before).
- Simulator: turrets need power; only railguns have a capacitor (artillery / assault-cannon capacitors starved every turret of a big
  ship); turret targeting groups + Azimuth/Elevation API; enemy vitals in the results; `--enemy-fleets`.

### v2.5: foundry fixes (finish-welding, robust reach, automatic take-off, owner ids)
- **Finish-welding verification.** `HiveMotherAI.cs` 2.1 no longer leaves BUILD when the projector reports 0 blocks left (that only means "all placed", not "all welded"). A new FINISH state keeps every welder on until a full scan of the bay's drone box finds each block at full integrity and functional. Welders can no longer be switched off in BUILD/FINISH (the old stall "kick" that turned all welders off is gone; it now toggles one welder at a time). The LCD lists unfinished blocks (name, cell, integrity, distance to the nearest welder), reports off/damaged/unpowered welders and an empty `[Stock]`, and FINISH has a timeout that FAULTs with the list.
- **Robust welder reach.** The welder sphere centre is unknown (model dummy), so `reach.py` now checks 8 hypotheses (centre at the tip, 1, 2 or 3 cells inside the welder; radius 1.3 m and 1.0 m), a build-order support check and a foreign-bay check. Hornet-class bays now carry 10-12 welders (was 5-8), Gnat bays 7 (was 5). Exit directions were re-chosen per drone. Costs about +900 PCU and +2.7 t per Hornet-class bay. Per-bay Custom Data gains `Drone Box Min/Max`, `Drone Cell Count`, `Drone Occupied Cells`, `Ignore Cells`, an explicit `Exit Direction`, and a `[Launch]` section.
- **Automatic take-off.** A shared LAUNCH block (`tools/launch_block.cs`, synced by `tools/launch_sync.py`) is in the Hornet, Gnat, Longbow, Mantis, Wasp, Lancer, Harrier, Aegis and Basilisk scripts. A printed drone launches when its own PB sees the merge pair open, or on `[Launch] Armed=true`, `_JOIN`, FLEET `join`, or the arguments `armed` / `launch` / `disarm`. No single message is needed. It burns away from the printer for `Burst Seconds`, then goes home and into its start mode (default GUARD). The printer writes `[Launch]` into the drone PB before release, repeats `_JOIN` for 40 s and recompiles the drone PB.
- Known limit: Gnat only thrusts forward/back, so a lateral Away direction does not move it in the sim (see docs/launch-protocol.md). The Stinger script is not yet integrated with the LAUNCH block.
- Docs: `docs/foundry-notes.md`, `docs/welder-reach.md`, `docs/launch-protocol.md`, `docs/hive-protocol.md` section 9.
- **Owner / built-by ids.** Blueprints now carry Owner and BuiltBy (the in-game PB showed `Owner: Nobody` because none were written). Already-pasted v2.x ships: select all blocks in the terminal and Transfer to yourself.

### v2.4 : kamikaze defence
Simulated attacks by swarms of small warhead drones (4 and 8 Stingers cued by a carrier's radar, against every combat drone model) showed the
scripts writing the kamikazes off as wrecks. A Stinger correcting its course at the speed cap spins 1-2 rad/s, so the "tumbling for 4 s" rule
dropped it, ignored it for 120 s and told the whole hive it was finished, usually just before it arrived.
- **KAMIKAZE DEFENCE** (shared block in every combat drone script, `tools/kz_block.cs`, synced by `tools/kz_sync.py`; scripts 2.6 / Gnat 1.13
  / Longbow 2.4; details in `docs/kamikaze-defence.md`):
  - small contacts on a collision course with the drone or a hive mate are never written off as wrecks, and are dropped once spent;
  - they become the priority target;
  - the drone backs away along the threat axis while its guns stay on target, and breaks sideways inside 2 s of impact;
  - spare camera charge tracks the rest of the swarm and searches round known kamikazes for their pack;
  - the threats are shared with the hive, and Gnats skip their run-in against a kamikaze.
  New `[Kamikaze Defence]` section in Custom Data; PB screen line `!! KAMIKAZE x3 (2 at me) next 4.2 s 380 m`.
- Simulator, 620 kamikaze fights (20 seeds): defenders still fighting at the end 57% -> 70%, damage taken -41%. Against 4 Stingers, a lone
  Hornet goes 50 -> 80%, Lancer 45 -> 85%, Mantis 35 -> 75%, Longbow S 55 -> 80%. Fights without kamikazes are unchanged (1v1 regression in the doc).
- Simulator: scenario kind `kamikaze`, settings `SwarmCueSeconds` / `SwarmCueTeam`, `one --echo-every S`, report tool `tools/kz_report.py`.

### v2.3: lead aiming against manoeuvring targets
In-game report (2026-10-13): the Basilisk's rockets kept missing an enormous target that was doing basic evasive manoeuvres. A rocket
needs about 4 s to fly 800 m; an AI ship on "evasive" flips its strafe every 2-5 s. Full write-up and measurements: `docs/lead-v1.md`.
- **LEAD v1.0** (shared block in every armed drone script, `tools/lead_block.cs`, scripts v2.5 / Gnat 1.12 / Longbow 2.3):
  - the target's freshest acceleration, held only for as long as its manoeuvres usually last, then constant velocity (the old
    solver extrapolated a lagging, smoothed acceleration over the whole flight);
  - the hull aim point counts only across the line of fire, turns with the target's spin for up to 1 s, and keeps
    `Aim Margin (predicted misses)` x the predicted miss of known hull round it, so long, uncertain shots go to the middle of the
    known hull instead of its edge.
- Basilisk / Wasp: rockets modelled as leaving with the ship's velocity + launch speed and curving onto the barrel line
  (`Rocket Velocity Model` CAPPED / NONE / FULL; NONE is the v2.2 model). Closed-form rocket path, Newton solve on the flight time.
- Offline bench (`tools/lead_bench`), hits on manoeuvring targets: rockets 50 % -> 62 % (strafing 120 m ship 43 -> 66 %, strafing
  30 m ship 14 -> 39 %), gatling 70 % -> 90 %, railgun 77 % -> 90 %.
- Simulator: rockets inherit the shooter's velocity with the speed cap (`--rocket-inherit`, default 1), evasive Pirate
  (`--pirate-evasive true`).

### v2.2: FOLLOW mode
Question from the user: does `guard` follow the owner? Only as a side effect: a Mothership link's position replaces the guard spot, but
the drones fly to the ship's centre (into its hull for most drone types), lag behind a moving ship, and fall back to the old spot when
the link stops. Nothing followed a player on foot.
- **FOLLOW** (shared block in every scripted combat drone, `tools/follow_block.cs`, synced by `tools/follow_sync.py`): `follow` / `escort`
  command (also Start Mode and launch Mode `FOLLOW`). The owner is the ship running a Mothership link (any type, FLEET channel), or the
  owner's own character seen by the drone's sensor (on foot, ~50 m; wins while seen). Each drone flies its own slot on a ring behind the
  owner (upper half in gravity) outside its hull, with the owner's velocity fed forward (estimated from the link's position fixes, so old
  link scripts work), detours round the hull instead of through it, engages only targets within 800 m of the owner, breaks off past
  1.2 km (2.2 km for the snipers), and after a link loss coasts 3 s on the owner's track (10 s on foot) and holds there. On a
  collision course with the owner it sidesteps up to 8 s ahead, and the ring widens (up to 2x) while the owner manoeuvres hard.
  New `[Follow]` section in Custom Data. No AI-block search in FOLLOW (the AI Flight block would fly the drone away from you).
- Gnat 1.11: `follow` / `escort` = `form`; the formation now matches the link ship's velocity (keeps up with it), and also reads the
  ship radius from the FLEET channel.
- Mothership links (Hornet / Longbow v1.1, Gnat v1.2): send the ship's radius on `<Tag>_HOMER` and `<fleet>_HOMER`; `follow` relays.
- FLEET block: `follow` and `escort` added to the default `Allowed Commands`.
- Simulator: `follow-test` (moving owner on the fleet channel, or an owner character reported to the sensors; cruise, weave, link loss,
  on foot, fight).

### v2.1: first in-game report fixes
In-game report (2026-10-13): Full drones set to `guard` stood still; `hunt` drones waited about 20 s, then all flew off the same way
and never saw a pirate ship 700 m away. Cause: the AI blocks paste with **AI Behavior off**, so they do nothing, but the scripts handed
them the ship and switched their own camera search off while waiting for them. Reproduced in the simulator (AI blocks inert:
3 Hornets vs pirate at 700 m won 0 of 40, found the pirate in 1 of 40 runs).
- **AI GATE** (shared block in every scripted drone, `tools/ai_gate_block.cs`): the script tries to switch AI Behavior on itself
  (the PB screen says whether it could). Until the AI blocks have flown the ship once, they only get it in 6 s windows between 8 s
  of the script's own camera search (under fire the script searches); once they have, they are trusted as before (status `AI ok`).
  New `[AI Gate]` section in Custom Data.
- Side cameras scan out to 900 m whenever there is no target (was 120 m); short close-scan rays no longer drain the nose cameras
  below the long scan's range while under fire.
- Hit direction: the blocks that lose integrity tell which side was hit; the nose sweep and the side cameras search that side.
- HUNT search patrol: drones fan out (each starts its square at a different corner), keep sweeping their cameras on a leg instead of
  looking along the flight path, hold position at listening stops, and Lite drones (no AI blocks) patrol too.
- Simulator results (pirate ship 700 m away, 36 pirate scenarios x 20 seeds, every model): AI blocks doing nothing, `hunt`: drone
  side wins 23 -> 44 of 720, `guard`: 24 -> 47 of 720 (3 Hornets alone: found the pirate in 1 -> 15 of 40 fights); AI blocks that
  need the AI Behavior switch: 23 -> 211 of 720 (the script switches it on). With working AI blocks drone-vs-drone results are
  unchanged (1v1 without the Watcher, 1,560 fights: 77.6 % -> 77.4 % decisive). The unarmed Watcher (no AI blocks) now patrols in
  `hunt` like every drone without AI blocks, so armed drones catch it less often (Watcher fights 60 % -> 24 % decisive).
- Simulator: `--script-ai-blocks-inert` (AI blocks never act) and `--ai-behavior-needs-switch` (AI blocks act only once a script
  switches "ActivateBehavior" on); `GetProperties`/`GetActions` on terminal blocks.

### v2.0
- Every model exists as Full and **Lite** (Lite: only block XML shapes seen in a game-written ship, plus the merge block). Both variants build, validate and ship from one generator (`tools/build_all.py`).
- Blueprint generator rewritten around real data: mount-point validation (checked against the Starburst ship), real masses and costs from `defs_stats.json`, `<Toolbar>` written for Sensor/Timer/Turret Controller/Event Controller (probable paste-failure fix), Custom Data stored in ModStorage (the old `<CustomData>` element was ignored by the game), unique blueprint ids, stable (crc32) seeds, no `.sbcB5`.
- Weapon data corrected from the local game files: gatling 700 rpm, 800 m/s (was 400).
- Merge block clamp face corrected: small 1x1x1 block clamps toward Up (was Right); Hornet, Gnat and every printable drone got a clear docking face.
- New drones: **Wasp** (rockets), **Lancer** (autocannon), **Watcher** (unarmed scout), **Harrier** (interceptor), **Aegis** (escort / point defence), **Mantis** (railgun + gatling), **Basilisk** (large-grid rocket gunship), **Midge** (scriptless, experimental).
- New printers (projector + welders + merge block bays, `HiveMotherAI.cs` 2.0): Hive Mother, Twin Hive, Quad Hive, Hornet Forge, Wasp Foundry, Lancer Foundry, Longbow Foundry, Harrier Forge, Aegis Shipyard, Mantis Foundry, Watcher Pad, Fleet Forge, Escort Carrier, Mobile Hive, Static Nest, Stinger Rack.
- Hornet: rear camera moved one cell up to make room for the docking stalk. Gnat: merge block on a 2-cell stalk under the belly.
- Printers: every bay now has an exit lane. Before, Hornet-class bays (Hornet, Wasp, Lancer, Longbow S, Harrier, Aegis, Mantis, Watcher) had a welder on every side of the drone, so the finished drone could not leave. The drone's footprint swept 14 cells away from the merge block is kept free; Longbow S and Mantis leave sideways (outwards, away from the neighbour bay) and HiveMotherAI.cs reads the new per-bay `Exit Direction` Custom Data key to nudge the printer the right way.

### v1.x history
- **v1.0**: Hornet (gatling), Longbow S/L (railgun), Gnat (2-thruster swarm), mothership relays.
- **v1.1**: sensors added; nothing pasted.
- **v1.2**: sensor removed; Longbow stopped reading railgun power.
- **v1.3**: steadiness-gated lead, `Lead Scale`.
- **v1.4**: 5 extra cameras + all-around close scan; compact embedded scripts (size theory later disproven).
- **v1.5**: disabled-target detection, damage sensing and evasion, split focus, on-screen errors.
- **v1.6**: hull-point aim modes.
- **v1.7**: AI-block search hand-off (user places `[AI]` blocks).
- **v1.8** (uncompiled in-game): printer join / re-scan on grid change, Hornet scout mode.
