# Space Engineers drone printers v2.7 (Full)

Drone printers in their **Full** design. Each projector holds the **Full** drone; Full printers also carry two component-stock cargo containers.

Package contents: 16 printer blueprints. All printers are **dynamic** small-grid ships; **no DLC blocks**.

A printer is a pod (large battery, remote control, Programmable Block running `HiveMotherAI.cs`, gyros, antenna, thrusters in all six
directions) with docking bays on stalks. A bay is a projector `[Bay N]` (the drone blueprint is pre-loaded, Keep Projection on), welders
`[Bay N]` and a merge block `[Bay N]`. The cycle per bay is BUILD (welders on until nothing is left to build), CHARGE (the drone shares
the printer's power and its PB is recompiled), RELEASE (merge blocks off, the printer nudges away, `<Tag>_JOIN` is broadcast) and
COOLDOWN. Printed drones then start working by themselves.

## Install

1. Unzip this package anywhere. You get `Blueprints/<Name>/{bp.sbc,thumb.png}`, `Scripts/*.cs` and this README. The scripts in
   `Scripts/` are compacted (no comments) so they fit the Programmable Block's 100,000-character limit: paste those. The commented
   originals in `Scripts/Source/` are for reading only and are too long to paste.
2. **Delete the old blueprint folders first.** Open `%AppData%\SpaceEngineers\Blueprints\local\`, and remove every folder of an earlier
   version of these ships (Hornet, Gnat, Longbow ..., also their `bp.sbcB5` files). The game caches a binary `bp.sbcB5` next to `bp.sbc`
   and keeps loading the stale copy if it is still there. This package never ships a `.sbcB5`.
3. Copy the `Blueprints/<Name>` folders you want into `%AppData%\SpaceEngineers\Blueprints\local\`.
4. In game: press **F10** (blueprint screen), pick the ship, and paste it into the world (creative tools, or load it into a projector in a
   survival world).
5. Every ship is pasted as a **dynamic** small-grid ship (a large-grid ship for the Basilisk). Do not convert printers to a station: a
   static printer would make every printed drone static.
6. Check that "In-game scripts" is enabled in the world settings, otherwise the Programmable Blocks do not run.
7. If something does not paste, send the game log (`%AppData%\SpaceEngineers\SpaceEngineers_*.log`) and say which model and variant.

**Which variant?** `<Name>` (Full) uses the whole design, including block types whose XML has never been seen in a game-written
blueprint (Sensor, AI blocks, Decoy, cargo containers, turret). `<Name> Lite` uses only block types whose XML shape is copied from a
game-written ship (the Starburst reference), with the one exception noted under "Known unknowns" (the small merge block). If a Full ship
does not paste, try its Lite twin: it must still fly and fight. No ship uses DLC blocks.

## Models

| Model | Variant | Blocks | Mass kg | Accel m/s2 | PCU | Script |
|---|---|--:|--:|--:|--:|---|
| Aegis Shipyard | Full | 333 | 21579 | 1.3 | 4738 | AegisAI, HiveMotherAI |
| Escort Carrier | Full | 326 | 47702 | 0.9 | 5337 | HiveMotherAI, HornetDroneAI |
| Fleet Forge | Full | 424 | 30368 | 1.4 | 7277 | GnatSwarmAI, HiveMotherAI, HornetDroneAI |
| Harrier Forge | Full | 303 | 20979 | 1.4 | 4708 | HarrierAI, HiveMotherAI |
| Hive Mother | Full | 221 | 15055 | 1.9 | 3136 | GnatSwarmAI, HiveMotherAI |
| Hornet Forge | Full | 313 | 21179 | 1.4 | 4718 | HiveMotherAI, HornetDroneAI |
| Lancer Foundry | Full | 329 | 21499 | 1.3 | 4734 | HiveMotherAI, LancerAI |
| Longbow Foundry | Full | 298 | 20879 | 1.4 | 4703 | HiveMotherAI, LongbowSniperAI |
| Mantis Foundry | Full | 331 | 21539 | 1.3 | 4736 | HiveMotherAI, MantisAI |
| Mobile Hive | Full | 361 | 25430 | 2.3 | 5790 | GnatSwarmAI, HiveMotherAI |
| Quad Hive | Full | 589 | 42110 | 1.0 | 10716 | GnatSwarmAI, HiveMotherAI |
| Static Nest | Full | 453 | 31209 | 0.0 | 8000 | GnatSwarmAI, HiveMotherAI |
| Stinger Rack | Full | 352 | 24038 | 1.2 | 5649 | HiveMotherAI, StingerAI |
| Twin Hive | Full | 349 | 23978 | 1.2 | 5646 | GnatSwarmAI, HiveMotherAI |
| Wasp Foundry | Full | 313 | 21179 | 1.4 | 4718 | HiveMotherAI, WaspAI |
| Watcher Pad | Full | 319 | 21299 | 1.4 | 4724 | HiveMotherAI, HornetDroneAI |

### Aegis Shipyard

2 bays, prints Aegis escorts (4 gatlings, decoys).

* **Aegis Shipyard**: 333 blocks, 21579 kg, 22.0x7.5x12.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4738, 2 bays / 24 welders; script: AegisAI.cs, HiveMotherAI.cs; cost Iron 21872 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Escort Carrier

Hornet bays + heavy armour, 4 fixed gatlings and the turret-target relay.

* **Escort Carrier**: 326 blocks, 47702 kg, 20.0x7.5x11.0 m, accel F0.9 B0.9 U0.9 D0.9 L0.9 R0.9 m/s2, PCU 5337, 2 bays / 24 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 52326 Nickel 3115 Cobalt 1815 Silicon 56 Gold 18 Platinum 7

### Fleet Forge

mixed bays: 2 Gnats on top, a Hornet and a Watcher in front.

* **Fleet Forge**: 424 blocks, 30368 kg, 14.5x12.5x17.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 7277, 4 bays / 38 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 30874 Nickel 510 Cobalt 180 Silicon 60 Gold 18 Platinum 7

### Harrier Forge

2 bays, prints Harrier interceptors.

* **Harrier Forge**: 303 blocks, 20979 kg, 18.5x8.0x12.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4708, 2 bays / 24 welders; script: HarrierAI.cs, HiveMotherAI.cs; cost Iron 21242 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Hive Mother

2 bays, prints Gnats (swarm drone).

* **Hive Mother**: 221 blocks, 15055 kg, 10.0x11.0x5.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 3136, 2 bays / 14 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 15140 Nickel 250 Cobalt 120 Silicon 49 Gold 12 Platinum 5

### Hornet Forge

2 bays, prints Hornets (twin gatling fighters).

* **Hornet Forge**: 313 blocks, 21179 kg, 20.0x7.5x11.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4718, 2 bays / 24 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 21452 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Lancer Foundry

2 bays, prints Lancers (autocannons).

* **Lancer Foundry**: 329 blocks, 21499 kg, 20.0x7.5x12.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4734, 2 bays / 24 welders; script: HiveMotherAI.cs, LancerAI.cs; cost Iron 21788 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Longbow Foundry

2 big bays, prints Longbow S railgun snipers (docking stalk added by printer_lib.with_latch).

* **Longbow Foundry**: 298 blocks, 20879 kg, 16.5x12.5x9.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4703, 2 bays / 24 welders; script: HiveMotherAI.cs, LongbowSniperAI.cs; cost Iron 21136 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Mantis Foundry

2 bays, prints Mantis hybrids (railgun + gatling; docking stalk added).

* **Mantis Foundry**: 331 blocks, 21539 kg, 19.5x15.5x8.5 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 4736, 2 bays / 24 welders; script: HiveMotherAI.cs, MantisAI.cs; cost Iron 21830 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Mobile Hive

4 Gnat bays and 4 ion thrusters per direction: keeps up with its brood.

* **Mobile Hive**: 361 blocks, 25430 kg, 10.0x11.0x15.5 m, accel F2.3 B2.3 U2.3 D2.3 L2.3 R2.3 m/s2, PCU 5790, 4 bays / 28 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 25752 Nickel 410 Cobalt 240 Silicon 56 Gold 24 Platinum 10

### Quad Hive

8 compact bays in a 4x2 array, prints Gnats.

* **Quad Hive**: 589 blocks, 42110 kg, 20.0x11.0x15.5 m, accel F1.0 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 10716, 8 bays / 56 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 42976 Nickel 730 Cobalt 180 Silicon 70 Gold 18 Platinum 7

### Static Nest

6 Gnat bays, no thrusters: a stationary hive (still a DYNAMIC grid; never convert it to a station).

* **Static Nest**: 453 blocks, 31209 kg, 15.0x10.0x15.5 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 8000, 6 bays / 42 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 31866 Nickel 570 Silicon 63

### Stinger Rack

RACK MODE: 4 Stingers stay docked; one is released per enemy sighting and told to launch.

* **Stinger Rack**: 352 blocks, 24038 kg, 12.5x9.5x18.0 m, accel F1.2 B1.2 U1.2 D1.2 L1.2 R1.2 m/s2, PCU 5649, 4 bays / 28 welders; script: HiveMotherAI.cs, StingerAI.cs; cost Iron 24400 Nickel 410 Cobalt 120 Silicon 56 Gold 12 Platinum 5

### Twin Hive

4 bays in a 2x2 array, prints Gnats.

* **Twin Hive**: 349 blocks, 23978 kg, 10.0x11.0x15.5 m, accel F1.2 B1.2 U1.2 D1.2 L1.2 R1.2 m/s2, PCU 5646, 4 bays / 28 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 24336 Nickel 410 Cobalt 120 Silicon 56 Gold 12 Platinum 5

### Wasp Foundry

2 bays, prints Wasps (rocket launchers).

* **Wasp Foundry**: 313 blocks, 21179 kg, 20.0x7.5x11.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4718, 2 bays / 24 welders; script: HiveMotherAI.cs, WaspAI.cs; cost Iron 21452 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5

### Watcher Pad

2 bays, prints unarmed Watcher scouts (feed the HORNET hive).

* **Watcher Pad**: 319 blocks, 21299 kg, 20.0x7.5x11.5 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4724, 2 bays / 24 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 21578 Nickel 350 Cobalt 120 Silicon 53 Gold 12 Platinum 5


## Configure and command

### AegisAI.cs (v2.6-aegis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Extra Home Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Max Fire Range vs Huge Grids`, `Standoff Range vs Huge Grids`, `Standoff Range`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Screen Distance From Carrier`, `Carrier Radius`, `Hold Radius`, `Tether Radius`, `Target Missiles`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### GnatSwarmAI.cs (v1.13+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `form`
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `attack`
* `hunt`: chase and engage any target, actively scan
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (FORM/ATTACK/IDLE)`, `Projectile Speed`, `Fire Range`, `Closing Speed`, `Run-in Start Range`, `Back-off Speed`, `Orbit Speed`, `Back-off Range`, `Re-close Range`, `Emergency Break Range`, `Attack Cone Degrees`, `Max Sideways Drift m/s`, `Formation Radius`, `Satellite Distance (m)`, `Satellite Orbit Period (s)`, `Separation Radius`, `Engage Radius From Home`, `Combat Speed`, `Cruise Speed`, `Velocity Gain`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `RTB Battery Fraction`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Lead Scale (1 = calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false = focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire (s)`, `Raid Fan Half-angle Degrees`, `Raid Scan Cone Degrees`, `Raid Scan Ray Length`, `Raid Speed`, `Raid Max Travel`, `Raid Bearing Memory Seconds`, `Raid Start Confidence`, `Raid Hold Confidence`, `Listen To IGC Tags (target feeds)`, `Scan Range`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`.


### HarrierAI.cs (v2.6-harrier)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Small Target Standoff Fraction`, `Target Priority Small Bonus`, `Target Priority Large Penalty`, `Target Priority Fast Closer Bonus`, `Target Priority Missile Bonus`, `Target Missiles`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### HiveMotherAI.cs (v2.2)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `start`: start printing
* `stop`: stop printing, all welders off
* `max`: `max <n>` set Max Drones
* `release`: printers: `release [bay]` release finished drones; warship Staff / bay PBs: `release <n|a-b|all> [delay_s] [force]` let go of clamped drones (waits for a calm ship unless `force`)
* `hold`: `hold <bay>` keep a bay paused
* `unhold`: `unhold <bay>` resume a bay
* `relay`: `relay on|off` forward carrier turret targets
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Hive Mother]` keys: `Max Drones (all tags)`, `Rack Mode (keep docked, launch on targets)`, `Rack Launch Command Tag`, `Rack Target Tags (enemy sightings that release a drone)`, `Max Charge Seconds`, `Cooldown Seconds`, `Stall Warning Seconds`, `Build Timeout Seconds`, `Fault Retry Seconds`, `Parallel Builds`, `Recompile Drone PB Before Release`, `Recompile Wait Seconds`, `Release Nudge Seconds`, `Release Nudge Power (0-1)`, `Release Gap Seconds`, `Drone Match Radius m`, `Finish Timeout Seconds`, `Finish Fallback Seconds (used only without Drone Box keys)`, `Arm Max Seconds`, `Join Seconds (join is re-sent every 2 s, minimum 30)`, `Fused Grace Seconds`, `Launch Burst Seconds`, `Fleet Channel (join command for freshly released drones, blank = off)`, `Fleet Secret`, `Relay Turret Targets To All Tags`, `Auto Start`.

Custom Data `[Bay N]` keys: `Tag`, `Prefix`, `Max Alive`, `Max Prints`, `Hold`, `Exit Direction (printer axis the drone leaves along, blank means straight away from the merge block)`, `Skip Finish Check`, `Launch Burst Seconds`, `Drone Cell Count`, `Drone Cell Tolerance`, `Drone Box Min`, `Drone Box Max`, `Ignore Cells`.


### HornetDroneAI.cs (v2.6-hornet)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LancerAI.cs (v2.6-lancer+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Burst Seconds`, `Burst Pause`, `Conserve Below Shells`, `Conserve Max Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LongbowSniperAI.cs (v2.4)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### MantisAI.cs (v2.6-mantis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Engage Cap`, `Use Gatling`, `Gatling Projectile Speed`, `Gatling Range`, `Gatling Fire Window Multiplier`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Aim Margin (predicted misses)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### StingerAI.cs (v1.1)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `abort`: abort and release
* `disarm`: disarm the warheads
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `Listen To IGC Tags`, `Own Command Tag`, `Auto Launch When Released`, `Max Target Distance`, `Arm Warheads Within`, `Never Arm Within This Of Launch Point`, `Max Speed`, `Target Large Grids`, `Target Small Grids`, `Target Neutral/Unowned`.


### WaspAI.cs (v2.6-wasp+launch)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `armed`
* `launch`: Stinger rack: leave the dock and hunt; warship Staff: `launch [n|a-b|all] [force]` park the Helm, release the bays, hand the Helm its mode back
* `disarm`: disarm the warheads
* `guard`: hold the home point, engage anything inside Guard Radius
* `follow`
* `escort`
* `satellite`
* `sat`
* `orbit`
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point (AUTO / BREACH / ENGINES / FACING / SPREAD / CENTER)
* `breach`: `breach on|off` AUTO drills one hole into big ships (v2.6)
* `seeker`: `seeker on|off` let a [Seeker] turret guide the aim (v2.6, experimental)
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Rocket Velocity Model (CAPPED/NONE/FULL)`, `Aim Margin (predicted misses)`, `Max Fire Range`, `Max Flight Time`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Jink Gate Radius Factor`, `Jink Gate Min Miss (m)`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range`, `Standoff Range (unlimited rockets)`, `Max Fire Range (unlimited rockets)`, `Max Flight Time (unlimited rockets)`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`, `Seeker Group (PowerSystems/Weapons/Propulsion)`, `Seeker Turret Guides Aim`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Boresight Rays (of 8)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `AI Confirm Cone Yaw (deg)`, `AI Confirm Cone Pitch (deg)`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.



Before the first start: put the component stock for the drone into the `[Stock]` cargo (Full printers) or into the welders (the needed
components are listed as `;` comment lines at the top of the PB Custom Data). Then run the printer's PB with `start`.

## Known unknowns

- **Merge-block clamp face (unverified).** The small 1x1x1 merge block (`SmallShipSmallMergeBlock`) clamps toward its local **Up** face (one wiki source); the old assumption was Right. Every merge pair in this package is built on that. It is one constant (`MERGE_CLAMP_FACE_SMALL` in `tools/designs/_common.py`); if the merge-face test (T1) shows another face, change it and run `tools/build_all.py` again.
- **Lite variants keep the small merge block.** Its XML shape comes from the Keen source, not from the Starburst reference, so strictly a Lite ship is not 100 % "seen" XML. A drone or printer without it cannot be printed or docked. `LITE_KEEPS_MERGE = False` in `_common.py` drops it from the drones.
- **XML shapes never seen in a game-written blueprint:** Sensor, the AI blocks (Offensive, Flight, Defensive), Decoy, large gatling turret, Timer and Event Controller toolbars. They are why Full variants exist next to Lite ones. Earlier blueprints with a Sensor or Custom Turret Controller failed to paste; the leading hypothesis is a missing `<Toolbar>` element (now always written), but that is not confirmed.
- **Projected Programmable Blocks.** A welded PB may keep its Program text but not start by itself. The printer script calls `ApplyAction("Recompile")` on it; whether that works is the projected-PB test (T5, T6).
- **No ammunition is pre-loaded** in any gun or launcher (the generator cannot write inventories). In a survival world load magazines / rockets by hand; in a creative world the guns may still need magazines unless the world has infinite ammunition switched on (test T8 shows which). Scripts treat an unknown ammo count as unlimited and never return to base for lack of ammo in that case.
- **Scripts have never run in the game with these versions.** They compile against a hand-written stub of the game API (`tools/compile_check.sh`), which proves syntax and types only.
- **Weapon numbers** come from the local game data (gatling 700 rpm, 800 m/s, 800 m; small rocket 500 damage, 4 m blast; small railgun 1000 m/s, 1400 m, 500 ms shot delay). Rockets are assumed (v2.3) to leave with the shooter's velocity plus their launch speed, accelerate along the barrel and have their total speed capped, so a rocket fired from a moving ship curves onto the barrel line (Keen bug tracker). Test 18 in the test list checks it; if your rockets fly dead straight from a ship moving sideways, set `Rocket Velocity Model=NONE` on the Basilisk and Wasp.
- **Fused grid (biggest risk).** Blocks welded from a projection become part of the *projector's* grid. After switching both merge blocks off the drone may still be on the printer's grid. `HiveMotherAI` checks this at run time; if the drone is still on the printer's grid it sets the bay to FAULT with a "FUSED" message and sends no `_JOIN`. The fused-grid test (P1) decides.
- **Welder reach is modelled, not measured:** the welder's work sphere centre comes from a model dummy we cannot read. v2.1 checks 8 guesses (centre at the tip face or 1 to 3 cells inside the welder, radius 1.3 m or 1.0 m); the outer hull is covered under all of them, deep core blocks (batteries, gyro, remote) only under the shallow ones. If the real centre is deeper, bays stall in FINISH with `N unfinished`, and the LCD lists which blocks.
- **Hornet-class drones need touching welders.** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis, Mantis and Longbow S are 6 to 7 cells across, so their interior blocks can only be reached by welders whose tips touch the drone surface (a welder tip has no mount point, so no block attaches, but the surfaces do touch). If touching causes a permanent merge, use the Gnat-class printers (Hive Mother, Twin Hive, Quad Hive, Mobile Hive, Static Nest, Stinger Rack), which keep a full cell of air.
- **No conveyors.** The component stock must sit in a cargo container touching a welder's port, or in the welders themselves. A creative world may not need components at all (unconfirmed). The components needed per drone are listed as comment lines at the top of the PB Custom Data.
- **Cargo containers** (Full printers) have a guessed shape and volume; the Escort Carrier Full also has a guessed `SmallGatlingTurret`. Lite printers have neither.
- **Stinger Rack** prints a minimal fallback Stinger (Gnat frame, two warheads, `StingerAI.cs`) because there is no dedicated Stinger design module.
- Printers are heavy (about 13 to 36 t) and slow to turn; the Static Nest has no thrusters at all (it is still a dynamic grid). Timer / Event-Controller printers ("Midge Nest" and friends) are **not** part of this release.
- **Power budget and run time (computed from `defs_stats.json`, not measured).** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis: 4 small batteries = 0.2 MWh and at most 0.8 MW output; the 12 thrusters could draw 2.4 MW, so a burn on all three axes at once is capped at about 67 % thrust, and a one-axis burn (2 thrusters, 0.4 MW) lasts about 30 minutes. Gnat and Midge Lite: 1 battery = 0.05 MWh and 0.2 MW, i.e. about 15 minutes with the one thruster at full power. Longbow S and Mantis: one 3x2x3 battery = 1 MWh, 4 MW. Longbow L: 12 MWh, 48 MW against 40 MW of thrusters. Power drawn by guns, railgun charging, antenna range and welders is not in the game files, so it is not in these figures. There is no generator or solar panel on any drone: once the batteries are empty the drone is dead weight (`RTB Battery Fraction` sends it home before that).
- **Space only.** Thrust is ion thrust with no gravity term: the best drones accelerate at 6 to 7 m/s2 (Harrier 12 m/s2 forward only), which is less than 1 g (9.81 m/s2), and ion thrusters lose most of their force in an atmosphere. None of these ships can lift off or hover over a planet. Use them in space or at the edge of low gravity. Masses are component masses only; magazines, rockets and cargo add weight.
- **A printed drone leaves with a nearly empty battery.** The CHARGE phase lasts at most `Max Charge Seconds` (default 25 s). A small battery charges at 0.2 MW, so 25 s adds only about 3 % of its 0.05 MWh; a full recharge of a Hornet's 0.2 MWh from the printer's 4 MW pack takes about 15 minutes. A freshly welded battery starts at its definition's initial charge (30 %, unverified for welded blocks), so expect a drone to leave with roughly one third of its endurance (about 10 minutes of one-axis burn for a Hornet class, 5 minutes for a Gnat). Raise `Max Charge Seconds` in the PB Custom Data if you can wait. Drones that return to the printer are not re-docked or recharged by the scripts.
- **PCU.** The table's PCU is the printer alone (welders cost 150 each). Every printed drone adds roughly 700 to 1,700 PCU, and every projected block counts 1 PCU while it is projected. A world with a low block limit (survival defaults) will refuse to paste a Quad Hive (8,381 PCU) or Static Nest (6,244 PCU).
- **Script size headroom is small.** Minified, the Basilisk script is 97,721 of the 100,000 characters a Programmable Block takes (Wasp 95,313, Mantis 94,623). The build stops with an error when a script goes over; the next big feature will need code moved out or trimmed.

## In-game tests (do them in this order)

1. **World settings and cache (T13, T14).** "In-game scripts" on. Old blueprint folders deleted. Paste once with a stale `bp.sbcB5` left in a folder to see whether it matters. Decides: cause 1 of "script missing after paste".
2. **Paste the Lite twins first** (`Gnat Lite`, `Hornet Lite`, then the rest of the Lite set). Pass: it pastes, no floating blocks (cut one block with a grinder; thrusters, cameras, gyro, PB and antenna must stay), the PB's Edit window shows the code, its Custom Data shows the ini section, no DLC warning. Decides: the generator's basic XML (ComponentContainers, ModStorage custom data, orientation) is right.
3. **Paste the Full variants.** Same checks. If a Full ship fails and its Lite twin pastes, the unseen block shapes (Sensor, AI blocks, Decoy, cargo, turret) are the cause (T2, T11): send a Ctrl+B export of a small grid that holds one each of Timer, Sensor, Turret Controller, Event Controller, AI Offensive / Flight / Defensive, Merge Block, Projector, Welder, Warhead.
4. **Merge face (T1).** On two small grids put two `SmallShipSmallMergeBlock`s with their Up faces towards each other (and separately Right towards Right) and see which pair turns yellow / merges. Then check a drone's merge latch against a printer bay.
5. **Release (T3).** Merge two blocks; switch the drone-side one off, then the printer-side one off. Decides which side can release (needed by the printers; also by hand docking).
6. **Dynamic printer (T4).** Merge a dynamic printer with a drone and unmerge. Repeat with a static one if you want to see the trap.
7. **Pre-loaded projection.** In the printer, the projector must show the drone at the merge block (offset and rotation as generated), with Keep Projection on. Weld one block by hand and check the welded block lines up with the projection.
8. **Welder reach and finish (v2.1).** Switch on one bay and watch the printer LCD. After BUILD shows `0 left` it must show FINISH with a scan percentage, and the welders must keep running until it reads `0 unfinished`; only then CHARGE. The bay now checks 8 guesses for where the welder's work sphere is centred, so a stall means the real centre is deeper than all of them or a block is blocked. In the PB's Show on screen / the LCD, FINISH lists every unfinished block with its name, cell, integrity % and distance to the nearest welder, plus any welder that is off, damaged or unpowered, and `[Stock]` empty. Weld range cannot be seen in game (no Show Tool Range for welders), so measure it instead: with one welder alone (no scripts), put the tip against a single projected armour cube and note whether it builds at 0, 0.5 and 1.0 m in front of the tip. If a block stays unwelded, report: the block name and cell from the LCD line, the nearest welder's name and the distance shown, the bay's `Exit Direction`, the model, and whether the LCD said `no Drone Box keys`, `none buildable (unsupported)` or `buildable but not welded`.
9. **Projected PB (T5, T6).** After the build, open the welded drone's PB: does the Edit window hold the code, does it run, who owns it (and `GetOwnershipFromProjector`)? Does the printer's `Recompile` fix an uncompiled one?
10. **Fused grid (P1).** Weld one drone, switch both merge blocks off, look at the Info / grid list: is the drone a separate grid? If not, the bay shows FAULT "FUSED" and the printer concept needs another way to cut the drone loose.
11. **Full cycle on Hive Mother.** Creative world, stock present: `start`; watch BUILD, CHARGE, RELEASE; the drone should receive `<Tag>_JOIN` and start working. Then `max`, `hold`, `release` commands.
12. **Runtime and IGC limits (T12).** Print `Runtime.MaxInstructionCount` on a PB; send an IGC test message between two antenna ships at 1 km and 10 km. Decides whether hive messages reach as far as the Watcher's 5000 m antenna implies.
13. **Finish check can be broken on purpose (v2.4).** In FINISH switch one welder off by hand: it must come back on within about a second and the stall text must name it. Empty `[Stock]` during FINISH: the LCD must ask for a refill and not FAULT; refill and it continues. Delete the `Drone Box Min/Max` keys from `[Bay N]`: the LCD must warn `no Drone Box keys` and the finish waits 90 s. Report the LCD text if any of these fail.
14. **Automatic take-off (v2.4).** Print one drone and do nothing else. After the release it must burn away from the printer for a few seconds and then switch to GUARD (the PB screen shows `Launch: took off (...)`). Then repeat three times while the drone is still docked: set Custom Data `[Launch] Auto=false` and run PB argument `launch` after the merge opens; recompile the drone PB after the release; switch the printer's `_JOIN` off. In each case the drone should still leave. Read the drone PB Custom Data before separation (`release 1`): it must contain `[Launch]` with `Armed=true` and `Away X/Y/Z`. If the drone sits still, report the Custom Data and the PB screen text.
15. **Launch direction and Gnat (v2.4).** Check the burn goes along the bay's `Exit Direction` / Away X/Y/Z and not into the printer, for the Longbow S and Mantis docking stalk faces. Gnat only thrusts forward and back, so on a Hive Mother bay check that a printed Gnat really leaves; if it hangs beside the printer, report the bay's Exit Direction and Away values.
16. **Disarm (v2.4).** A drone merged on purpose to something else (carrier hangar) must not launch until the merge is released; run PB argument `disarm` to cancel auto-launch, `armed` to re-arm.

## Changelog

### v2.7 (unreleased): WARSHIPS Shrike, Corsair, Warden, Leviathan (new package `Warships_v2.7_Full` / `_Lite`)
- **Helm default mode REACT** (`ShrikeAI.cs`, mode 7 in the `.H2S` flags, `StaffAI.cs` shows it): combat-ready but passive until an AI alarm, a mate's alarm, damage or a held target wakes it. `Start Mode` default is REACT (the key name is unchanged). Four rarely used Custom Data keys were dropped to make room (`Target Large/Small Grids`, `Aim Kp/Kd`, `RTB Battery Fraction`); the Helm is 79,977 of 80,000.
- **Cockpit buttons `deploy` / `dock`** (Staff) on Warden, Leviathan and Corsair; the cradle bay PB keeps a docked drone's thrusters off and switches them on at release.
- **Walkways and entry** (Warden, Leviathan; Shrike and Corsair are cockpit-only): slide doors (`LargeBlockSlideDoor`, seen in the Tech Hunter sample) in both sides of the tower stem lead to a one-cell passage and shaft to the bridge and, on the Warden, through the hangar roof; the Leviathan also has a door into each hangar. `carve_walkway` / `route_walkway` / `walk_check` in `designs/_common.py` (the build asserts a walk from the outside door to the bridge and hangars).
- **Gravity generator** (large `GravityGenerator`, 1 g toward the ship's down, field over the crew spaces) on Warden and Leviathan Full (the Lite variants keep no unseen shape). Large grid only: the small-grid Corsair cannot carry one. The object-builder fields (`FieldSize`, `GravityAcceleration`) were never seen in a game file.
- **Round slopes / corners** in the concave edges of the big Leviathan rooms (`chamfer_room`); the Warden's rooms are too cramped to take any.
- **`<ConveyorLines>`** are now written for every face-adjacent ported pair (junction cubes, thrusters on tanks / junctions, turret / tank / locker terminals), as the game's own saves do. Suspected cause of ships that could not hold forward: without the lines the hydrogen network may not connect on paste. Not verified in the game.

New zips with four ships that fly by hand (sit in the seat) and by themselves, plus the Cradle Pod and the `Corsair Wing`, `Warden Wing`, `Leviathan Wing` variants with Hornets in the cradles.
Three scripts: `ShrikeAI.cs` (the Helm of every ship: Hornet brain + MANUAL mode + weapon batteries + dead-man heartbeat; 79,990 of its 80,000 characters), `StaffAI.cs` (heartbeat watch that releases every
override when the Helm dies, wing orders and roll call, hangar doors, drone launch, display pages) and `CradleBayAI.cs` (the merge-block cradles). The usage guide is the README of the Warships zips.
The drone zips no longer contain the warships (they moved to the new zips); the All zip has everything. All ships were run in the simulator only: nothing has been pasted into the game yet.
- Staff 1.4: `launch [n|a-b|all]` (parks the Helm so the bays' ship-turns / ship-accelerates gates pass, releases, gives the Helm its mode back); `[Staff] Turret Target Group` / `Turret Target Names`
  (artillery and assault turrets aim at the targets' weapons: Leviathan vs Pirate, kill time median 143 s -> 89 s in the sim; replaces the planned Gunnery PB).
- ShrikeAI: the integrity scan (hit direction) is sliced, 150 blocks per call (a 1,300-block ship read all of them in one tick: 58,000 IL instructions of the 50,000 limit; peak is now 25,000);
  a seat named `Gunnery` no longer switches the Helm to MANUAL (`[Manual] Seat Exclude`).
- Designs: the Helm Custom Data of every ship now carries the keys the scripts read (the old `[Battery n]` / `[Cockpit]` sections were read by nobody); large ships: stand-off 700 / 800 m, jinking off,
  AI-block search off (the AI Flight block made the idle warship wander); Warden / Leviathan Timer D renamed `Timer D (deadman)` (the Helm finds it by that word: they had none); the Shrike has a second forward camera
  (with one the nose camera was shot off and the Shrike never saw a Hornet again); the empty Gunnery PB of the Leviathan is gone.
- Simulator: warship scenarios (`ship/<Blueprint>-vs-<Enemy>`) start with the Custom Data the blueprint carries and keep a connector-docked pod rigidly on its host; `selftest m6`.

### v2.7 (unreleased): SATELLITE formation
New operating mode: the drones spread round a slowly turning vertical ring centred on the owner (a ship running a Mothership link, you on foot, or the Gnat's carrier /
home point), break off and engage anything inside the Engage Radius, and fly back to their slots afterwards. Command `satellite` / `sat` / `orbit`; ring distance
(`Satellite Distance`, default 100 m, grows with the number of ships), orbit period and plane are in the `[Follow]` Custom Data section. Details, numbers and tests:
`docs/follow-mode.md`. FOLLOW block v1.1 (`tools/follow_block.cs`); the Gnat has its own copy. Size: the Basilisk is now 99,733 of the 100,000 characters.

### v2.6 (this package): BREACH aim against big ships; SEEKER test ships
- **Script length fix (important).** A Programmable Block takes at most 100,000 characters; since v2.2 every armed drone script
  was over it (Hornet 155,629, Basilisk 175,054 characters with comments), so a pasted drone's PB could not hold its script. The
  blueprints and the zips' `Scripts/` folder now carry minified scripts (comments and whitespace removed only; `tools/minify_cs.py`,
  proven identical by compiling both and comparing the IL, `tools/minify_check.sh`; largest now Basilisk 97,721). The commented
  originals are in `Scripts/Source/`, for reading only: they are too long to paste. The build refuses a script over the limit.
Question from the user: against large battleships (their *Tech Hunter*) the drones "can't figure out where vital components are and
just shoot the hull". Study: `docs/tech-hunter-study.md` (1,280 simulated fights, fleets of up to 10 Hornet / Gnat / Longbow S /
Longbow L / Basilisk).
- **BREACH** (shared block `tools/aim_block.cs` in every armed drone script, synced by `tools/aim_sync.py`): against a large grid of
  radius >= 25 m, AUTO holds one hull point (the known one nearest the target's centre, where the armour over the core is thinnest),
  keeps every round on it, and aims down the hole as it deepens; stalled or missing points are swapped. Sim vs Tech Hunter: railgun
  drones destroy about twice as many power blocks (Longbow L 0.65 -> 1.2 per drone in 10 min), at the cost of fewer exposed turrets.
  `aim breach`, `breach on|off`; Custom Data `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`.
- **SEEKER (experimental, option 4)**: a turret on the drone named `[Seeker]` is set to `Seeker Group` (PowerSystems / Weapons /
  Propulsion); the script reads where it points and drills there. New test ships **Longbow L Seeker** (artillery turret, 2 km) and
  **Basilisk Seeker** (roof turret renamed); `scripts/SeekerProbe.cs` reports what any ship's turrets tell a script. In the sim it did
  not beat BREACH; the in-game API behaviour is the open question (test 23).
- Finding for fleet building: against a turret-heavy capital ship only Longbow L survives (2 km = artillery range); Hornets, Gnats and
  Basilisks die in under 70 s whatever they aim at. Nothing of 10 drones or fewer knocked the Tech Hunter out in 10 minutes.
- Simulator turret ranges as in the game: an AI turret on its own targets within its Range setting, at most 800 m for every
  large-grid turret (artillery and assault cannon included), 600 m small grid; a working AI Offensive/Defensive block on its grid
  unlocks the ammo range (artillery 2 km, assault cannon 1.4 km). Turn rates and elevation limits per turret type from the data
  (artillery 0.2 rad/s). Re-run vs Tech Hunter: Longbow S now survives too; with BREACH 10 of them destroy 4.2 power blocks (0.8 before).
- Simulator: turrets need power; only railguns have a capacitor (artillery / assault-cannon capacitors starved every turret of a big
  ship); turret targeting groups + Azimuth/Elevation API; enemy vitals in the results; `--enemy-fleets`.

### v2.5: foundry fixes (finish-welding, robust reach, automatic take-off, owner ids)
- **Finish-welding verification.** `HiveMotherAI.cs` 2.1 no longer leaves BUILD when the projector reports 0 blocks left (that only means "all placed", not "all welded"). A new FINISH state keeps every welder on until a full scan of the bay's drone box finds each block at full integrity and functional. Welders can no longer be switched off in BUILD/FINISH (the old stall "kick" that turned all welders off is gone; it now toggles one welder at a time). The LCD lists unfinished blocks (name, cell, integrity, distance to the nearest welder), reports off/damaged/unpowered welders and an empty `[Stock]`, and FINISH has a timeout that FAULTs with the list.
- **Robust welder reach.** The welder sphere centre is unknown (model dummy), so `reach.py` now checks 8 hypotheses (centre at the tip, 1, 2 or 3 cells inside the welder; radius 1.3 m and 1.0 m), a build-order support check and a foreign-bay check. Hornet-class bays now carry 10-12 welders (was 5-8), Gnat bays 7 (was 5). Exit directions were re-chosen per drone. Costs about +900 PCU and +2.7 t per Hornet-class bay. Per-bay Custom Data gains `Drone Box Min/Max`, `Drone Cell Count`, `Drone Occupied Cells`, `Ignore Cells`, an explicit `Exit Direction`, and a `[Launch]` section.
- **Automatic take-off.** A shared LAUNCH block (`tools/launch_block.cs`, synced by `tools/launch_sync.py`) is in the Hornet, Gnat, Longbow, Mantis, Wasp, Lancer, Harrier, Aegis and Basilisk scripts. A printed drone launches when its own PB sees the merge pair open, or on `[Launch] Armed=true`, `_JOIN`, FLEET `join`, or the arguments `armed` / `launch` / `disarm`. No single message is needed. It burns away from the printer for `Burst Seconds`, then goes home and into its start mode (default GUARD). The printer writes `[Launch]` into the drone PB before release, repeats `_JOIN` for 40 s and recompiles the drone PB.
- Known limit: Gnat only thrusts forward/back, so a lateral Away direction does not move it in the sim (see docs/launch-protocol.md). The Stinger script is not yet integrated with the LAUNCH block.
- Docs: `docs/foundry-notes.md`, `docs/welder-reach.md`, `docs/launch-protocol.md`, `docs/hive-protocol.md` section 9.
- **Owner / built-by ids.** Blueprints now carry Owner and BuiltBy (the in-game PB showed `Owner: Nobody` because none were written). Already-pasted v2.x ships: select all blocks in the terminal and Transfer to yourself.

### v2.4 : kamikaze defence
Simulated attacks by swarms of small warhead drones (4 and 8 Stingers cued by a carrier's radar, against every combat drone model) showed the
scripts writing the kamikazes off as wrecks. A Stinger correcting its course at the speed cap spins 1-2 rad/s, so the "tumbling for 4 s" rule
dropped it, ignored it for 120 s and told the whole hive it was finished, usually just before it arrived.
- **KAMIKAZE DEFENCE** (shared block in every combat drone script, `tools/kz_block.cs`, synced by `tools/kz_sync.py`; scripts 2.6 / Gnat 1.13
  / Longbow 2.4; details in `docs/kamikaze-defence.md`):
  - small contacts on a collision course with the drone or a hive mate are never written off as wrecks, and are dropped once spent;
  - they become the priority target;
  - the drone backs away along the threat axis while its guns stay on target, and breaks sideways inside 2 s of impact;
  - spare camera charge tracks the rest of the swarm and searches round known kamikazes for their pack;
  - the threats are shared with the hive, and Gnats skip their run-in against a kamikaze.
  New `[Kamikaze Defence]` section in Custom Data; PB screen line `!! KAMIKAZE x3 (2 at me) next 4.2 s 380 m`.
- Simulator, 620 kamikaze fights (20 seeds): defenders still fighting at the end 57% -> 70%, damage taken -41%. Against 4 Stingers, a lone
  Hornet goes 50 -> 80%, Lancer 45 -> 85%, Mantis 35 -> 75%, Longbow S 55 -> 80%. Fights without kamikazes are unchanged (1v1 regression in the doc).
- Simulator: scenario kind `kamikaze`, settings `SwarmCueSeconds` / `SwarmCueTeam`, `one --echo-every S`, report tool `tools/kz_report.py`.

### v2.3: lead aiming against manoeuvring targets
In-game report (2026-10-13): the Basilisk's rockets kept missing an enormous target that was doing basic evasive manoeuvres. A rocket
needs about 4 s to fly 800 m; an AI ship on "evasive" flips its strafe every 2-5 s. Full write-up and measurements: `docs/lead-v1.md`.
- **LEAD v1.0** (shared block in every armed drone script, `tools/lead_block.cs`, scripts v2.5 / Gnat 1.12 / Longbow 2.3):
  - the target's freshest acceleration, held only for as long as its manoeuvres usually last, then constant velocity (the old
    solver extrapolated a lagging, smoothed acceleration over the whole flight);
  - the hull aim point counts only across the line of fire, turns with the target's spin for up to 1 s, and keeps
    `Aim Margin (predicted misses)` x the predicted miss of known hull round it, so long, uncertain shots go to the middle of the
    known hull instead of its edge.
- Basilisk / Wasp: rockets modelled as leaving with the ship's velocity + launch speed and curving onto the barrel line
  (`Rocket Velocity Model` CAPPED / NONE / FULL; NONE is the v2.2 model). Closed-form rocket path, Newton solve on the flight time.
- Offline bench (`tools/lead_bench`), hits on manoeuvring targets: rockets 50 % -> 62 % (strafing 120 m ship 43 -> 66 %, strafing
  30 m ship 14 -> 39 %), gatling 70 % -> 90 %, railgun 77 % -> 90 %.
- Simulator: rockets inherit the shooter's velocity with the speed cap (`--rocket-inherit`, default 1), evasive Pirate
  (`--pirate-evasive true`).

### v2.2: FOLLOW mode
Question from the user: does `guard` follow the owner? Only as a side effect: a Mothership link's position replaces the guard spot, but
the drones fly to the ship's centre (into its hull for most drone types), lag behind a moving ship, and fall back to the old spot when
the link stops. Nothing followed a player on foot.
- **FOLLOW** (shared block in every scripted combat drone, `tools/follow_block.cs`, synced by `tools/follow_sync.py`): `follow` / `escort`
  command (also Start Mode and launch Mode `FOLLOW`). The owner is the ship running a Mothership link (any type, FLEET channel), or the
  owner's own character seen by the drone's sensor (on foot, ~50 m; wins while seen). Each drone flies its own slot on a ring behind the
  owner (upper half in gravity) outside its hull, with the owner's velocity fed forward (estimated from the link's position fixes, so old
  link scripts work), detours round the hull instead of through it, engages only targets within 800 m of the owner, breaks off past
  1.2 km (2.2 km for the snipers), and after a link loss coasts 3 s on the owner's track (10 s on foot) and holds there. On a
  collision course with the owner it sidesteps up to 8 s ahead, and the ring widens (up to 2x) while the owner manoeuvres hard.
  New `[Follow]` section in Custom Data. No AI-block search in FOLLOW (the AI Flight block would fly the drone away from you).
- Gnat 1.11: `follow` / `escort` = `form`; the formation now matches the link ship's velocity (keeps up with it), and also reads the
  ship radius from the FLEET channel.
- Mothership links (Hornet / Longbow v1.1, Gnat v1.2): send the ship's radius on `<Tag>_HOMER` and `<fleet>_HOMER`; `follow` relays.
- FLEET block: `follow` and `escort` added to the default `Allowed Commands`.
- Simulator: `follow-test` (moving owner on the fleet channel, or an owner character reported to the sensors; cruise, weave, link loss,
  on foot, fight).

### v2.1: first in-game report fixes
In-game report (2026-10-13): Full drones set to `guard` stood still; `hunt` drones waited about 20 s, then all flew off the same way
and never saw a pirate ship 700 m away. Cause: the AI blocks paste with **AI Behavior off**, so they do nothing, but the scripts handed
them the ship and switched their own camera search off while waiting for them. Reproduced in the simulator (AI blocks inert:
3 Hornets vs pirate at 700 m won 0 of 40, found the pirate in 1 of 40 runs).
- **AI GATE** (shared block in every scripted drone, `tools/ai_gate_block.cs`): the script tries to switch AI Behavior on itself
  (the PB screen says whether it could). Until the AI blocks have flown the ship once, they only get it in 6 s windows between 8 s
  of the script's own camera search (under fire the script searches); once they have, they are trusted as before (status `AI ok`).
  New `[AI Gate]` section in Custom Data.
- Side cameras scan out to 900 m whenever there is no target (was 120 m); short close-scan rays no longer drain the nose cameras
  below the long scan's range while under fire.
- Hit direction: the blocks that lose integrity tell which side was hit; the nose sweep and the side cameras search that side.
- HUNT search patrol: drones fan out (each starts its square at a different corner), keep sweeping their cameras on a leg instead of
  looking along the flight path, hold position at listening stops, and Lite drones (no AI blocks) patrol too.
- Simulator results (pirate ship 700 m away, 36 pirate scenarios x 20 seeds, every model): AI blocks doing nothing, `hunt`: drone
  side wins 23 -> 44 of 720, `guard`: 24 -> 47 of 720 (3 Hornets alone: found the pirate in 1 -> 15 of 40 fights); AI blocks that
  need the AI Behavior switch: 23 -> 211 of 720 (the script switches it on). With working AI blocks drone-vs-drone results are
  unchanged (1v1 without the Watcher, 1,560 fights: 77.6 % -> 77.4 % decisive). The unarmed Watcher (no AI blocks) now patrols in
  `hunt` like every drone without AI blocks, so armed drones catch it less often (Watcher fights 60 % -> 24 % decisive).
- Simulator: `--script-ai-blocks-inert` (AI blocks never act) and `--ai-behavior-needs-switch` (AI blocks act only once a script
  switches "ActivateBehavior" on); `GetProperties`/`GetActions` on terminal blocks.

### v2.0
- Every model exists as Full and **Lite** (Lite: only block XML shapes seen in a game-written ship, plus the merge block). Both variants build, validate and ship from one generator (`tools/build_all.py`).
- Blueprint generator rewritten around real data: mount-point validation (checked against the Starburst ship), real masses and costs from `defs_stats.json`, `<Toolbar>` written for Sensor/Timer/Turret Controller/Event Controller (probable paste-failure fix), Custom Data stored in ModStorage (the old `<CustomData>` element was ignored by the game), unique blueprint ids, stable (crc32) seeds, no `.sbcB5`.
- Weapon data corrected from the local game files: gatling 700 rpm, 800 m/s (was 400).
- Merge block clamp face corrected: small 1x1x1 block clamps toward Up (was Right); Hornet, Gnat and every printable drone got a clear docking face.
- New drones: **Wasp** (rockets), **Lancer** (autocannon), **Watcher** (unarmed scout), **Harrier** (interceptor), **Aegis** (escort / point defence), **Mantis** (railgun + gatling), **Basilisk** (large-grid rocket gunship), **Midge** (scriptless, experimental).
- New printers (projector + welders + merge block bays, `HiveMotherAI.cs` 2.0): Hive Mother, Twin Hive, Quad Hive, Hornet Forge, Wasp Foundry, Lancer Foundry, Longbow Foundry, Harrier Forge, Aegis Shipyard, Mantis Foundry, Watcher Pad, Fleet Forge, Escort Carrier, Mobile Hive, Static Nest, Stinger Rack.
- Hornet: rear camera moved one cell up to make room for the docking stalk. Gnat: merge block on a 2-cell stalk under the belly.
- Printers: every bay now has an exit lane. Before, Hornet-class bays (Hornet, Wasp, Lancer, Longbow S, Harrier, Aegis, Mantis, Watcher) had a welder on every side of the drone, so the finished drone could not leave. The drone's footprint swept 14 cells away from the merge block is kept free; Longbow S and Mantis leave sideways (outwards, away from the neighbour bay) and HiveMotherAI.cs reads the new per-bay `Exit Direction` Custom Data key to nudge the printer the right way.

### v1.x history
- **v1.0**: Hornet (gatling), Longbow S/L (railgun), Gnat (2-thruster swarm), mothership relays.
- **v1.1**: sensors added; nothing pasted.
- **v1.2**: sensor removed; Longbow stopped reading railgun power.
- **v1.3**: steadiness-gated lead, `Lead Scale`.
- **v1.4**: 5 extra cameras + all-around close scan; compact embedded scripts (size theory later disproven).
- **v1.5**: disabled-target detection, damage sensing and evasion, split focus, on-screen errors.
- **v1.6**: hull-point aim modes.
- **v1.7**: AI-block search hand-off (user places `[AI]` blocks).
- **v1.8** (uncompiled in-game): printer join / re-scan on grid change, Hornet scout mode.
