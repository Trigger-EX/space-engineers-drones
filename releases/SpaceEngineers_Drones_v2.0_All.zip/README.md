# Space Engineers drones and printers v2.0 (everything)

Every drone and every printer, Full and Lite, in one zip.

Package contents: 24 drone blueprints, 32 printer blueprints. **No DLC blocks.** `MODELS.md` in this zip is the master table (blocks, mass, thrust-to-weight, PCU, cost).

## Install

1. Unzip this package anywhere. You get `Blueprints/<Name>/{bp.sbc,thumb.png}`, `Scripts/*.cs` and this README.
2. **Delete the old blueprint folders first.** Open `%AppData%\SpaceEngineers\Blueprints\local\`, and remove every folder of an earlier
   version of these ships (Hornet, Gnat, Longbow ..., also their `bp.sbcB5` files). The game caches a binary `bp.sbcB5` next to `bp.sbc`
   and keeps loading the stale copy if it is still there. This package never ships a `.sbcB5`.
3. Copy the `Blueprints/<Name>` folders you want into `%AppData%\SpaceEngineers\Blueprints\local\`.
4. In game: press **F10** (blueprint screen), pick the ship, and paste it into the world (creative tools, or load it into a projector in a
   survival world).
5. Every ship is pasted as a **dynamic** small-grid ship (a large-grid ship for the Basilisk). Do not convert printers to a station: a
   static printer would make every printed drone static.
6. Check that "In-game scripts" is enabled in the world settings, otherwise the Programmable Blocks do not run.
7. If something does not paste, send the game log (`%AppData%\SpaceEngineers\SpaceEngineers_*.log`) and say which model and variant.

**Which variant?** `<Name>` (Full) uses the whole design, including block types whose XML has never been seen in a game-written
blueprint (Sensor, AI blocks, Decoy, cargo containers, turret). `<Name> Lite` uses only block types whose XML shape is copied from a
game-written ship (the Starburst reference), with the one exception noted under "Known unknowns" (the small merge block). If a Full ship
does not paste, try its Lite twin: it must still fly and fight. No ship uses DLC blocks.

## Models

| Model | Variant | Blocks | Mass kg | Accel m/s2 | PCU | Script |
|---|---|--:|--:|--:|--:|---|
| Gnat | Full | 19 | 1941 | 0.0-7.4 | 672 | GnatSwarmAI |
| Gnat | Lite | 18 | 1807 | 0.0-8.0 | 647 | GnatSwarmAI |
| Hornet | Full | 54 | 4451 | 6.5 | 1010 | HornetDroneAI |
| Hornet | Lite | 51 | 4005 | 7.2 | 935 | HornetDroneAI |
| Longbow L | Full | 52 | 110181 | 6.3 | 926 | LongbowSniperAI |
| Longbow L | Lite | 49 | 108247 | 6.4 | 851 | LongbowSniperAI |
| Longbow S | Full | 53 | 6044 | 4.8 | 885 | LongbowSniperAI |
| Longbow S | Lite | 50 | 5597 | 5.1 | 810 | LongbowSniperAI |
| Lancer | Full | 54 | 4515 | 6.4 | 1010 | LancerAI |
| Lancer | Lite | 51 | 4069 | 7.1 | 935 | LancerAI |
| Wasp | Full | 54 | 4607 | 6.3 | 1700 | WaspAI |
| Wasp | Lite | 51 | 4161 | 6.9 | 1625 | WaspAI |
| Midge | Full | 35 | 4169 | 6.9 | 680 | none |
| Midge | Lite | 18 | 1807 | 0.0-8.0 | 647 | GnatSwarmAI |
| Watcher | Full | 54 | 4005 | 7.2 | 900 | HornetDroneAI |
| Watcher | Lite | 53 | 3871 | 7.4 | 875 | HornetDroneAI |
| Aegis | Full | 58 | 4876 | 5.9 | 1180 | AegisAI |
| Aegis | Lite | 55 | 4525 | 6.4 | 1097 | AegisAI |
| Basilisk | Full | 52 | 115787 | 6.0 | 4257 | BasiliskAI |
| Basilisk | Lite | 48 | 112424 | 6.1 | 3957 | BasiliskAI |
| Harrier | Full | 56 | 4693 | 6.1-12.3 | 1034 | HarrierAI |
| Harrier | Lite | 53 | 4247 | 6.8-13.6 | 959 | HarrierAI |
| Mantis | Full | 53 | 6312 | 4.6-9.1 | 914 | MantisAI |
| Mantis | Lite | 50 | 5866 | 4.9-9.8 | 839 | MantisAI |
| Aegis Shipyard | Full | 258 | 14938 | 1.9 | 2875 | AegisAI, HiveMotherAI |
| Aegis Shipyard | Lite | 283 | 17094 | 1.7 | 3478 | AegisAI, HiveMotherAI |
| Escort Carrier | Full | 271 | 37505 | 1.2 | 3494 | HiveMotherAI, HornetDroneAI |
| Escort Carrier | Lite | 303 | 42653 | 1.0 | 4178 | HiveMotherAI, HornetDroneAI |
| Fleet Forge | Full | 370 | 23290 | 1.9 | 5137 | GnatSwarmAI, HiveMotherAI, HornetDroneAI |
| Fleet Forge | Lite | 390 | 24917 | 1.7 | 5586 | GnatSwarmAI, HiveMotherAI, HornetDroneAI |
| Harrier Forge | Full | 254 | 14858 | 1.9 | 2871 | HarrierAI, HiveMotherAI |
| Harrier Forge | Lite | 287 | 18030 | 1.6 | 3780 | HarrierAI, HiveMotherAI |
| Hive Mother | Full | 217 | 13262 | 2.2 | 2536 | GnatSwarmAI, HiveMotherAI |
| Hive Mother | Lite | 217 | 13203 | 2.2 | 2518 | GnatSwarmAI, HiveMotherAI |
| Hornet Forge | Full | 258 | 14938 | 1.9 | 2875 | HiveMotherAI, HornetDroneAI |
| Hornet Forge | Lite | 293 | 18150 | 1.6 | 3786 | HiveMotherAI, HornetDroneAI |
| Lancer Foundry | Full | 258 | 14938 | 1.9 | 2875 | HiveMotherAI, LancerAI |
| Lancer Foundry | Lite | 293 | 18150 | 1.6 | 3786 | HiveMotherAI, LancerAI |
| Longbow Foundry | Full | 283 | 17152 | 1.7 | 3496 | HiveMotherAI, LongbowSniperAI |
| Longbow Foundry | Lite | 245 | 14620 | 2.0 | 2844 | HiveMotherAI, LongbowSniperAI |
| Mantis Foundry | Full | 273 | 16952 | 1.7 | 3486 | HiveMotherAI, MantisAI |
| Mantis Foundry | Lite | 273 | 16894 | 1.7 | 3468 | HiveMotherAI, MantisAI |
| Mobile Hive | Full | 335 | 21483 | 2.7 | 4572 | GnatSwarmAI, HiveMotherAI |
| Mobile Hive | Lite | 335 | 21424 | 2.7 | 4554 | GnatSwarmAI, HiveMotherAI |
| Quad Hive | Full | 544 | 34355 | 1.3 | 8287 | GnatSwarmAI, HiveMotherAI |
| Quad Hive | Lite | 544 | 34297 | 1.3 | 8269 | GnatSwarmAI, HiveMotherAI |
| Static Nest | Full | 414 | 25288 | 0.0 | 6173 | GnatSwarmAI, HiveMotherAI |
| Static Nest | Lite | 414 | 25230 | 0.0 | 6155 | GnatSwarmAI, HiveMotherAI |
| Stinger Rack | Full | 323 | 20031 | 1.4 | 4428 | HiveMotherAI, StingerAI |
| Stinger Rack | Lite | 323 | 19972 | 1.4 | 4410 | HiveMotherAI, StingerAI |
| Twin Hive | Full | 323 | 20031 | 1.4 | 4428 | GnatSwarmAI, HiveMotherAI |
| Twin Hive | Lite | 323 | 19972 | 1.4 | 4410 | GnatSwarmAI, HiveMotherAI |
| Wasp Foundry | Full | 258 | 14938 | 1.9 | 2875 | HiveMotherAI, WaspAI |
| Wasp Foundry | Lite | 293 | 18150 | 1.6 | 3786 | HiveMotherAI, WaspAI |
| Watcher Pad | Full | 269 | 16872 | 1.7 | 3482 | HiveMotherAI, HornetDroneAI |
| Watcher Pad | Lite | 269 | 16814 | 1.7 | 3464 | HiveMotherAI, HornetDroneAI |

### Gnat

Minimal swarm drone: one gatling, two axial ion thrusters (it steers by turning the whole ship), belly merge latch. Flies yo-yo attack runs inside a leaderless IGC swarm.

* **Gnat**: 19 blocks, 1941 kg, 2.0x2.5x2.5 m, accel F7.4 B7.4 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 672; script: GnatSwarmAI.cs; cost Iron 1976 Nickel 134 Cobalt 26 Silicon 19 Gold 2 Platinum 1
* **Gnat Lite**: 18 blocks, 1807 kg, 2.0x2.5x2.5 m, accel F8.0 B8.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 647; script: GnatSwarmAI.cs; cost Iron 1838 Nickel 44 Cobalt 26 Silicon 17 Gold 2 Platinum 1

Note: Thrust only along the nose axis (forward / back), by design.

### Hornet

The standard fighter: two gatlings, 12 ion thrusters (2 per axis), 7 cameras, 4 batteries, rear merge latch. Holds a standoff, orbits and jinks; guard / hunt / assist.

* **Hornet**: 54 blocks, 4451 kg, 3.5x3.0x4.0 m, accel F6.5 B6.5 U6.5 D6.5 L6.5 R6.5 m/s2, PCU 1010; script: HornetDroneAI.cs; cost Iron 4412 Nickel 301 Cobalt 132 Silicon 31 Gold 12 Platinum 5
* **Hornet Lite**: 51 blocks, 4005 kg, 3.5x3.0x4.0 m, accel F7.2 B7.2 U7.2 D7.2 L7.2 R7.2 m/s2, PCU 935; script: HornetDroneAI.cs; cost Iron 3968 Nickel 71 Cobalt 132 Silicon 25 Gold 12 Platinum 5

### Longbow L

Large-grid railgun sniper (2000 m). Same logic as Longbow S; not printable (no merge block).

* **Longbow L**: 52 blocks, 110181 kg, 17.5x25.0x27.5 m, accel F6.3 B6.3 U6.3 D6.3 L6.3 R6.3 m/s2, PCU 926; script: LongbowSniperAI.cs; cost Iron 97090 Nickel 1850 Cobalt 9750 Silicon 528 Gold 1260 Platinum 384
* **Longbow L Lite**: 49 blocks, 108247 kg, 17.5x25.0x27.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 851; script: LongbowSniperAI.cs; cost Iron 95132 Nickel 1120 Cobalt 9750 Silicon 518 Gold 1260 Platinum 384

Note: Large grid, no merge block: paste only.

### Longbow S

Small-grid railgun sniper (1400 m). Computes the longest range at which a dodging target is still hit, takes one settled shot, jinks while reloading.

* **Longbow S**: 53 blocks, 6044 kg, 3.5x4.0x5.5 m, accel F4.8 B4.8 U4.8 D4.8 L4.8 R4.8 m/s2, PCU 885; script: LongbowSniperAI.cs; cost Iron 5619 Nickel 310 Cobalt 120 Silicon 58 Gold 52 Platinum 5
* **Longbow S Lite**: 50 blocks, 5597 kg, 3.5x4.0x5.5 m, accel F5.1 B5.1 U5.1 D5.1 L5.1 R5.1 m/s2, PCU 810; script: LongbowSniperAI.cs; cost Iron 5175 Nickel 80 Cobalt 120 Silicon 51 Gold 52 Platinum 5

Note: No docking face in the base model; printers add a docking stalk to it.

### Lancer

Hornet-class frame with 1x1x5 autocannons (800 m/s shells). Burst fire only when the solution is tight; standoff 420 m.

* **Lancer**: 54 blocks, 4515 kg, 3.5x3.0x4.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 1010; script: LancerAI.cs; cost Iron 4472 Nickel 301 Cobalt 132 Silicon 31 Gold 12 Platinum 5
* **Lancer Lite**: 51 blocks, 4069 kg, 3.5x3.0x4.5 m, accel F7.1 B7.1 U7.1 D7.1 L7.1 R7.1 m/s2, PCU 935; script: LancerAI.cs; cost Iron 4028 Nickel 71 Cobalt 132 Silicon 25 Gold 12 Platinum 5

### Wasp

Hornet frame with small rocket launchers (8 rockets). Integrates the rocket speed curve to lead targets, fires short salvos, refuses shots at unpredictable targets or near hive mates.

* **Wasp**: 54 blocks, 4607 kg, 3.5x3.0x4.0 m, accel F6.3 B6.3 U6.3 D6.3 L6.3 R6.3 m/s2, PCU 1700; script: WaspAI.cs; cost Iron 4584 Nickel 291 Cobalt 126 Silicon 31 Gold 12 Platinum 5
* **Wasp Lite**: 51 blocks, 4161 kg, 3.5x3.0x4.0 m, accel F6.9 B6.9 U6.9 D6.9 L6.9 R6.9 m/s2, PCU 1625; script: WaspAI.cs; cost Iron 4140 Nickel 61 Cobalt 126 Silicon 25 Gold 12 Platinum 5

Note: Needs rockets loaded by hand in survival; relies on the terminal action ShootOnce (unverified).

### Midge (experimental)

EXPERIMENTAL scriptless drone: gatling, AI Offensive + AI Flight + AI Defensive blocks, no Programmable Block. The AI blocks must be set up by hand (Scripts/MidgeNotes.md). Midge Lite is only a renamed Gnat Lite running GnatSwarmAI.cs.

* **Midge**: 35 blocks, 4169 kg, 3.5x3.0x5.0 m, accel F6.9 B6.9 U6.9 D6.9 L6.9 R6.9 m/s2, PCU 680; script: none; cost Iron 4122 Nickel 267 Cobalt 126 Silicon 19 Gold 12 Platinum 5
* **Midge Lite**: 18 blocks, 1807 kg, 2.0x2.5x2.5 m, accel F8.0 B8.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 647; script: GnatSwarmAI.cs; cost Iron 1838 Nickel 44 Cobalt 26 Silicon 17 Gold 2 Platinum 1

Note: Experimental; no script. Configure the three AI blocks by hand (Scripts/MidgeNotes.md). Gatling ammo is not preloaded.

### Watcher

Unarmed scout / spotter: 11 cameras, 5000 m antenna. Keeps 900 m standoff and shares targets with the hive (runs the Hornet script in scout mode).

* **Watcher**: 54 blocks, 4005 kg, 3.5x3.0x4.0 m, accel F7.2 B7.2 U7.2 D7.2 L7.2 R7.2 m/s2, PCU 900; script: HornetDroneAI.cs; cost Iron 3948 Nickel 131 Cobalt 120 Silicon 29 Gold 12 Platinum 5
* **Watcher Lite**: 53 blocks, 3871 kg, 3.5x3.0x4.0 m, accel F7.4 B7.4 U7.4 D7.4 L7.4 R7.4 m/s2, PCU 875; script: HornetDroneAI.cs; cost Iron 3810 Nickel 41 Cobalt 120 Silicon 27 Gold 12 Platinum 5

Note: Configured only through the PB Custom Data ([Hornet] section, IGC Tag HORNET, Start Mode HUNT). `range` is clamped to Max Fire Range; use Standoff in Custom Data for larger values.

### Aegis

Escort / point defence: four gatlings, two decoys (Lite: armour plates). Parks on a station around the carrier and screens it by standing on the carrier-to-threat line.

* **Aegis**: 58 blocks, 4876 kg, 3.5x3.0x4.5 m, accel F5.9 B5.9 U5.9 D5.9 L5.9 R5.9 m/s2, PCU 1180; script: AegisAI.cs; cost Iron 4882 Nickel 331 Cobalt 144 Silicon 34 Gold 12 Platinum 5
* **Aegis Lite**: 55 blocks, 4525 kg, 3.5x3.0x4.5 m, accel F6.4 B6.4 U6.4 D6.4 L6.4 R6.4 m/s2, PCU 1097; script: AegisAI.cs; cost Iron 4560 Nickel 121 Cobalt 156 Silicon 25 Gold 12 Platinum 5

Note: For a carrier link copy HornetMothership.cs and change Tag to AEGIS, or use the default extra channel HORNET_HOME.

### Basilisk

LARGE-grid armoured rocket gunship: four large missile launchers, six heavy armour blocks, 12 thrusters; Full adds a large gatling turret as point defence. Not printable.

* **Basilisk**: 52 blocks, 115787 kg, 17.5x17.5x20.0 m, accel F6.0 B6.0 U6.0 D6.0 L6.0 R6.0 m/s2, PCU 4257; script: BasiliskAI.cs; cost Iron 109148 Nickel 3825 Cobalt 11055 Silicon 326 Gold 960 Platinum 384
* **Basilisk Lite**: 48 blocks, 112424 kg, 17.5x17.5x20.0 m, accel F6.1 B6.1 U6.1 D6.1 L6.1 R6.1 m/s2, PCU 3957; script: BasiliskAI.cs; cost Iron 105655 Nickel 2980 Cobalt 11010 Silicon 313 Gold 960 Platinum 384

Note: Large grid: paste it as a free ship; it has no merge block and cannot be put in a printer bay.

### Harrier

Fast interceptor: Hornet frame with four main engines (12 m/s2 forward). Hunts small fast grids, drones and missiles first; shares threat cues on the DRONE_CUE channel.

* **Harrier**: 56 blocks, 4693 kg, 3.5x3.0x4.0 m, accel F12.3 B6.1 U6.1 D6.1 L6.1 R6.1 m/s2, PCU 1034; script: HarrierAI.cs; cost Iron 4648 Nickel 301 Cobalt 152 Silicon 31 Gold 14 Platinum 6
* **Harrier Lite**: 53 blocks, 4247 kg, 3.5x3.0x4.0 m, accel F13.6 B6.8 U6.8 D6.8 L6.8 R6.8 m/s2, PCU 959; script: HarrierAI.cs; cost Iron 4204 Nickel 71 Cobalt 152 Silicon 25 Gold 14 Platinum 6

### Mantis

Railgun + gatling hybrid on a Longbow S spine: alpha strike at range, gatling up close. Engage cap 650 m.

* **Mantis**: 53 blocks, 6312 kg, 3.5x4.5x5.5 m, accel F9.1 B4.6 U4.6 D4.6 L4.6 R4.6 m/s2, PCU 914; script: MantisAI.cs; cost Iron 5891 Nickel 325 Cobalt 146 Silicon 56 Gold 54 Platinum 6
* **Mantis Lite**: 50 blocks, 5866 kg, 3.5x4.5x5.5 m, accel F9.8 B4.9 U4.9 D4.9 L4.9 R4.9 m/s2, PCU 839; script: MantisAI.cs; cost Iron 5447 Nickel 95 Cobalt 146 Silicon 50 Gold 54 Platinum 6

### Aegis Shipyard

2 bays, prints Aegis escorts (4 gatlings, decoys).

* **Aegis Shipyard**: 258 blocks, 14938 kg, 15.0x9.0x9.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 2875, 2 bays / 12 welders; script: AegisAI.cs, HiveMotherAI.cs; cost Iron 15040 Nickel 230 Cobalt 120 Silicon 48 Gold 12 Platinum 5
* **Aegis Shipyard Lite**: 283 blocks, 17094 kg, 19.5x9.0x10.0 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 3478, 2 bays / 16 welders; script: AegisAI.cs, HiveMotherAI.cs; cost Iron 17282 Nickel 260 Cobalt 120 Silicon 40 Gold 12 Platinum 5

### Escort Carrier

Hornet bays + heavy armour, 4 fixed gatlings and the turret-target relay.

* **Escort Carrier**: 271 blocks, 37505 kg, 15.0x9.0x9.5 m, accel F1.2 B1.2 U1.2 D1.2 L1.2 R1.2 m/s2, PCU 3494, 2 bays / 12 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 41270 Nickel 2565 Cobalt 1557 Silicon 51 Gold 18 Platinum 7
* **Escort Carrier Lite**: 303 blocks, 42653 kg, 19.5x9.0x10.0 m, accel F1.0 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 4178, 2 bays / 18 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 46958 Nickel 2860 Cobalt 1716 Silicon 41 Gold 18 Platinum 7

### Fleet Forge

mixed bays: 2 Gnats on top, a Hornet and a Watcher in front.

* **Fleet Forge**: 370 blocks, 23290 kg, 18.5x11.5x14.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 5137, 4 bays / 24 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 23608 Nickel 370 Cobalt 180 Silicon 54 Gold 18 Platinum 7
* **Fleet Forge Lite**: 390 blocks, 24917 kg, 18.5x11.5x16.5 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 5586, 4 bays / 27 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 25306 Nickel 390 Cobalt 180 Silicon 45 Gold 18 Platinum 7

### Harrier Forge

2 bays, prints Harrier interceptors.

* **Harrier Forge**: 254 blocks, 14858 kg, 15.0x9.0x9.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 2871, 2 bays / 12 welders; script: HarrierAI.cs, HiveMotherAI.cs; cost Iron 14956 Nickel 230 Cobalt 120 Silicon 48 Gold 12 Platinum 5
* **Harrier Forge Lite**: 287 blocks, 18030 kg, 19.5x9.0x9.5 m, accel F1.6 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 3780, 2 bays / 18 welders; script: HarrierAI.cs, HiveMotherAI.cs; cost Iron 18242 Nickel 280 Cobalt 120 Silicon 40 Gold 12 Platinum 5

### Hive Mother

2 bays, prints Gnats (swarm drone).

* **Hive Mother**: 217 blocks, 13262 kg, 16.5x9.5x6.0 m, accel F2.2 B2.2 U2.2 D2.2 L2.2 R2.2 m/s2, PCU 2536, 2 bays / 10 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 13304 Nickel 210 Cobalt 120 Silicon 48 Gold 12 Platinum 5
* **Hive Mother Lite**: 217 blocks, 13203 kg, 16.5x9.5x6.0 m, accel F2.2 B2.2 U2.2 D2.2 L2.2 R2.2 m/s2, PCU 2518, 2 bays / 10 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 13268 Nickel 200 Cobalt 120 Silicon 37 Gold 12 Platinum 5

### Hornet Forge

2 bays, prints Hornets (twin gatling fighters).

* **Hornet Forge**: 258 blocks, 14938 kg, 15.0x9.0x9.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 2875, 2 bays / 12 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 15040 Nickel 230 Cobalt 120 Silicon 48 Gold 12 Platinum 5
* **Hornet Forge Lite**: 293 blocks, 18150 kg, 19.5x9.0x10.0 m, accel F1.6 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 3786, 2 bays / 18 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 18368 Nickel 280 Cobalt 120 Silicon 40 Gold 12 Platinum 5

### Lancer Foundry

2 bays, prints Lancers (autocannons).

* **Lancer Foundry**: 258 blocks, 14938 kg, 15.0x9.0x9.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 2875, 2 bays / 12 welders; script: HiveMotherAI.cs, LancerAI.cs; cost Iron 15040 Nickel 230 Cobalt 120 Silicon 48 Gold 12 Platinum 5
* **Lancer Foundry Lite**: 293 blocks, 18150 kg, 19.5x9.0x10.0 m, accel F1.6 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 3786, 2 bays / 18 welders; script: HiveMotherAI.cs, LancerAI.cs; cost Iron 18368 Nickel 280 Cobalt 120 Silicon 40 Gold 12 Platinum 5

### Longbow Foundry

2 big bays, prints Longbow S railgun snipers (docking stalk added by printer_lib.with_latch).

* **Longbow Foundry**: 283 blocks, 17152 kg, 19.0x12.5x8.5 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 3496, 2 bays / 16 welders; script: HiveMotherAI.cs, LongbowSniperAI.cs; cost Iron 17318 Nickel 270 Cobalt 120 Silicon 50 Gold 12 Platinum 5
* **Longbow Foundry Lite**: 245 blocks, 14620 kg, 14.5x11.0x7.5 m, accel F2.0 B2.0 U2.0 D2.0 L2.0 R2.0 m/s2, PCU 2844, 2 bays / 12 welders; script: HiveMotherAI.cs, LongbowSniperAI.cs; cost Iron 14732 Nickel 220 Cobalt 120 Silicon 38 Gold 12 Platinum 5

### Mantis Foundry

2 bays, prints Mantis hybrids (railgun + gatling; docking stalk added).

* **Mantis Foundry**: 273 blocks, 16952 kg, 19.5x10.0x8.5 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 3486, 2 bays / 16 welders; script: HiveMotherAI.cs, MantisAI.cs; cost Iron 17108 Nickel 270 Cobalt 120 Silicon 50 Gold 12 Platinum 5
* **Mantis Foundry Lite**: 273 blocks, 16894 kg, 19.5x10.0x8.5 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 3468, 2 bays / 16 welders; script: HiveMotherAI.cs, MantisAI.cs; cost Iron 17072 Nickel 260 Cobalt 120 Silicon 40 Gold 12 Platinum 5

### Mobile Hive

4 Gnat bays and 4 ion thrusters per direction: keeps up with its brood.

* **Mobile Hive**: 335 blocks, 21483 kg, 16.5x9.5x12.0 m, accel F2.7 B2.7 U2.7 D2.7 L2.7 R2.7 m/s2, PCU 4572, 4 bays / 20 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 21702 Nickel 330 Cobalt 240 Silicon 53 Gold 24 Platinum 10
* **Mobile Hive Lite**: 335 blocks, 21424 kg, 16.5x9.5x12.0 m, accel F2.7 B2.7 U2.7 D2.7 L2.7 R2.7 m/s2, PCU 4554, 4 bays / 20 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 21668 Nickel 320 Cobalt 240 Silicon 42 Gold 24 Platinum 10

### Quad Hive

8 compact bays in a 4x2 array, prints Gnats.

* **Quad Hive**: 544 blocks, 34355 kg, 32.5x9.5x12.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 8287, 8 bays / 40 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 35024 Nickel 570 Cobalt 180 Silicon 63 Gold 18 Platinum 7
* **Quad Hive Lite**: 544 blocks, 34297 kg, 32.5x9.5x12.0 m, accel F1.3 B1.3 U1.3 D1.3 L1.3 R1.3 m/s2, PCU 8269, 8 bays / 40 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 34988 Nickel 560 Cobalt 180 Silicon 53 Gold 18 Platinum 7

### Static Nest

6 Gnat bays, no thrusters: a stationary hive (still a DYNAMIC grid; never convert it to a station).

* **Static Nest**: 414 blocks, 25288 kg, 24.5x8.5x12.0 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 6173, 6 bays / 30 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 25790 Nickel 450 Silicon 58
* **Static Nest Lite**: 414 blocks, 25230 kg, 24.5x8.5x12.0 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 6155, 6 bays / 30 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 25756 Nickel 440 Silicon 48

### Stinger Rack

RACK MODE: 4 Stingers stay docked; one is released per enemy sighting and told to launch.

* **Stinger Rack**: 323 blocks, 20031 kg, 16.5x9.5x12.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4428, 4 bays / 20 welders; script: HiveMotherAI.cs, StingerAI.cs; cost Iron 20286 Nickel 330 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Stinger Rack Lite**: 323 blocks, 19972 kg, 16.5x9.5x12.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4410, 4 bays / 20 welders; script: HiveMotherAI.cs, StingerAI.cs; cost Iron 20252 Nickel 320 Cobalt 120 Silicon 42 Gold 12 Platinum 5

### Twin Hive

4 bays in a 2x2 array, prints Gnats.

* **Twin Hive**: 323 blocks, 20031 kg, 16.5x9.5x12.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4428, 4 bays / 20 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 20286 Nickel 330 Cobalt 120 Silicon 53 Gold 12 Platinum 5
* **Twin Hive Lite**: 323 blocks, 19972 kg, 16.5x9.5x12.0 m, accel F1.4 B1.4 U1.4 D1.4 L1.4 R1.4 m/s2, PCU 4410, 4 bays / 20 welders; script: GnatSwarmAI.cs, HiveMotherAI.cs; cost Iron 20252 Nickel 320 Cobalt 120 Silicon 42 Gold 12 Platinum 5

### Wasp Foundry

2 bays, prints Wasps (rocket launchers).

* **Wasp Foundry**: 258 blocks, 14938 kg, 15.0x9.0x9.5 m, accel F1.9 B1.9 U1.9 D1.9 L1.9 R1.9 m/s2, PCU 2875, 2 bays / 12 welders; script: HiveMotherAI.cs, WaspAI.cs; cost Iron 15040 Nickel 230 Cobalt 120 Silicon 48 Gold 12 Platinum 5
* **Wasp Foundry Lite**: 293 blocks, 18150 kg, 19.5x9.0x10.0 m, accel F1.6 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 3786, 2 bays / 18 welders; script: HiveMotherAI.cs, WaspAI.cs; cost Iron 18368 Nickel 280 Cobalt 120 Silicon 40 Gold 12 Platinum 5

### Watcher Pad

2 bays, prints unarmed Watcher scouts (feed the HORNET hive).

* **Watcher Pad**: 269 blocks, 16872 kg, 16.5x9.0x9.5 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 3482, 2 bays / 16 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 17024 Nickel 270 Cobalt 120 Silicon 50 Gold 12 Platinum 5
* **Watcher Pad Lite**: 269 blocks, 16814 kg, 16.5x9.0x9.5 m, accel F1.7 B1.7 U1.7 D1.7 L1.7 R1.7 m/s2, PCU 3464, 2 bays / 16 welders; script: HiveMotherAI.cs, HornetDroneAI.cs; cost Iron 16988 Nickel 260 Cobalt 120 Silicon 40 Gold 12 Platinum 5


## Configure and command

Every script keeps its settings in the Programmable Block's **Custom Data** (ini; written on first run, edit and run `reload`).
Commands go in the PB's *argument* (run the PB with the text, or use a toolbar slot / button panel) or arrive over IGC on `<IGC Tag>_CMD`.
Printed drones start in IDLE and wait for the printer's `_JOIN`; a drone pasted by hand needs `guard` or `hunt`.
Printers: put the component stock in the `[Stock]` cargo or the welders, then run the printer PB with `start`.

### AegisAI.cs (v2.2-aegis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Extra Home Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Max Fire Range vs Huge Grids`, `Standoff Range vs Huge Grids`, `Standoff Range`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Screen Distance From Carrier`, `Carrier Radius`, `Hold Radius`, `Tether Radius`, `Target Missiles`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### BasiliskAI.cs (v2.2-basilisk)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Max Flight Time`, `Max Fire Range vs Huge Grids`, `Max Flight Time vs Huge Grids`, `Standoff Range vs Huge Grids`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range vs Small Grids`, `Min Range`, `Standoff Range vs Large Grids`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Wingmate Close Separation Range`, `Wingmate Close Separation Speed`, `Take Over From AI When A Wingmate Is Closer Than (m; 0 off)`, `Wingmate Separation Hold (s)`, `Fire Window Multiplier`, `Fire Window Multiplier (unlimited rockets)`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Cone (deg)`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Convergence Rays`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Dash Only While Recent Hits Below`, `AI Confirm Convergence Rays Per 8`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### GnatSwarmAI.cs (v1.9)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `form`
* `guard`: hold the home point, engage anything inside Guard Radius
* `attack`
* `hunt`: chase and engage any target, actively scan
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (FORM/ATTACK/IDLE)`, `Projectile Speed`, `Fire Range`, `Closing Speed`, `Run-in Start Range`, `Back-off Speed`, `Orbit Speed`, `Back-off Range`, `Re-close Range`, `Emergency Break Range`, `Attack Cone Degrees`, `Max Sideways Drift m/s`, `Formation Radius`, `Separation Radius`, `Engage Radius From Home`, `Combat Speed`, `Cruise Speed`, `Velocity Gain`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `RTB Battery Fraction`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Lead Scale (1 = calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false = focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire (s)`, `Raid Fan Half-angle Degrees`, `Raid Scan Cone Degrees`, `Raid Scan Ray Length`, `Raid Speed`, `Raid Max Travel`, `Raid Bearing Memory Seconds`, `Raid Start Confidence`, `Raid Hold Confidence`, `Listen To IGC Tags (target feeds)`, `Scan Range`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`.


### HarrierAI.cs (v2.2-harrier)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Cue Channel`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Small Target Standoff Fraction`, `Target Priority Small Bonus`, `Target Priority Large Penalty`, `Target Priority Fast Closer Bonus`, `Target Priority Missile Bonus`, `Target Missiles`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### HiveMotherAI.cs (v2.0)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `start`: start printing
* `stop`: stop printing, all welders off
* `max`: `max <n>` set Max Drones
* `release`: `release [bay]` release finished drones
* `hold`: `hold <bay>` keep a bay paused
* `unhold`: `unhold <bay>` resume a bay
* `relay`: `relay on|off` forward carrier turret targets
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Hive Mother]` keys: `Max Drones (all tags)`, `Rack Mode (keep docked, launch on targets)`, `Rack Launch Command Tag`, `Rack Target Tags (enemy sightings that release a drone)`, `Max Charge Seconds`, `Cooldown Seconds`, `Stall Warning Seconds`, `Build Timeout Seconds`, `Fault Retry Seconds`, `Parallel Builds`, `Recompile Drone PB Before Release`, `Recompile Wait Seconds`, `Release Nudge Seconds`, `Release Nudge Power (0-1)`, `Release Gap Seconds`, `Drone Match Radius m`, `Relay Turret Targets To All Tags`, `Auto Start`.

Custom Data `[Bay N]` keys: `Tag`, `Prefix`, `Max Alive`, `Max Prints`, `Hold`, `Exit Direction (printer axis the drone leaves along, blank means straight away from the merge block)`.


### HornetDroneAI.cs (v2.2-hornet)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Max Track Age To Fire (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Listen To IGC Tags (target feeds)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LancerAI.cs (v2.2-lancer)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Burst Seconds`, `Burst Pause`, `Conserve Below Shells`, `Conserve Max Range`, `Standoff Range`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### LongbowSniperAI.cs (v2.0)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### MantisAI.cs (v2.2-mantis)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Auto Detect Weapon`, `Custom Projectile Speed`, `Custom Weapon Range`, `Custom Reload Seconds`, `Custom Shot Delay Seconds`, `Custom Gravity Drop`, `Projectiles Inherit Ship Velocity`, `Hit Fraction Of Target Radius`, `Velocity Error m/s`, `Assumed Dodge Accel Small Grid`, `Assumed Dodge Accel Large Grid`, `Assumed Dodge Accel Character`, `Range Margin`, `Min Engage Range`, `Engage Cap`, `Use Gatling`, `Gatling Projectile Speed`, `Gatling Range`, `Gatling Fire Window Multiplier`, `Forced Range (0: auto)`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Drift Speed While Aiming`, `Jink Speed While Reloading`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`, `Settle Ticks Before Shot`, `Lead Scale (1: as calculated)`, `Preferred Engage Range`, `Max Aim Window m (railgun)`, `Max Aim Window m (big target)`, `Calm Target Accel m/s2 (0 off)`, `Max Wait For Calm Target s`, `Fresh Acceleration Weight (0: old smoothing)`, `Fresh Acceleration Scale`, `Full Thrust While Travelling`, `Travelling Distance m`, `No Thrust Around The Shot`, `Retrigger Lead s`, `Retrigger After Refusal s`, `Railgun Off While AI Searches`, `Railgun Off Longest After First Lock s`, `Fire Range Factor`, `Fire Range Slack`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `Max Track Age To Fire Gatling (s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`.


### StingerAI.cs (v1.1)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `launch`: rack: leave the dock and hunt
* `abort`: abort and release
* `disarm`: disarm the warheads
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `Listen To IGC Tags`, `Own Command Tag`, `Auto Launch When Released`, `Max Target Distance`, `Arm Warheads Within`, `Never Arm Within This Of Launch Point`, `Max Speed`, `Target Large Grids`, `Target Small Grids`, `Target Neutral/Unowned`.


### WaspAI.cs (v2.2-wasp)

Commands (PB argument, toolbar, or IGC `<IGC Tag>_CMD`):

* `guard`: hold the home point, engage anything inside Guard Radius
* `hunt`: chase and engage any target, actively scan
* `assist`: you fly, the script aims and fires
* `rtb`: fly home, then idle
* `idle`: release all control (`stop` is an alias)
* `lock`: raycast-lock whatever the nose camera points at
* `unlock`: drop the current target
* `next`: ignore the current target for 60 s
* `split`: split targets across the hive
* `aialert`: treat the AI-block alert as raised
* `ai`: `ai on|off` AI-block search assist
* `aim`: `aim <mode>` aim point
* `focus`: focus fire
* `home`: set the home point to the current position
* `range`: `range <m>` set the standoff
* `reload`: re-read Custom Data and re-scan blocks

Custom Data `[Fleet]` keys: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Projectile Speed`, `Rocket Launch Speed`, `Rocket Acceleration`, `Rocket Top Speed`, `Projectiles Inherit Ship Velocity`, `Max Fire Range`, `Max Flight Time`, `Min Launch Distance`, `Friendly Flight Line Clearance`, `Friendly Blast Clearance`, `Salvo Size`, `Salvo Pause`, `Seconds Between Shots Per Launcher`, `Seconds Between Launchers`, `Jink Gate Radius Factor`, `Jink Gate Min Miss (m)`, `Conserve Below Rockets`, `Conserve Max Range`, `Standoff Range`, `Standoff Range (unlimited rockets)`, `Max Fire Range (unlimited rockets)`, `Max Flight Time (unlimited rockets)`, `Min Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`, `Evasive Jinking`, `Jink Speed`, `Jink Interval (s)`, `Jink Interval Random (s)`, `Manual Lock Range`, `Auto Camera Scan`, `All-around Close Scan`, `Close Scan Range`, `Scan Range`, `Scan Cone Degrees`, `Target Large Grids`, `Target Small Grids`, `Target Characters`, `Target Neutral/Unowned`, `Share Targets Over IGC`, `Friendly Fire Check`, `Listen To IGC Tags (target feeds)`, `Max Track Age To Fire (s)`, `Search Share Tenths (stale lock)`, `Search Share Tenths (stale > 1.5 s)`, `Wingmate Separation Range`, `Wingmate Separation Speed`, `Fire Window Multiplier`, `Lead Scale (1: as calculated)`, `Use Target Acceleration`, `Split Targets Across Hive (false: focus fire)`, `Seconds Before Dropping Disabled Target`, `Evade Speed When Hit`, `Aim Point (AUTO/ENGINES/FACING/SPREAD/CENTER)`, `AI Block Search Assist`, `AI Confirm Raycast Range`, `AI Confirm Long Raycast Range`, `AI Confirm Boresight Rays (of 8)`, `AI Confirm Rays Shorten After A Fight`, `AI Confirm Spiral Min (deg)`, `AI Confirm Spiral Max (deg)`, `AI Confirm Spiral Exponent`, `AI Takes Over After Stale Lock (s)`, `Ghost Target Time (s)`, `Target Stickiness (score bonus for the current target)`, `AI Re-pick Interval (s; 0 off)`, `Dash Along AI Heading`, `Dash Starts After AI Stint (s)`, `Dash Length (s)`, `Dash Re-aim By AI (s)`, `Dash Speed`, `Search Patrol When Nothing Found (HUNT)`, `Search Patrol Own Start Corner And Direction`, `Search Patrol Radius (m)`, `Search Patrol Starts After (s)`, `Search Patrol Starts After A Fight (s)`, `Search Patrol Listening Stop (s)`, `Search Patrol Speed`, `AI Re-pick Only Within (s) Of Last Target`, `AI Confirm Cone Yaw (deg)`, `AI Confirm Cone Pitch (deg)`, `RTB Battery Fraction`, `Aim Kp`, `Aim Kd`, `Max Turn Rate rad/s`.


### GnatMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.

### HornetMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.

### LongbowMothership.cs (optional carrier link)

Put it on a carrier ship's Programmable Block (needs an antenna). It broadcasts the carrier position as the drones' moving home point, forwards what its turrets track to the drones and relays commands: run it with an argument such as `guard`, `hunt`, `rtb`, `idle`, `unlock` (Gnat link: `form`, `attack`, `rtb`, `idle`, `unlock`). Its `Tag` constant must equal the drones' `IGC Tag`.


## Known unknowns

- **Merge-block clamp face (unverified).** The small 1x1x1 merge block (`SmallShipSmallMergeBlock`) clamps toward its local **Up** face (one wiki source); the old assumption was Right. Every merge pair in this package is built on that. It is one constant (`MERGE_CLAMP_FACE_SMALL` in `tools/designs/_common.py`); if the merge-face test (T1) shows another face, change it and run `tools/build_all.py` again.
- **Lite variants keep the small merge block.** Its XML shape comes from the Keen source, not from the Starburst reference, so strictly a Lite ship is not 100 % "seen" XML. A drone or printer without it cannot be printed or docked. `LITE_KEEPS_MERGE = False` in `_common.py` drops it from the drones.
- **XML shapes never seen in a game-written blueprint:** Sensor, the AI blocks (Offensive, Flight, Defensive), Decoy, large gatling turret, Timer and Event Controller toolbars. They are why Full variants exist next to Lite ones. Earlier blueprints with a Sensor or Custom Turret Controller failed to paste; the leading hypothesis is a missing `<Toolbar>` element (now always written), but that is not confirmed.
- **Projected Programmable Blocks.** A welded PB may keep its Program text but not start by itself. The printer script calls `ApplyAction("Recompile")` on it; whether that works is the projected-PB test (T5, T6).
- **No ammunition is pre-loaded** in any gun or launcher (the generator cannot write inventories). In a survival world load magazines / rockets by hand; in a creative world the guns may still need magazines unless the world has infinite ammunition switched on (test T8 shows which). Scripts treat an unknown ammo count as unlimited and never return to base for lack of ammo in that case.
- **Scripts have never run in the game with these versions.** They compile against a hand-written stub of the game API (`tools/compile_check.sh`), which proves syntax and types only.
- **Weapon numbers** come from the local game data (gatling 700 rpm, 800 m/s, 800 m; small rocket 500 damage, 4 m blast; small railgun 1000 m/s, 1400 m, 500 ms shot delay). Rockets are assumed not to inherit the shooter's velocity.
- **Gnat / Midge Lite** thrust only along the nose axis (two axial thrusters, steered by gyros). They have no lateral or vertical thrusters by design.
- **Wasp** relies on the terminal action `ShootOnce` (name from memory, unverified). If it is wrong the Wasp never fires. Its target-lead solver was checked numerically only.
- **Midge (experimental)** has no script and no Programmable Block. The AI-block XML is a guess and its settings (attack pattern, selected gun, AI Behavior switch) cannot be pre-set: configure it by hand once, see `Scripts/MidgeNotes.md`. **Midge Lite** is only the Gnat Lite frame renamed and still runs `GnatSwarmAI.cs`.
- **Basilisk** is a large-grid ship with no merge block; it cannot be printed (paste only). Longbow S / L have no docking face in the base model (printers add a docking stalk to Longbow S and Mantis).
- Scripts that were forked from the Hornet script (Wasp, Lancer, Harrier, Aegis, Mantis, Basilisk, Watcher) do not share later bug fixes automatically. A drone only joins the hive of another model if both use the same `IGC Tag`.
- **Fused grid (biggest risk).** Blocks welded from a projection become part of the *projector's* grid. After switching both merge blocks off the drone may still be on the printer's grid. `HiveMotherAI` checks this at run time; if the drone is still on the printer's grid it sets the bay to FAULT with a "FUSED" message and sends no `_JOIN`. The fused-grid test (P1) decides.
- **Welder reach is modelled, not measured:** a sphere of 1.3 m (minus 0.2 m margin) around the middle of the welder tip face. If the real centre is deeper inside the welder, bays stall at "N blocks left". Rebuild with `SE_WELDER_BACKOFF=<cells>` to try another guess.
- **Hornet-class drones need touching welders.** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis, Mantis and Longbow S are 6 to 7 cells across, so their interior blocks can only be reached by welders whose tips touch the drone surface (a welder tip has no mount point, so no block attaches, but the surfaces do touch). If touching causes a permanent merge, use the Gnat-class printers (Hive Mother, Twin Hive, Quad Hive, Mobile Hive, Static Nest, Stinger Rack), which keep a full cell of air.
- **No conveyors.** The component stock must sit in a cargo container touching a welder's port, or in the welders themselves. A creative world may not need components at all (unconfirmed). The components needed per drone are listed as comment lines at the top of the PB Custom Data.
- **Cargo containers** (Full printers) have a guessed shape and volume; the Escort Carrier Full also has a guessed `SmallGatlingTurret`. Lite printers have neither.
- **Stinger Rack** prints a minimal fallback Stinger (Gnat frame, two warheads, `StingerAI.cs`) because there is no dedicated Stinger design module.
- Printers are heavy (about 13 to 36 t) and slow to turn; the Static Nest has no thrusters at all (it is still a dynamic grid). Timer / Event-Controller printers ("Midge Nest" and friends) are **not** part of this release.
- **Power budget and run time (computed from `defs_stats.json`, not measured).** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis: 4 small batteries = 0.2 MWh and at most 0.8 MW output; the 12 thrusters could draw 2.4 MW, so a burn on all three axes at once is capped at about 67 % thrust, and a one-axis burn (2 thrusters, 0.4 MW) lasts about 30 minutes. Gnat and Midge Lite: 1 battery = 0.05 MWh and 0.2 MW, i.e. about 15 minutes with the one thruster at full power. Longbow S and Mantis: one 3x2x3 battery = 1 MWh, 4 MW. Longbow L: 12 MWh, 48 MW against 40 MW of thrusters. Power drawn by guns, railgun charging, antenna range and welders is not in the game files, so it is not in these figures. There is no generator or solar panel on any drone: once the batteries are empty the drone is dead weight (`RTB Battery Fraction` sends it home before that).
- **Space only.** Thrust is ion thrust with no gravity term: the best drones accelerate at 6 to 7 m/s2 (Harrier 12 m/s2 forward only), which is less than 1 g (9.81 m/s2), and ion thrusters lose most of their force in an atmosphere. None of these ships can lift off or hover over a planet. Use them in space or at the edge of low gravity. Masses are component masses only; magazines, rockets and cargo add weight.
- **A printed drone leaves with a nearly empty battery.** The CHARGE phase lasts at most `Max Charge Seconds` (default 25 s). A small battery charges at 0.2 MW, so 25 s adds only about 3 % of its 0.05 MWh; a full recharge of a Hornet's 0.2 MWh from the printer's 4 MW pack takes about 15 minutes. A freshly welded battery starts at its definition's initial charge (30 %, unverified for welded blocks), so expect a drone to leave with roughly one third of its endurance (about 10 minutes of one-axis burn for a Hornet class, 5 minutes for a Gnat). Raise `Max Charge Seconds` in the PB Custom Data if you can wait. Drones that return to the printer are not re-docked or recharged by the scripts.
- **PCU.** The table's PCU is the printer alone (welders cost 150 each). Every printed drone adds roughly 700 to 1,700 PCU, and every projected block counts 1 PCU while it is projected. A world with a low block limit (survival defaults) will refuse to paste a Quad Hive (8,381 PCU) or Static Nest (6,244 PCU).

## In-game tests (do them in this order)

1. **World settings and cache (T13, T14).** "In-game scripts" on. Old blueprint folders deleted. Paste once with a stale `bp.sbcB5` left in a folder to see whether it matters. Decides: cause 1 of "script missing after paste".
2. **Paste the Lite twins first** (`Gnat Lite`, `Hornet Lite`, then the rest of the Lite set). Pass: it pastes, no floating blocks (cut one block with a grinder; thrusters, cameras, gyro, PB and antenna must stay), the PB's Edit window shows the code, its Custom Data shows the ini section, no DLC warning. Decides: the generator's basic XML (ComponentContainers, ModStorage custom data, orientation) is right.
3. **Paste the Full variants.** Same checks. If a Full ship fails and its Lite twin pastes, the unseen block shapes (Sensor, AI blocks, Decoy, cargo, turret) are the cause (T2, T11): send a Ctrl+B export of a small grid that holds one each of Timer, Sensor, Turret Controller, Event Controller, AI Offensive / Flight / Defensive, Merge Block, Projector, Welder, Warhead.
4. **Merge face (T1).** On two small grids put two `SmallShipSmallMergeBlock`s with their Up faces towards each other (and separately Right towards Right) and see which pair turns yellow / merges. Then check a drone's merge latch against a printer bay.
5. **Release (T3).** Merge two blocks; switch the drone-side one off, then the printer-side one off. Decides which side can release (needed by the printers; also by hand docking).
6. **Dynamic printer (T4).** Merge a dynamic printer with a drone and unmerge. Repeat with a static one if you want to see the trap.
7. **Pre-loaded projection.** In the printer, the projector must show the drone at the merge block (offset and rotation as generated), with Keep Projection on. Weld one block by hand and check the welded block lines up with the projection.
8. **Welder reach.** Switch on one bay's welders and wait. A bay that stalls at "N blocks left" has unreachable blocks (welder sphere centre guess). Report N and which blocks.
9. **Projected PB (T5, T6).** After the build, open the welded drone's PB: does the Edit window hold the code, does it run, who owns it (and `GetOwnershipFromProjector`)? Does the printer's `Recompile` fix an uncompiled one?
10. **Fused grid (P1).** Weld one drone, switch both merge blocks off, look at the Info / grid list: is the drone a separate grid? If not, the bay shows FAULT "FUSED" and the printer concept needs another way to cut the drone loose.
11. **Full cycle on Hive Mother.** Creative world, stock present: `start`; watch BUILD, CHARGE, RELEASE; the drone should receive `<Tag>_JOIN` and start working. Then `max`, `hold`, `release` commands.
12. **Weapon and ammo behaviour (T8, T9).** Fire each gun class once with an empty inventory (creative vs survival), time the small railgun's trigger-to-impact (Longbow, Mantis), check that Wasp rockets launch (`ShootOnce`) and where they go relative to the moving shooter.
13. **Scriptless Midge (T7).** Configure the AI blocks by hand as in `MidgeNotes.md`, switch AI Behavior on, check that it flies and fires. Send a Ctrl+B export of the configured Midge so the generator can copy the real AI-block XML.
14. **Gyro sign (T10), only for new scripts.** Flight and aim of the Hornet / Longbow scripts worked in earlier tests; confirm the same for Wasp / Lancer / Harrier / Aegis / Mantis (nose turns onto a stationary target).
15. **Runtime and IGC limits (T12).** Print `Runtime.MaxInstructionCount` on a PB; send an IGC test message between two antenna ships at 1 km and 10 km. Decides whether hive messages reach as far as the Watcher's 5000 m antenna implies.

## Changelog

### v2.0 (this package)
- Every model exists as Full and **Lite** (Lite: only block XML shapes seen in a game-written ship, plus the merge block). Both variants build, validate and ship from one generator (`tools/build_all.py`).
- Blueprint generator rewritten around real data: mount-point validation (checked against the Starburst ship), real masses and costs from `defs_stats.json`, `<Toolbar>` written for Sensor/Timer/Turret Controller/Event Controller (probable paste-failure fix), Custom Data stored in ModStorage (the old `<CustomData>` element was ignored by the game), unique blueprint ids, stable (crc32) seeds, no `.sbcB5`.
- Weapon data corrected from the local game files: gatling 700 rpm, 800 m/s (was 400).
- Merge block clamp face corrected: small 1x1x1 block clamps toward Up (was Right); Hornet, Gnat and every printable drone got a clear docking face.
- New drones: **Wasp** (rockets), **Lancer** (autocannon), **Watcher** (unarmed scout), **Harrier** (interceptor), **Aegis** (escort / point defence), **Mantis** (railgun + gatling), **Basilisk** (large-grid rocket gunship), **Midge** (scriptless, experimental).
- New printers (projector + welders + merge block bays, `HiveMotherAI.cs` 2.0): Hive Mother, Twin Hive, Quad Hive, Hornet Forge, Wasp Foundry, Lancer Foundry, Longbow Foundry, Harrier Forge, Aegis Shipyard, Mantis Foundry, Watcher Pad, Fleet Forge, Escort Carrier, Mobile Hive, Static Nest, Stinger Rack.
- Hornet: rear camera moved one cell up to make room for the docking stalk. Gnat: merge block on a 2-cell stalk under the belly.
- Printers: every bay now has an exit lane. Before, Hornet-class bays (Hornet, Wasp, Lancer, Longbow S, Harrier, Aegis, Mantis, Watcher) had a welder on every side of the drone, so the finished drone could not leave. The drone's footprint swept 14 cells away from the merge block is kept free; Longbow S and Mantis leave sideways (outwards, away from the neighbour bay) and HiveMotherAI.cs reads the new per-bay `Exit Direction` Custom Data key to nudge the printer the right way.

### v1.x history
- **v1.0**: Hornet (gatling), Longbow S/L (railgun), Gnat (2-thruster swarm), mothership relays.
- **v1.1**: sensors added; nothing pasted.
- **v1.2**: sensor removed; Longbow stopped reading railgun power.
- **v1.3**: steadiness-gated lead, `Lead Scale`.
- **v1.4**: 5 extra cameras + all-around close scan; compact embedded scripts (size theory later disproven).
- **v1.5**: disabled-target detection, damage sensing and evasion, split focus, on-screen errors.
- **v1.6**: hull-point aim modes.
- **v1.7**: AI-block search hand-off (user places `[AI]` blocks).
- **v1.8** (uncompiled in-game): printer join / re-scan on grid change, Hornet scout mode.
