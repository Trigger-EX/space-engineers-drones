# Space Engineers warships v2.7 (Full)

The warships Shrike, Corsair, Warden and Leviathan in their **Full** design, with the Cradle Pod. Paste-ready scripts for the Helm, Staff and bay Programmable Blocks are in Scripts/.

Package contents: 8 ship blueprints. **No DLC blocks.** The Shrike and Corsair are small-grid ships, the Warden and Leviathan are large-grid ships. All of them can be flown by hand
from their seat and fly and fight by themselves when nobody sits in it. Nothing in this package has been tried in the game yet: it was built and tested in a simulator
(see "What was tested" below, and do the in-game tests at the end first).

| Ship | Class | Grid | Programmable Blocks | Drones |
|---|---|---|---|---|
| **Shrike** | fighter, 1 pilot, 17 m | small | `[Helm] Shrike` | none |
| **Corsair** | corvette, 36 m | small | `[Helm] Corsair`, `[Staff] Corsair`, `[Bay] Corsair` | 2 cradles in the outrigger pylons (`Corsair Wing` = with two Hornets) |
| **Warden** | frigate, 85 m | large | `[Helm][SH] Warden Helm`, `[Staff][SH] Warden Staff`, `[Pod] Pod PB` (on the docked pod) | one docked 4-slot pod (`Warden Wing` = with four Hornets) |
| **Leviathan** | dreadnought, 222 m | large | `[Helm][SH] Leviathan Helm`, `[Staff][SH] Leviathan Staff`, `[Pod] Pod PB 1` and `2` (on the two docked pods) | two docked 4-slot pods (`Leviathan Wing` = with eight Hornets) |
| **Cradle Pod** | empty 4-slot drone pod | small | `[Pod] Pod PB` | docks into a Warden / Leviathan hangar |

## Install

1. Unzip this package anywhere. You get `Blueprints/<Name>/{bp.sbc,thumb.png}`, `Scripts/*.cs` and this README. The scripts in `Scripts/` are compacted (no comments) so that they fit the
   Programmable Block limits; the commented originals in `Scripts/Source/` are for reading only. The blueprints already carry the scripts in their Programmable Blocks.
2. **Delete the old blueprint folders first.** Open `%AppData%\SpaceEngineers\Blueprints\local\` and remove every folder of an earlier version of these ships (also the `bp.sbcB5` next to
   `bp.sbc`: the game keeps loading that stale cache). This package never ships a `.sbcB5`.
3. Copy the `Blueprints/<Name>` folders you want into `%AppData%\SpaceEngineers\Blueprints\local\`. In game press **F10**, pick the ship and paste it (creative tools, or a projector in survival).
   Every ship is a **dynamic** ship; do not convert it to a station.
4. "In-game scripts" must be enabled in the world settings, otherwise the Programmable Blocks do not run.
5. If something does not paste, send the game log (`%AppData%\SpaceEngineers\SpaceEngineers_*.log`) and say which model and variant. **Which variant?** `<Name>` (Full) uses the whole design,
   including block types whose XML has never been seen in a game-written blueprint (turrets, sensor, AI blocks, decoys, cargo containers, Run toolbar slots); `<Name> Lite` uses only shapes copied
   from a game-written ship (no turrets, so no point defence, no sensor, no decoys, no toolbar `Run` slots). If a Full ship does not paste, try its Lite twin.
6. Drones for the cradles come from the **Drones** package (Hornet, Wasp, Lancer, Harrier, Aegis, Mantis, Watcher); the `* Wing` ships already carry Hornets.

**Warship specifics.** Large-grid ships are pasted as a free ship in creative mode (or from a projector in survival). The Warden (about 10,300 PCU with its pod) and the Leviathan
(about 33,000 PCU with both pods) need a world limit to match: the repository file `docs/design/ships/Leviathan.md` lists what to delete for a 20,000 PCU world. The pods are separate grids in the same
blueprint, docked by two connector pairs: after the paste look at the hangar connectors in the terminal and press **Lock** on each pair that is not locked. Every ship comes with its
guns loaded, its tanks and batteries full and its Programmable Blocks programmed and configured; there is nothing to copy into a PB. The scripts are in `Scripts/` only for re-pasting.

## Models

| Model | Variant | Blocks | Mass kg | Accel m/s2 | PCU | Script |
|---|---|--:|--:|--:|--:|---|
| Cradle Pod | Full | 605 | 16518 | 0.0 | 1643 | CradleBayAI |
| Shrike | Full | 1278 | 59318 | 8.1-16.2 | 2864 | ShrikeAI |
| Corsair | Full | 6601 | 279167 | 3.4-6.9 | 11735 | CradleBayAI, ShrikeAI, StaffAI |
| Corsair Wing | Full | 6601 | 279167 | 3.4-6.9 | 11735 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Warden | Full | 1220 | 2758126 | 1.6-3.8 | 9862 | CradleBayAI, ShrikeAI, StaffAI |
| Warden Wing | Full | 1220 | 2758126 | 1.6-3.8 | 9862 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |
| Leviathan | Full | 8550 | 14895816 | 1.0-1.9 | 34251 | CradleBayAI, ShrikeAI, StaffAI |
| Leviathan Wing | Full | 8550 | 14895816 | 1.0-1.9 | 34251 | CradleBayAI, HornetDroneAI, ShrikeAI, StaffAI |

### Cradle Pod

Small-grid 4-slot drone cradle (merge blocks), Pod PB, two ConnectorMedium, batteries and reactors, backup timers; docks into the Warden / Leviathan hangars. Empty: drones are added by pasting them touching the merge blocks (designs/pods.py attach_drone). No propulsion.

* **Cradle Pod**: 605 blocks, 16518 kg, 19.0x5.5x7.5 m, accel F0.0 B0.0 U0.0 D0.0 L0.0 R0.0 m/s2, PCU 1643; script: CradleBayAI.cs; cost Iron 16544 Nickel 200 Cobalt 12 Silicon 59 Silver 30 Stone 120

Note: Paste next to a large hangar and dock the two connectors (or paste the Warden, which carries it docked). Merge-block clamp face and the connector lock at paste are unverified (docs/design/ships/Pod.md, C1..C4).

### Shrike

Delta-wing fighter (small grid, 17 m): one pilot in a fighter cockpit, one Programmable Block "[Helm] Shrike" (ShrikeAI.cs), Remote Control, two autocannons + two gatlings (battery [B1]) and an assault cannon ([B2]) fixed forward, eight large hydrogen thrusters on three full tanks (16 m/s2 forward and back, 8 m/s2 up / down / sideways), six gyros, two charged batteries, two uranium reactors, six cameras, antenna, dead-man timer. No drone bay. Limitation: the autocannons hold 3 magazines (19 s of fire) and the assault cannon 3 shells; the 12 + 10 spare magazines in the nose container touch the guns exactly as the owner's Pod Chaser layout does, but whether that feeds them is untested in game.

* **Shrike**: 1278 blocks, 59318 kg, 15.5x7.0x17.5 m, accel F16.2 B16.2 U8.1 D8.1 L8.1 R8.1 m/s2, PCU 2864; script: ShrikeAI.cs; cost Iron 63516 Nickel 2680 Cobalt 1347 Silicon 1010 Silver 30 Stone 120

### Corsair

Catamaran-hammerhead corvette (small grid, 33 m x 26.5 m x 12 m): charcoal hull with orange accents, hammer crossbar at the bow carrying two assault cannons and two autocannons, a dorsal ridge with two small railguns (B1), a stepped bridge tower with the cockpit, four point-defence gatling turrets and an assault turret (Full), 14 large hydrogen thrusters on 10 full tanks (7.1 m/s2 forward, 3.6 m/s2 in the other directions), 40 gyros, a 14.75 MW reactor and four charged batteries, three Programmable Blocks ("[Helm] Corsair", "[Staff] Corsair", "[Bay] Corsair" for the cradles), dead-man timer, hand-flyable. Two cradle pods on outrigger pylons, each a 9 x 8 x 9 cell bay for a Hornet-class drone (Hornet, Wasp, Watcher, Harrier, Lancer, Aegis), nose forward, 24-cell launch lane; the bay merge blocks are "[SH] [Bay n] Merge ...". Limitation: the assault cannons hold 3 shells, the autocannons 3 clips (48 rounds) and the railguns 6 slugs; there is no conveyor feed (port positions are not known), so those guns run dry after a short fight. Paste it empty and add drones by hand, or use Corsair Wing.

* **Corsair**: 6601 blocks, 279167 kg, 26.5x12.0x33.0 m, accel F6.9 B3.4 U3.4 D3.4 L3.4 R3.4 m/s2, PCU 11735; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 301682 Nickel 11315 Cobalt 6201 Silicon 1278 Gold 80 Silver 475 Stone 1900

### Corsair Wing

Catamaran-hammerhead corvette (small grid, 33 m x 26.5 m x 12 m): charcoal hull with orange accents, hammer crossbar at the bow carrying two assault cannons and two autocannons, a dorsal ridge with two small railguns (B1), a stepped bridge tower with the cockpit, four point-defence gatling turrets and an assault turret (Full), 14 large hydrogen thrusters on 10 full tanks (7.1 m/s2 forward, 3.6 m/s2 in the other directions), 40 gyros, a 14.75 MW reactor and four charged batteries, three Programmable Blocks ("[Helm] Corsair", "[Staff] Corsair", "[Bay] Corsair" for the cradles), dead-man timer, hand-flyable. Two cradle pods on outrigger pylons, each a 9 x 8 x 9 cell bay for a Hornet-class drone (Hornet, Wasp, Watcher, Harrier, Lancer, Aegis), nose forward, 24-cell launch lane; the bay merge blocks are "[SH] [Bay n] Merge ...". Limitation: the assault cannons hold 3 shells, the autocannons 3 clips (48 rounds) and the railguns 6 slugs; there is no conveyor feed (port positions are not known), so those guns run dry after a short fight. Corsair Wing is the same ship with two Hornets already clamped in the cradles as separate CubeGrids (merge blocks touching, enabled). Paste risk C1 (grids_bays.md): whether the game merges the touching grids at paste time is untested; if the drones float free on paste, toggle the bay merge blocks Off/On, or paste Corsair and the drones separately. The drones add 2 x 4.4 t that the acceleration figures do not include.

* **Corsair Wing**: 6601 blocks, 279167 kg, 26.5x12.0x33.0 m, accel F6.9 B3.4 U3.4 D3.4 L3.4 R3.4 m/s2, PCU 11735; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 301682 Nickel 11315 Cobalt 6201 Silicon 1278 Gold 80 Silver 475 Stone 1900

### Warden

LARGE-grid frigate (about 85 x 27.5 x 40 m, 2.6 kt with ammunition): two large railguns (battery [B1]), two artillery and four assault turrets, eight gatling turrets for point defence, six decoys, a four-engine hydrogen stern (1 large + 3 small, 4 m/s2), 20 small hydrogen thrusters for the other axes, a bridge tower with cockpit, Remote Control and the Helm and Staff programmable blocks, and a belly hangar (8 doors) with a docked, empty 4-slot Cradle Pod for Hornet-class drones (own CubeGrid and Pod PB). Ammunition, uranium, hydrogen and batteries are pre-loaded; 101 junction blocks feed the thrusters and every turret from the tanks and two ammo lockers. Limits: the two railguns have no feed (6 slugs each, reload by hand from the lockers), the pod carries no drones, and nothing of this has been pasted in the game yet.

* **Warden**: 1220 blocks, 2758126 kg, 27.5x40.0x85.0 m, accel F3.8 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 9862; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 3036400 Nickel 166410 Cobalt 96228 Silicon 12416 Gold 660 Silver 3030 Stone 12000

Note: Large grid, paste only (delete the old blueprint folder first). Needs the Helm / Staff / Pod scripts for autonomous play (PBs stay empty until the script files exist); flyable by hand from the bridge cockpit. The pod is a second grid docked by two connector pairs: press Lock on both hangar connectors if it did not lock (docs/design/ships/Warden.md, C1..C4). Drones are added by pasting them against the pod's merge blocks.

### Warden Wing

The Warden with four Hornets already clamped in its pod (each stern merge block on a cradle merge block): launch them with `launch all` on the Staff PB. Adds 216 blocks and about 4,000 PCU to the empty Warden.

* **Warden Wing**: 1220 blocks, 2758126 kg, 27.5x40.0x85.0 m, accel F3.8 B1.6 U1.6 D1.6 L1.6 R1.6 m/s2, PCU 9862; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 3036400 Nickel 166410 Cobalt 96228 Silicon 12416 Gold 660 Silver 3030 Stone 12000

Note: Large grid, paste only (delete the old blueprint folder first). Needs the Helm / Staff / Pod scripts for autonomous play (PBs stay empty until the script files exist); flyable by hand from the bridge cockpit. The pod is a second grid docked by two connector pairs: press Lock on both hangar connectors if it did not lock (docs/design/ships/Warden.md, C1..C4). Drones are added by pasting them against the pod's merge blocks.

### Leviathan

LARGE-grid dreadnought (about 222 x 72 x 42 m, 14 kt with ammunition): a stepped wedge with an armoured dorsal citadel and a glazed bridge tower, a forward main-battery spine of six large railguns (battery [B1]), eight artillery and twelve assault turrets on the flank ledges, twenty gatling turrets for point defence, four rocket turrets (Full only) and twelve decoys; four large hydrogen engines (2 m/s2 forward) and ten more large thrusters for the other axes, 144 gyros, one large and eight small reactors, 20 batteries, four hydrogen tanks, Helm and Staff programmable blocks, bridge cockpit, gunnery seat and Remote Control, and two flank hangars (eight doors each) with a docked, empty 4-slot Cradle Pod each (own CubeGrids and Pod PBs, room for 8 Hornet-class drones). Ammunition, uranium, hydrogen and batteries are pre-loaded and about 270 junction blocks feed the thrusters and the artillery / assault / rocket turrets from the tanks and four ammo lockers. Limits: the six railguns have no feed (6 slugs each, reload by hand from the lockers), the pods carry no drones, about 33,000 PCU with the pods (worlds of 50 k or more; the doc lists what to drop for 20 k), and nothing of this has been pasted in the game yet.

* **Leviathan**: 8550 blocks, 14895816 kg, 72.5x42.5x222.5 m, accel F1.9 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 34251; script: CradleBayAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 16462454 Nickel 829930 Cobalt 486039 Silicon 13626 Gold 2060 Silver 14030 Stone 56000

Note: Large grid, paste only (delete the old blueprint folder first). About 33,000 PCU with the two pods: needs a world limit of 50 k or more (docs/design/ships/Leviathan.md lists the trimming steps for 20 k). The Helm, Staff and Pod scripts are embedded in the PBs; flyable by hand from the bridge cockpit. Each pod is a second / third grid docked by two connector pairs inside its hangar: press Lock on the hangar connectors if a pod did not lock. Drones are added by pasting them against the pods' merge blocks.

### Leviathan Wing

The Leviathan with eight Hornets already clamped, four in each hangar pod: launch them with `launch all` on the Staff PB (the second pod follows the first by 20 s). Adds 432 blocks and about 8,000 PCU to the empty Leviathan (about 41,000 PCU in all: a world limit of 50 k or more).

* **Leviathan Wing**: 8550 blocks, 14895816 kg, 72.5x42.5x222.5 m, accel F1.9 B1.0 U1.0 D1.0 L1.0 R1.0 m/s2, PCU 34251; script: CradleBayAI.cs, HornetDroneAI.cs, ShrikeAI.cs, StaffAI.cs; cost Iron 16462454 Nickel 829930 Cobalt 486039 Silicon 13626 Gold 2060 Silver 14030 Stone 56000

Note: Large grid, paste only (delete the old blueprint folder first). About 33,000 PCU with the two pods: needs a world limit of 50 k or more (docs/design/ships/Leviathan.md lists the trimming steps for 20 k). The Helm, Staff and Pod scripts are embedded in the PBs; flyable by hand from the bridge cockpit. Each pod is a second / third grid docked by two connector pairs inside its hangar: press Lock on the hangar connectors if a pod did not lock. Drones are added by pasting them against the pods' merge blocks.


## How the ships think (and what runs where)

One script family, three jobs, each in its own Programmable Block so that none comes near the 100,000-character or the 50,000-instruction limit:

| script | runs in | minified characters | limit |
|---|---|--:|--:|
| `CradleBayAI.cs` | Bay / Pod PB (Corsair, each pod) | 17,339 | 100,000 |
| `HornetDroneAI.cs` | the Hornets of the Wing ships | 92,967 | 100,000 |
| `ShrikeAI.cs` | Helm (every ship) | 79,977 | 80,000 |
| `StaffAI.cs` | Staff (Corsair, Warden, Leviathan) | 23,086 | 100,000 |

* **Helm** (`ShrikeAI.cs`, the same script on every ship): finds, tracks and shoots the target, flies the ship (thrusters, gyros) and hands the controls to you when you sit down.
  It is the only block that ever writes a thruster or gyro override. Fixed guns are grouped by the `[B1]` .. `[B4]` tag in their names into up to four batteries (ballistic,
  rocket, railgun, shell cannon: each gets its own lead solver); turrets are left to the game's own turret AI and count as extra designators. With turrets aboard it also
  has a *turret-only* mode (a target none of the fixed guns can hit is ignored by them, the ship keeps its broadside to it) and it chooses the stand-off distance from the weapons.
* **Staff** (`StaffAI.cs`): the ship's officer. It watches a heartbeat from the Helm and **releases every thruster and gyro override when the Helm stops** (about 1.5 s: the
  dead-man switch), shows status on the cockpit screens, tells the drones where the ship is (so they can fly a ring round it, `wing satellite`) and which target the Helm has, runs the
  hangar doors and the launch of the drones, and forwards the words you give it to the Helm.
* **Bay / Pod PB** (`CradleBayAI.cs`): one per pod (or on the Corsair), manages the merge-block cradles: charges the drone, checks the way out is clear, lets go, repeats for the next drone.
  The Staff talks to it over the antenna (IGC channel `<Ship Tag>.S2P` and `.P2S`).
* A **Timer** named `... Timer D (deadman)` (5 s) is re-armed by the Helm every second while the Helm flies and cuts the thrusters and weapons if the Helm dies; it is stopped while you
  fly. The Shrike and Corsair carry one Event Controller `EC Cockpit (configure in game)` (cockpit occupied -> stop the timer, empty -> start it: this second layer of the dead-man needs you to pick the event once, its number has never been seen in a game file); the Warden and Leviathan carry `EC Cockpit`, `EC Power` (same: pick the events by hand) and `EC Core` (reactor integrity below 40 % -> `Run` the Staff with no argument, which steps its menu to `wing satellite`).
* **Why one Helm script for a 60-tonne fighter and a 14-kilotonne dreadnought?** The measured numbers (docs/design/ships/*.md in the repository) say a class setting is enough: the stand-off range, speeds and
  the dodging (off for the large ships) are Custom Data, the turn-rate limit is measured by the script itself from the gyros' response (`Auto Max Turn`), and the weapons decide the
  stand-off distance. The large ships just carry different numbers in their Helm Custom Data.

## Commands

Commands are the **argument** of a Programmable Block (run it with the text; toolbar slots do this), or arrive over IGC. **Run a Helm or Staff PB with no argument** and it steps a
menu instead: each press highlights the next item (shown on the PB screen and on the cockpit HUD), the highlighted item runs 2 s after the last press. That is what the cockpit
toolbar slots use (a `Run` slot may not be able to carry a typed argument: step 3 of the test list at the end).

**Staff PB** (anything it does not know goes to the Helm):

| argument | does |
|---|---|
| `wing hunt` / `guard` / `rtb` / `follow` / `satellite` | order every drone of the types in `[Wing] Types`: attack what the ship has locked, hold, go home, follow, or fly the ring round the ship (100 m, grows with the hull) |
| `wing lock` | send the Helm's target to the drones now and `hunt` |
| `wing roll` / `page` | roll call of the wing (alive, engaged, range) on page 2 of the cockpit display |
| `launch [n \| a-b \| all] [force]` | **the way to launch drones in a fight**: parks the Helm (idle, dampeners on) so that the ship stops turning and accelerating, opens the hangar doors, releases the drones one by one (2 s apart, 20 s between pods), then gives the Helm its mode back. `n` and `a-b` are bay numbers |
| `release <n \| a-b \| all> [delay_s] [force]` | the same without touching the Helm. The bays wait until the ship turns slower than 0.1 rad/s and accelerates slower than 1 m/s2 (the drone leaves with the ship's velocity); `force` skips the gates. A request is dropped after 60 s |
| `hold n` / `unhold n` | keep a bay shut / free it |
| `recall` | `wing rtb`, 12 s later `wing satellite`, bays cancel their pending releases and switch the cradle merge blocks on (docking back by hand is not scripted) |
| `doors open` / `doors close` | the `[Hangar n]` doors |
| `status`, `reload` | refresh the screen / re-read Custom Data and re-scan blocks |
| `hunt` `guard` `rtb` `idle` `manual` `auto` `assist hud\|fbw\|off` `lock` `unlock` `next` `range <m>` `home` `aim <mode>` `breach on\|off` | forwarded to the Helm (below) |

**Helm PB**: `guard` (hold the home point, engage within Guard Radius), `hunt` (chase and engage), `rtb`, `idle` (release everything: thrusters and gyros off, dampeners on), `lock` (raycast-lock
what the front camera points at), `unlock`, `next` (ignore this target for 60 s), `range <m>` (stand-off), `home` (set home here), `aim AUTO|BREACH|ENGINES|FACING|SPREAD|CENTER`,
`breach on|off`, `ai on|off` (use the AI blocks to search), `reload`, and the manual-flight words `manual`, `auto`, `pilot` (toggle), `assist hud|fbw|off`.
The Helm starts in `REACT` (it saves its mode): weapons, turrets and target tracking are live, but the ship does not yaw round, scan with its cameras or hand itself to the AI blocks
until something wakes it: an AI Defensive block running the Helm with `aialert`, a mate's alarm, damage taken, or a target a turret already holds. Then it behaves like `guard`; when the
alarm and the damage are over (about 10 s) it goes quiet again. `guard` = always sweep, `hunt` = sweep and chase, `react` = back to the default. The first fight of a ship that has nothing to shoot at: `hunt`.

**Bay / Pod PB**: `release`, `recall`, `hold`, `unhold`, `status`, `reload` (the same words as the Staff).

## Flying by hand (manual mode)

1. **Sit in the pilot seat**: `[SH] Cockpit [Helm Seat]` (Shrike, Corsair) or `Bridge Cockpit` (Warden, Leviathan). Within 0.4 s the Helm switches to **MANUAL**: it releases every gyro
   and thruster override in that same tick, puts the dampener switch back to what you had, switches the AI blocks off and stops the fixed guns it had switched on. You fly with the
   ordinary controls. Tracking, the camera scan, the lock, the turrets and the point defence keep working; the fixed guns only fire when **you** fire them
   (`Auto Fire In Manual` is false). The Remote Control and the `Gunnery Seat` (Warden, Leviathan) do not take the ship from the Helm.
2. **HUD**: cockpit screen 0 shows the mode, the target, range, the battery that would fire and a **lead pip** (how far to move the nose, in degrees) with the fire window. The Staff writes
   its status on screen 1 and the wing roll call on screen 2 (which screens your cockpit really has is test K9 in `tests.md`; `[Manual] HUD Surface`, `[Staff] Cockpit Surface`,
   `Helm HUD Surface`, `Wing Surface` re-map them).
3. **Assist levels** (`assist hud|fbw|off` on the Helm, default `hud`): `off` nothing; `hud` the pip and the fire window only; `fbw` fly-by-wire: your stick rate is blended with the script's rate
   towards the lead point, it needs a lock (`lock`), and any stick movement takes the blend away within 0.2 s. (`assist` with no word is the old Hornet mode: the script aims and fires, you fly.)
4. **Leave the seat**: after 1.5 s (`Release Delay`) the Helm is back in the mode it had; it does not snap the nose (the turn-rate limit ramps up over 2 s) and the lock resumes.
5. **`manual`** (to the Helm or the Staff) forces MANUAL with nobody in the seat (the ship then does nothing: Remote-Control or turret-only play), **`auto`** forces AUTO with a pilot aboard
   (the ship flies itself and you get the HUD), `pilot` toggles. Both are cancelled by the seat changing.
6. **Cockpit toolbar** (Full variants; page 1): weapon slots, `Main Turrets` / `PD` / `Decoys` on-off, hangar doors, `Run` Helm, `Run` Staff (the menu). Lite variants have the weapon slots only.
7. If the nose turns the wrong way or too fast under `assist fbw`, change `[Manual] Pilot Rot Sign` (1 or -1), `Pilot Rate Gain` and `Rotation Input Scale` (never measured in the game: step 3 of the test list at the end).

## Launching the drones (wing)

* **Which drones**: Hornet-class drones from the Drones package (`Hornet`, `Wasp`, `Lancer`, `Harrier`, `Aegis`, `Mantis`, `Watcher`) that carry a rear merge block. The `* Wing` ships
  come with Hornets already clamped (`Corsair Wing` 2, `Warden Wing` 4, `Leviathan Wing` 8): those are the easy way.
* **Loading by hand**: paste the drone so that its merge block touches the cradle's merge block (the cradle merge blocks are named `[SH] [Bay n] Merge ...` on the Corsair and `[POD] Merge n` on the pods; the drone's merge block
  is at its tail). Both merge blocks must be switched on; the game joins the two grids when they touch. Details and coordinates per slot: `docs/design/ships/Pod.md` (section 3).
  The Corsair's bays only look for drone blocks named `Hornet...` (`Drone Prefix=Hornet` in the `[Bay] Corsair` Custom Data): change it to the drone's name (or delete the line) for another
  type. The pod PBs take any drone.
* **Launch**: `launch all` on the Staff PB (or `launch 1`, `launch 1-2`). The ship parks (idle), the doors open, each drone's batteries are put on recharge if they are below 90 %, the
  drone is armed and the cradle lets go; the drone burns clear of the ship along the bay's `Away` direction and starts in `GUARD`. Then give the wing its job: `wing satellite` (ring),
  `wing hunt`, `wing follow`. Bay numbers are global: the Leviathan's second pod starts at 5.
* **Cockpit buttons** (Warden, Leviathan: slots 9-10 of the first toolbar page; Corsair: slots 8-9): `deploy` = open the hangar doors, `launch all`, and once the bays have let go send
  `wing satellite` (the drones form the ring round the ship); `dock` = `wing rtb`, bays cancelled, hangar doors open. Docked drones have their thrusters switched off by the bay PB (they come on at release).
* **Recall**: `recall`. Docking the drones back into the cradles is not scripted (phase 2): `dock` only calls them home; fly them next to the cradle and paste/merge by hand, or let them be.
* If nobody answers (`NO BAY ANSWERED` on the Staff screen) the pod PB cannot be reached across the docked connectors: run `release n` on the pod PB itself, or use its Timer `[POD] Timer R(n)`.

## Custom Data (what you can change)

Every PB keeps its settings in Custom Data (ini text; the scripts write the keys they know on first start). After editing run the PB with `reload`.

* **Helm** `[Shrike]`: `IGC Tag`, `Start Mode (GUARD/HUNT/ASSIST/IDLE)`, `Standoff Range`, `Min Range`, `Max Fire Range`, `Guard Radius`, `Combat Speed`, `Cruise Speed`, `Orbit Speed`,
  `Evasive Jinking`, `Auto Camera Scan`, `AI Block Search Assist`, `Share Targets Over IGC`, `Friendly Fire Check`, `Fire Window Multiplier`,
  `Aim Point (AUTO/BREACH/ENGINES/FACING/SPREAD/CENTER)`, `Breach Large Ships (AUTO)`, `Max Turn Rate rad/s`.
  `[Manual]`: `Seat Debounce`, `Release Delay`, `Assist (OFF/HUD/FBW)`, `Assist Max Rate`, `Pilot Rate Gain`, `Pilot Rot Sign`, `Rotation Input Scale`, `Pilot Priority Rate`,
  `Auto Fire In Manual`, `Scan In Manual`, `Run Menu`, `Run Menu Wait`, `Deadman Timer Name`, `Seat Exclude (name part)`, `HUD Surface`.
  `[Battery]`: `Primary (AUTO/B1..B4)`, `Standoff By Weapons`, `Turret Only (AUTO/ON/OFF)`, `Auto Max Turn (AUTO/ON/OFF)`.
  `[Link]`: `Enable (AUTO/ON/OFF)`, `Ship Tag`, `Block Prefix`, `Heartbeat (s)`. `[Ship]`: `Tag`.
  Also `[Fleet]`, `[Kamikaze Defence]`, `[AI Gate]` as in the drones.
  The **Block Prefix** `[SH]` matters: the Helm and the Staff only use blocks whose name starts with it, so drones clamped in the cradles (they are blocks of the same grid while clamped) and the
  pod are never adopted as thrusters or guns. Name every block you add `[SH] ...` (the Warden and Leviathan PBs are named `[Helm][SH] ...`).
* **Staff** `[Staff]`: `Ship Tag`, `Block Prefix`, `Trip Time (s)` (1.5), `Watch Helm`, `Cockpit Surface`, `Helm HUD Surface`, `Wing Surface`, `Display Name`, `Wing Display Name`, `Run Menu`,
  `Run Menu Wait`, `Pod Gap (s)` (20), `Door Open Wait (s)`, `Door Close After (s)`, `Recall Satellite After (s)`; `[Wing] Types` (the drone types it talks to); `[Hangar n] Group`, `Pod`.
  The **Ship Tag** of the Helm (`[Link] Ship Tag` or `[Ship] Tag`), the Staff and the Pod PBs (`[Pod] Tag`) must be equal; it is `SH` on the Corsair, `WARDEN` / `LEVIATHAN` on the large ships.
* **Bay / Pod PB** `[Pod]`: `Tag`, `First Bay`, `Slots`, `Charge Fraction`, `Wave Gap`, `Arm Seconds`, `Fused Grace`, `Cooldown`, `Wait Max`, `Max Turn`, `Max Accel`, `Join Seconds`, `Lane Check`,
  `Lane Cells`, `Match Radius`, `Fleet Channel`, `Fleet Secret`; `[Bay n]`: `Merge`, `Drone Box Min/Max`, `Drone Prefix`, `Drone Tag`, `Away`, `Timer`.

## What was tested, and what was not

Everything below was done in the simulator that runs the real scripts (`SimHost.exe selftest m6`, `docs/design/ships/*.md`), against its own stand-in enemies. **It proves that the
scripts, names and Custom Data fit together and that the logic holds; it proves nothing about the game's own behaviour.**

* Tested in the sim: every PB finds exactly its ship's own blocks; a scripted pilot sits, flies, turns and leaves with no fight over the controls; the dead-man releases within 1.2 s; the
  drones leave the cradles with `launch all`, form the ring and shoot; turn rates, accelerations and stopping distances against the design numbers; instruction counts
  (peak per PB under 40,000 in the pessimistic IL model); fights against the sim's Pirate ship, small drone groups and the Tech Hunter (`docs/design/ships/*.md` for the numbers).
* Known weak spots, from the same runs: the **Lite Shrike and Lite Corsair** (no AI blocks, no turrets) do not find a target on their own - fly them (`lock`) or use the Full ships; a lone Shrike finds small attackers late and lost to a single Hornet in 3 of 5 sim duels (to three Hornets always); the sim's Gnat swarms rarely close on a ship that does not look for them; `launch` while a pilot flies waits for the pilot to hold still; docking the drones back is not scripted.
* Not tested and different in the game, possibly: the gyro feel and stick scale (`Pilot Rot Sign`...), the toolbar `Run`, IGC latency and range between the ship and its drones, merge-block clamping and
  the real separation, connector locking of the pods, conveyor-fed ammunition and hydrogen on the large ships (the sim has no conveyor model and unlimited hydrogen), large-grid damage (the sim is
  optimistic: large thrusters and batteries die 1.6 to 5.9 times too slowly), the enemy AIs (stand-ins) and the real count of "instructions" (the sim reports a block model and a pessimistic IL model).

## First in-game tests, in this order

1. **Paste the Lite twins** (`Shrike Lite`, `Corsair Lite`, then `Warden Lite`), then the Full ships. A failure of a Full ship that its Lite twin does not have points at the block shapes that have never been seen
   in a game file (turrets, sensor, AI blocks, decoys, timer toolbars). Large ships: check the PCU against the world limit.
2. **The scripts start**: open each PB: the screen shows the script and version (ShrikeAI 0.1, StaffAI 1.4, CradleBayAI 1.0), no `Script too complex`, no red text. Let the ship idle for 5 minutes in `guard` and
   fly it in `hunt` against a target: if any PB stops with "too complex", the game counts instructions harder than the sim's block model; report which one.
3. **Sit down** (Shrike first): MANUAL within half a second, the ship flies normally, the HUD pip appears, the ship goes back to AUTO 1.5 s after you stand up.
   Then try `assist fbw` with a lock. If the nose swings the wrong way, flip `Pilot Rot Sign`. Try the Run menu from a toolbar slot: does `Run` with no argument step the menu, and can you set a
   `Run` slot with an argument on the PB (Ctrl+B export; test K3)?
4. **Dead-man**: switch the Helm PB off in the terminal while the ship flies in `hunt`: within about 1.5 s the thrusters and gyros must be released, the guns off, "HELM LOST" on the cockpit screen, and the Timer `(deadman)` fires after 5 s. Switch the PB on again: "Helm back".
5. **Fuel and ammunition** (Warden, Leviathan): every thruster shows hydrogen, turrets refill from the lockers, railguns hold their slugs (the generator writes no conveyor lines; if a branch is dry, rebuild one junction).
6. **Cradles**: Corsair Wing: are the two Hornets still clamped after the paste (one grid or three in the terminal)? `release 1` on the `[Bay] Corsair` PB; then `launch all` on the Staff. Warden Wing: the pod docked and locked, `launch all`
   (the Staff reaches the pod across the connectors, or says it did not), `doors open|close`.
7. **A fight**: a pirate ship or a few enemy drones at 1-2 km. The ship should lock, hold its stand-off (700 m Warden, 800 m Leviathan, from the weapons on the small ships), shoot with every battery it can, and keep
   the turrets busy. `wing satellite` then `wing hunt` with a launched wing.
8. Anything from `packages/tests.md` marked [ship] that is not covered above.

## Known unknowns

- **Merge-block clamp face (unverified).** The small 1x1x1 merge block (`SmallShipSmallMergeBlock`) clamps toward its local **Up** face (one wiki source); the old assumption was Right. Every merge pair in this package is built on that. It is one constant (`MERGE_CLAMP_FACE_SMALL` in `tools/designs/_common.py`); if the merge-face test (T1) shows another face, change it and run `tools/build_all.py` again.
- **Lite variants keep the small merge block.** Its XML shape comes from the Keen source, not from the Starburst reference, so strictly a Lite ship is not 100 % "seen" XML. A drone or printer without it cannot be printed or docked. `LITE_KEEPS_MERGE = False` in `_common.py` drops it from the drones.
- **XML shapes never seen in a game-written blueprint:** Sensor, the AI blocks (Offensive, Flight, Defensive), Decoy, large gatling turret, Timer and Event Controller toolbars. They are why Full variants exist next to Lite ones. Earlier blueprints with a Sensor or Custom Turret Controller failed to paste; the leading hypothesis is a missing `<Toolbar>` element (now always written), but that is not confirmed.
- **Projected Programmable Blocks.** A welded PB may keep its Program text but not start by itself. The printer script calls `ApplyAction("Recompile")` on it; whether that works is the projected-PB test (T5, T6).
- **No ammunition is pre-loaded** in any gun or launcher (the generator cannot write inventories). In a survival world load magazines / rockets by hand; in a creative world the guns may still need magazines unless the world has infinite ammunition switched on (test T8 shows which). Scripts treat an unknown ammo count as unlimited and never return to base for lack of ammo in that case.
- **Scripts have never run in the game with these versions.** They compile against a hand-written stub of the game API (`tools/compile_check.sh`), which proves syntax and types only.
- **Weapon numbers** come from the local game data (gatling 700 rpm, 800 m/s, 800 m; small rocket 500 damage, 4 m blast; small railgun 1000 m/s, 1400 m, 500 ms shot delay). Rockets are assumed (v2.3) to leave with the shooter's velocity plus their launch speed, accelerate along the barrel and have their total speed capped, so a rocket fired from a moving ship curves onto the barrel line (Keen bug tracker). Test 18 in the test list checks it; if your rockets fly dead straight from a ship moving sideways, set `Rocket Velocity Model=NONE` on the Basilisk and Wasp.
- **Power budget and run time (computed from `defs_stats.json`, not measured).** Hornet, Wasp, Lancer, Watcher, Harrier, Aegis: 4 small batteries = 0.2 MWh and at most 0.8 MW output; the 12 thrusters could draw 2.4 MW, so a burn on all three axes at once is capped at about 67 % thrust, and a one-axis burn (2 thrusters, 0.4 MW) lasts about 30 minutes. Gnat and Midge Lite: 1 battery = 0.05 MWh and 0.2 MW, i.e. about 15 minutes with the one thruster at full power. Longbow S and Mantis: one 3x2x3 battery = 1 MWh, 4 MW. Longbow L: 12 MWh, 48 MW against 40 MW of thrusters. Power drawn by guns, railgun charging, antenna range and welders is not in the game files, so it is not in these figures. There is no generator or solar panel on any drone: once the batteries are empty the drone is dead weight (`RTB Battery Fraction` sends it home before that).
- **Space only.** Thrust is ion thrust with no gravity term: the best drones accelerate at 6 to 7 m/s2 (Harrier 12 m/s2 forward only), which is less than 1 g (9.81 m/s2), and ion thrusters lose most of their force in an atmosphere. None of these ships can lift off or hover over a planet. Use them in space or at the edge of low gravity. Masses are component masses only; magazines, rockets and cargo add weight.
- **Script size headroom is small.** Minified, the Basilisk script is 97,721 of the 100,000 characters a Programmable Block takes (Wasp 95,313, Mantis 94,623). The build stops with an error when a script goes over; the next big feature will need code moved out or trimmed.
- **One Helm script for all four ships.** `ShrikeAI.cs` (a Hornet-derived script, 79,990 of its 80,000 characters) flies the 60-tonne fighter and the 14-kilotonne dreadnought alike; the large ships differ only by Custom Data (stand-off 700 / 800 m, jinking off, `AI Block Search Assist` off, stand-off from the weapons off). A `HelmAI.cs` for the large ships was not needed in the sim; whether the game's gyro and thruster response lets the same controller settle on a 14 kt hull is in-game test 35. The script has no room left (10 characters): the next feature must remove something (the AI-block support is the agreed first cut).
- **Instruction counts.** The sim counts a block model (Helm peak about 1,700) and a pessimistic IL model (Helm peak about 25,000 of 50,000, Staff 9,500, bay 15,700, Hornet 17,000). Which of the two the game's counter resembles is not known (test 30); the integrity scan is sliced for that reason.
- **Large-ship fights are optimistic in the sim.** Large thrusters and batteries die 1.6 to 5.9 times too slowly there, hydrogen is unlimited, there is no conveyor model (ammunition and fuel are "free"), the enemy ships are stand-ins (the Pirate brain), and the connector-docked pods are held rigidly to the host (RigidLink: no real connector, no pod mass). Kill times and win rates in `docs/design/ships/*.md` are for comparing settings, not for predicting the game.
- **Small drones are hard to find at long range.** The Helm confirms what the AI blocks see with camera rays; a 54-block Hornet is 0.1 to 0.4 degrees wide at 0.5 to 1 km, so a heavy ship that turns slowly finds small attackers late (the Shrike with one forward camera lost to a single Hornet 4 times out of 5; with two forward cameras 2 out of 5). Against several Hornets a single Shrike always lost in the sim (the old M3 result for any single fighter). Use turret ships (Warden, Leviathan) or a wing against drone swarms.
- **Lite Shrike and Lite Corsair do not find targets on their own.** Lite has no AI blocks, no sensor and (Corsair) no turrets, so autonomous search is the camera sweep only: in the sim `Shrike Lite` and `Corsair Lite` lost 0/3 to the Pirate without firing a shot (the nose camera is shot off first, the sweep turns the ship at 1 rad/s and rarely hits). Fly them (`lock` on a target gives the Helm one), or use the Full ships. `Warden Lite` and `Leviathan Lite` keep their turrets and won 3/3 vs the Pirate (Warden Lite, 64-80 s).

## All in-game tests for these ships

1. **World settings and cache (T13, T14).** "In-game scripts" on. Old blueprint folders deleted. Paste once with a stale `bp.sbcB5` left in a folder to see whether it matters. Decides: cause 1 of "script missing after paste".
2. **Paste the Lite twins first** (`Gnat Lite`, `Hornet Lite`, then the rest of the Lite set). Pass: it pastes, no floating blocks (cut one block with a grinder; thrusters, cameras, gyro, PB and antenna must stay), the PB's Edit window shows the code, its Custom Data shows the ini section, no DLC warning. Decides: the generator's basic XML (ComponentContainers, ModStorage custom data, orientation) is right.
3. **Paste the Full variants.** Same checks. If a Full ship fails and its Lite twin pastes, the unseen block shapes (Sensor, AI blocks, Decoy, cargo, turret) are the cause (T2, T11): send a Ctrl+B export of a small grid that holds one each of Timer, Sensor, Turret Controller, Event Controller, AI Offensive / Flight / Defensive, Merge Block, Projector, Welder, Warhead.
4. **Merge face (T1).** On two small grids put two `SmallShipSmallMergeBlock`s with their Up faces towards each other (and separately Right towards Right) and see which pair turns yellow / merges. Then check a drone's merge latch against a printer bay.
5. **Release (T3).** Merge two blocks; switch the drone-side one off, then the printer-side one off. Decides which side can release (needed by the printers; also by hand docking).
6. **Runtime and IGC limits (T12).** Print `Runtime.MaxInstructionCount` on a PB; send an IGC test message between two antenna ships at 1 km and 10 km. Decides whether hive messages reach as far as the Watcher's 5000 m antenna implies.
7. **Disarm (v2.4).** A drone merged on purpose to something else (carrier hangar) must not launch until the merge is released; run PB argument `disarm` to cancel auto-launch, `armed` to re-arm.
8. **Cradle bays, first contact (C0/T1, C1).** Paste `Cradle Pod Test`-style geometry: a Corsair Wing or a Cradle Pod with a Hornet pasted against a cradle merge block. Terminal: is it ONE grid (clamped) or two? If two, switch the host merge block Off and On from the terminal; if still two, the clamp face is wrong (`MERGE_CLAMP_FACE_SMALL`). Then PB argument `status` on the Pod PB / `[Bay] Corsair`: the screen must show `Bay 1 DOCKED HORNET 100%`; `EMPTY` with `merge open, no drone (C1...)` means the paste did not lock. Send the screen text and the grid list.
9. **Cradle release by hand (C5).** On the Pod PB / `[Bay] Corsair` run `release 1`. Expected: the PB screen goes ARMING -> RELEASED -> COOLDOWN within about a second, the drone's PB shows `Launch: took off`, it burns forward 4 s along the lane and then GUARDs; the other drone stays. Look for damage to the rear wall (3 cells behind the stalk), the neighbouring drone, the merge block. Then `release all`: two drones 2 s apart. If the drone sits there: PB screen of the bay (`FUSED`?) and of the drone.
10. **Gates.** Turn the ship (or accelerate) and run `release 1`: the bay must wait and say `waiting: ship turns ... rad/s` (limit 0.1) or `ship accelerates ... m/s2` (limit 1.0); `release 1 force` must go anyway. Put a block in the lane (or aim `Away`): `lane blocked at x,y,z`. Pasted drones start with the charge of the blueprint: if a drone battery is below 90 % the bay shows CHARGING and the batteries must read `Recharge`; they must charge from the pod's/ship's power (the sim never charges). Report what the screen says.
11. **Staff to pod across the connector (C3, C4).** Warden / Leviathan with the pod docked and both connector pairs locked: from the Staff PB run `release 1`. The Staff page shows `release 1: sent via ConnectedConstructs`, then `... AntennaRelay (try 2)`, `... unicast to the pod PB (try 3)`, then `the bays answered` or `NO BAY ANSWERED after 6 tries`. Report which try answered (that is the IGC result of C4); with a lost answer the hand launch is the Timer R(n) of the pod. Also: does the ship's Staff PB list the pod's blocks (`GridTerminalSystem` count with and without the pod, C3), and does the docked pod hold under 1 m/s2 for 30 s?
12. **Hangar doors (C8).** `doors open` / `doors close` on the Staff PB: time them (8 AirtightHangarDoors); then `release all`: the Staff opens the doors, waits for Open (up to 15 s), sends, and closes them 10 s after the last drone left. Report the open time and whether any door closed on a drone.
13. **Name-prefix rule (C10).** Corsair Wing with the two Hornets clamped and ShrikeAI/StaffAI in the Helm/Staff PBs: `Block Prefix=[SH]` is in their Custom Data (`[Link]` for the Helm, `[Staff]` for the Staff). Run `hunt` on the Helm (an enemy in sight, or `idle` and a hand-set target) and open the clamped Hornets' thrusters in the terminal: `Thrust Override` must stay 0 % and the Hornets' gyros must not be overridden. Then delete the prefix key and `reload` the Helm: the Hornets' thrusters/gyros now get overrides (that proves the clamped drones are blocks of the ship's grid in the game, too; switch it back). Also K3: the cockpit toolbar slot `Run` with the argument `release 1` while you sit in the seat.
14. **The warship scripts start and stay under the instruction limit (K11).** Open `[Helm]`, `[Staff]`, `[Bay]`/`[Pod]` PBs of each ship: ShrikeAI 0.1 / StaffAI 1.4 / CradleBayAI 1.0 on the PB screen, no `Script too complex`. Fly 5 minutes in `hunt` against something and watch the Helm's `Ins` line (it shows the peak per run): the sim's pessimistic IL model peaks at about 25,000 (Shrike, Warden) of the 50,000; if the real count is much higher the integrity scan (`CheckDamage`, 150 blocks per call) is the first thing to slow down.
15. **Sit down, stand up (K1, K2, K7).** Shrike first. MANUAL within about 0.4 s of sitting, no tug of war on the stick, the HUD pip on screen 0, the dampener switch as you left it; 1.5 s after standing up the Helm is back in its old mode and does not snap the nose. Then `assist fbw` with a lock; if the nose turns the wrong way flip `[Manual] Pilot Rot Sign`, scale with `Pilot Rate Gain` / `Rotation Input Scale`. Large ships: the Remote Control and the Gunnery Seat must NOT put the Helm into MANUAL.
16. **Run menu (K3).** Cockpit toolbar slot with `Run` on the Helm or Staff PB, no argument: each press steps the menu on the PB screen, the highlighted item runs 2 s after the last press. Then try a `Run` slot WITH an argument (Ctrl+B export, see whether the argument is saved).
17. **Dead-man in the game (K8).** Ship flying in `hunt`, switch the Helm PB off in the terminal: thrusters and gyros released within about 1.5 s (Staff), guns off, `HELM LOST` on cockpit screen 0, Timer `(deadman)` after 5 s. Switch it on again: `Helm back`. Repeat sitting in the seat: the Event Controller `EC Cockpit` (set its event by hand: cockpit occupied -> stop the timer, empty -> start) must start the timer when you leave.
18. **`launch all` in a fight.** Warden Wing / Corsair Wing with a target at 1-2 km: `launch all` on the Staff PB. The Helm goes idle (the ship stops turning), the doors open, the drones leave one by one, the Helm comes back to its mode. Then `wing satellite` (ring 100 m plus hull) and `wing hunt`. If the bays only say `waiting: ship turns ...` the ship does not settle (the Helm is not idle?); `release n force` is the manual override.
19. **Turn rate and braking of the large ships.** Time a 90 degree turn and the braking from 40 m/s: the sim says Warden 0.30 rad/s2 yaw (90 degrees in about 4.5 s with a 1.5 rad/s rate cap; `Max Turn Rate` is calibrated by the script from the first turns), Leviathan 0.04 rad/s2 (90 degrees in about 13 s), braking 1.7 / 1.0 m/s2 (Warden 24 s, Leviathan 40 s from 40 m/s). Large differences mean the gyro or thruster model is off; set `Max Turn Rate rad/s` and `Auto Max Turn (AUTO/ON/OFF)` by hand.

## Changelog

### v2.7 (unreleased): WARSHIPS Shrike, Corsair, Warden, Leviathan (new package `Warships_v2.7_Full` / `_Lite`)
- **Helm default mode REACT** (`ShrikeAI.cs`, mode 7 in the `.H2S` flags, `StaffAI.cs` shows it): combat-ready but passive until an AI alarm, a mate's alarm, damage or a held target wakes it. `Start Mode` default is REACT (the key name is unchanged). Four rarely used Custom Data keys were dropped to make room (`Target Large/Small Grids`, `Aim Kp/Kd`, `RTB Battery Fraction`); the Helm is 79,977 of 80,000.
- **Cockpit buttons `deploy` / `dock`** (Staff) on Warden, Leviathan and Corsair; the cradle bay PB keeps a docked drone's thrusters off and switches them on at release.
- **Walkways and entry** (Warden, Leviathan; Shrike and Corsair are cockpit-only): slide doors (`LargeBlockSlideDoor`, seen in the Tech Hunter sample) in both sides of the tower stem lead to a one-cell passage and shaft to the bridge and, on the Warden, through the hangar roof; the Leviathan also has a door into each hangar. `carve_walkway` / `route_walkway` / `walk_check` in `designs/_common.py` (the build asserts a walk from the outside door to the bridge and hangars).
- **Gravity generator** (large `GravityGenerator`, 1 g toward the ship's down, field over the crew spaces) on Warden and Leviathan Full (the Lite variants keep no unseen shape). Large grid only: the small-grid Corsair cannot carry one. The object-builder fields (`FieldSize`, `GravityAcceleration`) were never seen in a game file.
- **Round slopes / corners** in the concave edges of the big Leviathan rooms (`chamfer_room`); the Warden's rooms are too cramped to take any.
- **`<ConveyorLines>`** are now written for every face-adjacent ported pair (junction cubes, thrusters on tanks / junctions, turret / tank / locker terminals), as the game's own saves do. Suspected cause of ships that could not hold forward: without the lines the hydrogen network may not connect on paste. Not verified in the game.

New zips with four ships that fly by hand (sit in the seat) and by themselves, plus the Cradle Pod and the `Corsair Wing`, `Warden Wing`, `Leviathan Wing` variants with Hornets in the cradles.
Three scripts: `ShrikeAI.cs` (the Helm of every ship: Hornet brain + MANUAL mode + weapon batteries + dead-man heartbeat; 79,990 of its 80,000 characters), `StaffAI.cs` (heartbeat watch that releases every
override when the Helm dies, wing orders and roll call, hangar doors, drone launch, display pages) and `CradleBayAI.cs` (the merge-block cradles). The usage guide is the README of the Warships zips.
The drone zips no longer contain the warships (they moved to the new zips); the All zip has everything. All ships were run in the simulator only: nothing has been pasted into the game yet.
- Staff 1.4: `launch [n|a-b|all]` (parks the Helm so the bays' ship-turns / ship-accelerates gates pass, releases, gives the Helm its mode back); `[Staff] Turret Target Group` / `Turret Target Names`
  (artillery and assault turrets aim at the targets' weapons: Leviathan vs Pirate, kill time median 143 s -> 89 s in the sim; replaces the planned Gunnery PB).
- ShrikeAI: the integrity scan (hit direction) is sliced, 150 blocks per call (a 1,300-block ship read all of them in one tick: 58,000 IL instructions of the 50,000 limit; peak is now 25,000);
  a seat named `Gunnery` no longer switches the Helm to MANUAL (`[Manual] Seat Exclude`).
- Designs: the Helm Custom Data of every ship now carries the keys the scripts read (the old `[Battery n]` / `[Cockpit]` sections were read by nobody); large ships: stand-off 700 / 800 m, jinking off,
  AI-block search off (the AI Flight block made the idle warship wander); Warden / Leviathan Timer D renamed `Timer D (deadman)` (the Helm finds it by that word: they had none); the Shrike has a second forward camera
  (with one the nose camera was shot off and the Shrike never saw a Hornet again); the empty Gunnery PB of the Leviathan is gone.
- Simulator: warship scenarios (`ship/<Blueprint>-vs-<Enemy>`) start with the Custom Data the blueprint carries and keep a connector-docked pod rigidly on its host; `selftest m6`.

### v2.7 (unreleased): SATELLITE formation
New operating mode: the drones spread round a slowly turning vertical ring centred on the owner (a ship running a Mothership link, you on foot, or the Gnat's carrier /
home point), break off and engage anything inside the Engage Radius, and fly back to their slots afterwards. Command `satellite` / `sat` / `orbit`; ring distance
(`Satellite Distance`, default 100 m, grows with the number of ships), orbit period and plane are in the `[Follow]` Custom Data section. Details, numbers and tests:
`docs/follow-mode.md`. FOLLOW block v1.1 (`tools/follow_block.cs`); the Gnat has its own copy. Size: the Basilisk is now 99,733 of the 100,000 characters.

### v2.6 (this package): BREACH aim against big ships; SEEKER test ships
- **Script length fix (important).** A Programmable Block takes at most 100,000 characters; since v2.2 every armed drone script
  was over it (Hornet 155,629, Basilisk 175,054 characters with comments), so a pasted drone's PB could not hold its script. The
  blueprints and the zips' `Scripts/` folder now carry minified scripts (comments and whitespace removed only; `tools/minify_cs.py`,
  proven identical by compiling both and comparing the IL, `tools/minify_check.sh`; largest now Basilisk 97,721). The commented
  originals are in `Scripts/Source/`, for reading only: they are too long to paste. The build refuses a script over the limit.
Question from the user: against large battleships (their *Tech Hunter*) the drones "can't figure out where vital components are and
just shoot the hull". Study: `docs/tech-hunter-study.md` (1,280 simulated fights, fleets of up to 10 Hornet / Gnat / Longbow S /
Longbow L / Basilisk).
- **BREACH** (shared block `tools/aim_block.cs` in every armed drone script, synced by `tools/aim_sync.py`): against a large grid of
  radius >= 25 m, AUTO holds one hull point (the known one nearest the target's centre, where the armour over the core is thinnest),
  keeps every round on it, and aims down the hole as it deepens; stalled or missing points are swapped. Sim vs Tech Hunter: railgun
  drones destroy about twice as many power blocks (Longbow L 0.65 -> 1.2 per drone in 10 min), at the cost of fewer exposed turrets.
  `aim breach`, `breach on|off`; Custom Data `Breach Large Ships (AUTO)`, `Breach Min Target Radius (m)`, `Breach Stall (s)`.
- **SEEKER (experimental, option 4)**: a turret on the drone named `[Seeker]` is set to `Seeker Group` (PowerSystems / Weapons /
  Propulsion); the script reads where it points and drills there. New test ships **Longbow L Seeker** (artillery turret, 2 km) and
  **Basilisk Seeker** (roof turret renamed); `scripts/SeekerProbe.cs` reports what any ship's turrets tell a script. In the sim it did
  not beat BREACH; the in-game API behaviour is the open question (test 23).
- Finding for fleet building: against a turret-heavy capital ship only Longbow L survives (2 km = artillery range); Hornets, Gnats and
  Basilisks die in under 70 s whatever they aim at. Nothing of 10 drones or fewer knocked the Tech Hunter out in 10 minutes.
- Simulator turret ranges as in the game: an AI turret on its own targets within its Range setting, at most 800 m for every
  large-grid turret (artillery and assault cannon included), 600 m small grid; a working AI Offensive/Defensive block on its grid
  unlocks the ammo range (artillery 2 km, assault cannon 1.4 km). Turn rates and elevation limits per turret type from the data
  (artillery 0.2 rad/s). Re-run vs Tech Hunter: Longbow S now survives too; with BREACH 10 of them destroy 4.2 power blocks (0.8 before).
- Simulator: turrets need power; only railguns have a capacitor (artillery / assault-cannon capacitors starved every turret of a big
  ship); turret targeting groups + Azimuth/Elevation API; enemy vitals in the results; `--enemy-fleets`.

### v2.5: foundry fixes (finish-welding, robust reach, automatic take-off, owner ids)
- **Finish-welding verification.** `HiveMotherAI.cs` 2.1 no longer leaves BUILD when the projector reports 0 blocks left (that only means "all placed", not "all welded"). A new FINISH state keeps every welder on until a full scan of the bay's drone box finds each block at full integrity and functional. Welders can no longer be switched off in BUILD/FINISH (the old stall "kick" that turned all welders off is gone; it now toggles one welder at a time). The LCD lists unfinished blocks (name, cell, integrity, distance to the nearest welder), reports off/damaged/unpowered welders and an empty `[Stock]`, and FINISH has a timeout that FAULTs with the list.
- **Robust welder reach.** The welder sphere centre is unknown (model dummy), so `reach.py` now checks 8 hypotheses (centre at the tip, 1, 2 or 3 cells inside the welder; radius 1.3 m and 1.0 m), a build-order support check and a foreign-bay check. Hornet-class bays now carry 10-12 welders (was 5-8), Gnat bays 7 (was 5). Exit directions were re-chosen per drone. Costs about +900 PCU and +2.7 t per Hornet-class bay. Per-bay Custom Data gains `Drone Box Min/Max`, `Drone Cell Count`, `Drone Occupied Cells`, `Ignore Cells`, an explicit `Exit Direction`, and a `[Launch]` section.
- **Automatic take-off.** A shared LAUNCH block (`tools/launch_block.cs`, synced by `tools/launch_sync.py`) is in the Hornet, Gnat, Longbow, Mantis, Wasp, Lancer, Harrier, Aegis and Basilisk scripts. A printed drone launches when its own PB sees the merge pair open, or on `[Launch] Armed=true`, `_JOIN`, FLEET `join`, or the arguments `armed` / `launch` / `disarm`. No single message is needed. It burns away from the printer for `Burst Seconds`, then goes home and into its start mode (default GUARD). The printer writes `[Launch]` into the drone PB before release, repeats `_JOIN` for 40 s and recompiles the drone PB.
- Known limit: Gnat only thrusts forward/back, so a lateral Away direction does not move it in the sim (see docs/launch-protocol.md). The Stinger script is not yet integrated with the LAUNCH block.
- Docs: `docs/foundry-notes.md`, `docs/welder-reach.md`, `docs/launch-protocol.md`, `docs/hive-protocol.md` section 9.
- **Owner / built-by ids.** Blueprints now carry Owner and BuiltBy (the in-game PB showed `Owner: Nobody` because none were written). Already-pasted v2.x ships: select all blocks in the terminal and Transfer to yourself.

### v2.4 : kamikaze defence
Simulated attacks by swarms of small warhead drones (4 and 8 Stingers cued by a carrier's radar, against every combat drone model) showed the
scripts writing the kamikazes off as wrecks. A Stinger correcting its course at the speed cap spins 1-2 rad/s, so the "tumbling for 4 s" rule
dropped it, ignored it for 120 s and told the whole hive it was finished, usually just before it arrived.
- **KAMIKAZE DEFENCE** (shared block in every combat drone script, `tools/kz_block.cs`, synced by `tools/kz_sync.py`; scripts 2.6 / Gnat 1.13
  / Longbow 2.4; details in `docs/kamikaze-defence.md`):
  - small contacts on a collision course with the drone or a hive mate are never written off as wrecks, and are dropped once spent;
  - they become the priority target;
  - the drone backs away along the threat axis while its guns stay on target, and breaks sideways inside 2 s of impact;
  - spare camera charge tracks the rest of the swarm and searches round known kamikazes for their pack;
  - the threats are shared with the hive, and Gnats skip their run-in against a kamikaze.
  New `[Kamikaze Defence]` section in Custom Data; PB screen line `!! KAMIKAZE x3 (2 at me) next 4.2 s 380 m`.
- Simulator, 620 kamikaze fights (20 seeds): defenders still fighting at the end 57% -> 70%, damage taken -41%. Against 4 Stingers, a lone
  Hornet goes 50 -> 80%, Lancer 45 -> 85%, Mantis 35 -> 75%, Longbow S 55 -> 80%. Fights without kamikazes are unchanged (1v1 regression in the doc).
- Simulator: scenario kind `kamikaze`, settings `SwarmCueSeconds` / `SwarmCueTeam`, `one --echo-every S`, report tool `tools/kz_report.py`.

### v2.3: lead aiming against manoeuvring targets
In-game report (2026-10-13): the Basilisk's rockets kept missing an enormous target that was doing basic evasive manoeuvres. A rocket
needs about 4 s to fly 800 m; an AI ship on "evasive" flips its strafe every 2-5 s. Full write-up and measurements: `docs/lead-v1.md`.
- **LEAD v1.0** (shared block in every armed drone script, `tools/lead_block.cs`, scripts v2.5 / Gnat 1.12 / Longbow 2.3):
  - the target's freshest acceleration, held only for as long as its manoeuvres usually last, then constant velocity (the old
    solver extrapolated a lagging, smoothed acceleration over the whole flight);
  - the hull aim point counts only across the line of fire, turns with the target's spin for up to 1 s, and keeps
    `Aim Margin (predicted misses)` x the predicted miss of known hull round it, so long, uncertain shots go to the middle of the
    known hull instead of its edge.
- Basilisk / Wasp: rockets modelled as leaving with the ship's velocity + launch speed and curving onto the barrel line
  (`Rocket Velocity Model` CAPPED / NONE / FULL; NONE is the v2.2 model). Closed-form rocket path, Newton solve on the flight time.
- Offline bench (`tools/lead_bench`), hits on manoeuvring targets: rockets 50 % -> 62 % (strafing 120 m ship 43 -> 66 %, strafing
  30 m ship 14 -> 39 %), gatling 70 % -> 90 %, railgun 77 % -> 90 %.
- Simulator: rockets inherit the shooter's velocity with the speed cap (`--rocket-inherit`, default 1), evasive Pirate
  (`--pirate-evasive true`).

### v2.2: FOLLOW mode
Question from the user: does `guard` follow the owner? Only as a side effect: a Mothership link's position replaces the guard spot, but
the drones fly to the ship's centre (into its hull for most drone types), lag behind a moving ship, and fall back to the old spot when
the link stops. Nothing followed a player on foot.
- **FOLLOW** (shared block in every scripted combat drone, `tools/follow_block.cs`, synced by `tools/follow_sync.py`): `follow` / `escort`
  command (also Start Mode and launch Mode `FOLLOW`). The owner is the ship running a Mothership link (any type, FLEET channel), or the
  owner's own character seen by the drone's sensor (on foot, ~50 m; wins while seen). Each drone flies its own slot on a ring behind the
  owner (upper half in gravity) outside its hull, with the owner's velocity fed forward (estimated from the link's position fixes, so old
  link scripts work), detours round the hull instead of through it, engages only targets within 800 m of the owner, breaks off past
  1.2 km (2.2 km for the snipers), and after a link loss coasts 3 s on the owner's track (10 s on foot) and holds there. On a
  collision course with the owner it sidesteps up to 8 s ahead, and the ring widens (up to 2x) while the owner manoeuvres hard.
  New `[Follow]` section in Custom Data. No AI-block search in FOLLOW (the AI Flight block would fly the drone away from you).
- Gnat 1.11: `follow` / `escort` = `form`; the formation now matches the link ship's velocity (keeps up with it), and also reads the
  ship radius from the FLEET channel.
- Mothership links (Hornet / Longbow v1.1, Gnat v1.2): send the ship's radius on `<Tag>_HOMER` and `<fleet>_HOMER`; `follow` relays.
- FLEET block: `follow` and `escort` added to the default `Allowed Commands`.
- Simulator: `follow-test` (moving owner on the fleet channel, or an owner character reported to the sensors; cruise, weave, link loss,
  on foot, fight).

### v2.1: first in-game report fixes
In-game report (2026-10-13): Full drones set to `guard` stood still; `hunt` drones waited about 20 s, then all flew off the same way
and never saw a pirate ship 700 m away. Cause: the AI blocks paste with **AI Behavior off**, so they do nothing, but the scripts handed
them the ship and switched their own camera search off while waiting for them. Reproduced in the simulator (AI blocks inert:
3 Hornets vs pirate at 700 m won 0 of 40, found the pirate in 1 of 40 runs).
- **AI GATE** (shared block in every scripted drone, `tools/ai_gate_block.cs`): the script tries to switch AI Behavior on itself
  (the PB screen says whether it could). Until the AI blocks have flown the ship once, they only get it in 6 s windows between 8 s
  of the script's own camera search (under fire the script searches); once they have, they are trusted as before (status `AI ok`).
  New `[AI Gate]` section in Custom Data.
- Side cameras scan out to 900 m whenever there is no target (was 120 m); short close-scan rays no longer drain the nose cameras
  below the long scan's range while under fire.
- Hit direction: the blocks that lose integrity tell which side was hit; the nose sweep and the side cameras search that side.
- HUNT search patrol: drones fan out (each starts its square at a different corner), keep sweeping their cameras on a leg instead of
  looking along the flight path, hold position at listening stops, and Lite drones (no AI blocks) patrol too.
- Simulator results (pirate ship 700 m away, 36 pirate scenarios x 20 seeds, every model): AI blocks doing nothing, `hunt`: drone
  side wins 23 -> 44 of 720, `guard`: 24 -> 47 of 720 (3 Hornets alone: found the pirate in 1 -> 15 of 40 fights); AI blocks that
  need the AI Behavior switch: 23 -> 211 of 720 (the script switches it on). With working AI blocks drone-vs-drone results are
  unchanged (1v1 without the Watcher, 1,560 fights: 77.6 % -> 77.4 % decisive). The unarmed Watcher (no AI blocks) now patrols in
  `hunt` like every drone without AI blocks, so armed drones catch it less often (Watcher fights 60 % -> 24 % decisive).
- Simulator: `--script-ai-blocks-inert` (AI blocks never act) and `--ai-behavior-needs-switch` (AI blocks act only once a script
  switches "ActivateBehavior" on); `GetProperties`/`GetActions` on terminal blocks.

### v2.0
- Every model exists as Full and **Lite** (Lite: only block XML shapes seen in a game-written ship, plus the merge block). Both variants build, validate and ship from one generator (`tools/build_all.py`).
- Blueprint generator rewritten around real data: mount-point validation (checked against the Starburst ship), real masses and costs from `defs_stats.json`, `<Toolbar>` written for Sensor/Timer/Turret Controller/Event Controller (probable paste-failure fix), Custom Data stored in ModStorage (the old `<CustomData>` element was ignored by the game), unique blueprint ids, stable (crc32) seeds, no `.sbcB5`.
- Weapon data corrected from the local game files: gatling 700 rpm, 800 m/s (was 400).
- Merge block clamp face corrected: small 1x1x1 block clamps toward Up (was Right); Hornet, Gnat and every printable drone got a clear docking face.
- New drones: **Wasp** (rockets), **Lancer** (autocannon), **Watcher** (unarmed scout), **Harrier** (interceptor), **Aegis** (escort / point defence), **Mantis** (railgun + gatling), **Basilisk** (large-grid rocket gunship), **Midge** (scriptless, experimental).
- New printers (projector + welders + merge block bays, `HiveMotherAI.cs` 2.0): Hive Mother, Twin Hive, Quad Hive, Hornet Forge, Wasp Foundry, Lancer Foundry, Longbow Foundry, Harrier Forge, Aegis Shipyard, Mantis Foundry, Watcher Pad, Fleet Forge, Escort Carrier, Mobile Hive, Static Nest, Stinger Rack.
- Hornet: rear camera moved one cell up to make room for the docking stalk. Gnat: merge block on a 2-cell stalk under the belly.
- Printers: every bay now has an exit lane. Before, Hornet-class bays (Hornet, Wasp, Lancer, Longbow S, Harrier, Aegis, Mantis, Watcher) had a welder on every side of the drone, so the finished drone could not leave. The drone's footprint swept 14 cells away from the merge block is kept free; Longbow S and Mantis leave sideways (outwards, away from the neighbour bay) and HiveMotherAI.cs reads the new per-bay `Exit Direction` Custom Data key to nudge the printer the right way.

### v1.x history
- **v1.0**: Hornet (gatling), Longbow S/L (railgun), Gnat (2-thruster swarm), mothership relays.
- **v1.1**: sensors added; nothing pasted.
- **v1.2**: sensor removed; Longbow stopped reading railgun power.
- **v1.3**: steadiness-gated lead, `Lead Scale`.
- **v1.4**: 5 extra cameras + all-around close scan; compact embedded scripts (size theory later disproven).
- **v1.5**: disabled-target detection, damage sensing and evasion, split focus, on-screen errors.
- **v1.6**: hull-point aim modes.
- **v1.7**: AI-block search hand-off (user places `[AI]` blocks).
- **v1.8** (uncompiled in-game): printer join / re-scan on grid change, Hornet scout mode.
